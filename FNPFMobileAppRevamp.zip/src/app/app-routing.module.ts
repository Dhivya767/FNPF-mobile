import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    loadChildren: () =>
      import('./start/splash/splash.module').then((m) => m.SplashPageModule),
  },
  {
    path: 'home',
    loadChildren: () =>
      import('./home/home.module').then((m) => m.HomePageModule),
  },
  {
    path: 'login',
    loadChildren: () =>
      import('./start/login/login.module').then((m) => m.LoginPageModule),
  },
  {
    path: 'app-version',
    loadChildren: () => import('./start/app-version/app-version.module').then(m => m.AppVersionPageModule)
  },

  {
    path: 'landing',
    loadChildren: () =>
      import('./start/landing/landing.module').then((m) => m.LandingPageModule),
  },
  {
    path: 'staff-login-step1',
    loadChildren: () =>
      import(
        './start/login/staff/staff-login-step1/staff-login-step1.module'
      ).then((m) => m.StaffLoginStep1PageModule),
  },
  {
    path: 'staff-login-step2',
    loadChildren: () =>
      import(
        './start/login/staff/staff-login-step2/staff-login-step2.module'
      ).then((m) => m.StaffLoginStep2PageModule),
  },
  {
    path: 'login-with-password-step1',
    loadChildren: () =>
      import(
        './start/login/employee/login-with-password-step1/login-with-password-step1.module'
      ).then((m) => m.LoginWithPasswordStep1PageModule),
  },
  {
    path: 'login-with-password-step2',
    loadChildren: () =>
      import(
        './start/login/employee/login-with-password-step2/login-with-password-step2.module'
      ).then((m) => m.LoginWithPasswordStep2PageModule),
  },
  {
    path: 'login-with-password-step3',
    loadChildren: () =>
      import(
        './start/login/employee/login-with-password-step3/login-with-password-step3.module'
      ).then((m) => m.LoginWithPasswordStep3PageModule),
  },
  {
    path: 'login-with-pin-step1',
    loadChildren: () =>
      import(
        './start/login/employee/login-with-pin-step1/login-with-pin-step1.module'
      ).then((m) => m.LoginWithPinStep1PageModule),
  },
  {
    path: 'login-with-pin-step2',
    loadChildren: () =>
      import(
        './start/login/employee/login-with-pin-step2/login-with-pin-step2.module'
      ).then((m) => m.LoginWithPinStep2PageModule),
  },


  {
    path: 'forgot-login',
    loadChildren: () =>
      import('./start/login/employee/forgot-login/forgot-login.module').then(
        (m) => m.ForgotLoginPageModule
      ),
  },
  {
    path: 'forgot-password',
    loadChildren: () =>
      import(
        './start/login/employee/forgot-password/forgot-password.module'
      ).then((m) => m.ForgotPasswordPageModule),
  },
  {
    path: 'forgot-pin',
    loadChildren: () =>
      import('./start/login/employee/forgot-pin/forgot-pin.module').then(
        (m) => m.ForgotPinPageModule
      ),
  },
  {
    path: 'reset-new-pin',
    loadChildren: () =>
      import('./start/login/employee/reset-new-pin/reset-new-pin.module').then(
        (m) => m.ResetNewPinPageModule
      ),
  },
  {
    path: 'terms-and-conditions',
    loadChildren: () =>
      import('./start/terms-and-conditions/terms-and-conditions.module').then(
        (m) => m.TermsAndConditionsPageModule
      ),
  },
  {
    path: 'reset-password',
    loadChildren: () =>
      import(
        './start/login/employee/reset-password/reset-password.module'
      ).then((m) => m.ResetPasswordPageModule),
  },
  {
    path: 'reset-message',
    loadChildren: () =>
      import('./start/login/employee/reset-message/reset-message.module').then(
        (m) => m.ResetMessagePageModule
      ),
  },
  {
    path: 'change-fnpf-no',
    loadChildren: () =>
      import(
        './start/login/employee/change-fnpf-no/change-fnpf-no.module'
      ).then((m) => m.ChangeFnpfNoPageModule),
  },
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full',
  },
  {
    path: 'registration',
    loadChildren: () =>
      import('./start/registration/registration.module').then(
        (m) => m.RegistrationPageModule
      ),
  },
  {
    path: 'retrieve-message',
    loadChildren: () =>
      import(
        './start/login/employee/retrieve-message/retrieve-message.module'
      ).then((m) => m.RetrieveMessagePageModule),
  },
  {
    path: 'get-tin/:id',
    loadChildren: () =>
      import('./start/login/employee/get-tin/get-tin.module').then(
        (m) => m.GetTinPageModule
      ),
  },  {
    path: 'demo',
    loadChildren: () => import('./start/demo/demo.module').then( m => m.DemoPageModule)
  },



];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules }),
  ],
  exports: [RouterModule],
})
export class AppRoutingModule { }
