import { ComponentFixture, TestBed } from '@angular/core/testing';
import { GovernmentAssistancePage } from './government-assistance.page';

describe('GovernmentAssistancePage', () => {
  let component: GovernmentAssistancePage;
  let fixture: ComponentFixture<GovernmentAssistancePage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(GovernmentAssistancePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
