import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { GovernmentAssistanceStep10PageRoutingModule } from './government-assistance-step10-routing.module';

import { GovernmentAssistanceStep10Page } from './government-assistance-step10.page';
import { MessagesModule } from "../../../../app-core/template/messages/messages.module";

@NgModule({
    declarations: [GovernmentAssistanceStep10Page],
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        GovernmentAssistanceStep10PageRoutingModule,
        MessagesModule
    ]
})
export class GovernmentAssistanceStep10PageModule {}
