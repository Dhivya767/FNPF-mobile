import { ComponentFixture, TestBed } from '@angular/core/testing';
import { GovernmentAssistanceStep10Page } from './government-assistance-step10.page';

describe('GovernmentAssistanceStep10Page', () => {
  let component: GovernmentAssistanceStep10Page;
  let fixture: ComponentFixture<GovernmentAssistanceStep10Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(GovernmentAssistanceStep10Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
