import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from 'src/app/app.service';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { GovernmentAssistanceService } from '../government-assistance.service';

@Component({
  selector: 'app-government-assistance-step10',
  templateUrl: './government-assistance-step10.page.html',
  styleUrls: ['./government-assistance-step10.page.scss'],
})
export class GovernmentAssistanceStep10Page implements OnInit {
  Content: any;
  constructor(
    public router: Router,
    public governmentAssistanceService: GovernmentAssistanceService,
    public data: DataService,
    public appService: AppService,
    public applicationService: ApplicationApiService
  ) {
    this.Content = this.data.getErrorMessageByCode(
      '40',
      this.appService.appMessages
    );
  }

  ngOnInit() {}
  goNext() {
    if (
      !this.governmentAssistanceService.governmentAssistance
        .ibusUIGovernmentAssistanceAdditionalInfo.statutory_declaration ||
      this.governmentAssistanceService.governmentAssistance
        .ibusUIGovernmentAssistanceAdditionalInfo.statutory_declaration ===
        '' ||
      this.governmentAssistanceService.governmentAssistance
        .ibusUIGovernmentAssistanceAdditionalInfo.statutory_declaration
        .length == 0
    ) {
      this.data.constructErrorMessage('Please accept declaration to proceed.');
      return;
    }

    this.applicationService
      .saveGovernmentAssistanceApplication(
        this.governmentAssistanceService.governmentAssistance
      )
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.governmentAssistanceService.governmentAssistance = success;
          this.router.navigateByUrl(
            '/home/make-withdrawl/government-assistance/government-assistance-step12'
          );
        }
      });
  }
  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
  goToHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
}
