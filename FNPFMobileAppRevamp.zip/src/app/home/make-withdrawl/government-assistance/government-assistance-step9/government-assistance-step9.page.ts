import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from 'src/app/app.service';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { GovernmentAssistanceService } from '../government-assistance.service';

@Component({
  selector: 'app-government-assistance-step9',
  templateUrl: './government-assistance-step9.page.html',
  styleUrls: ['./government-assistance-step9.page.scss'],
})
export class GovernmentAssistanceStep9Page implements OnInit {
  Content: any;
  constructor(
    public router: Router,
    public governmentAssistanceService: GovernmentAssistanceService,
    public data: DataService,
    public appService: AppService,
    public applicationService: ApplicationApiService
  ) {
    this.Content = this.data.getErrorMessageByCode(
      '41',
      this.appService.appMessages
    );
  }

  ngOnInit() {}
  goToHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
  goNext() {
    this.loadGovernmentAssistanceDocuments();
  }
  loadGovernmentAssistanceDocuments() {
    this.applicationService
      .loadGovernmentAssistanceDocuments(
        this.governmentAssistanceService.governmentAssistance
      )
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.governmentAssistanceService.governmentAssistance = success;
          if (
            this.governmentAssistanceService.governmentAssistance
              .ilstbusUIAppWithdrawalApplicationDocuments &&
            this.governmentAssistanceService.governmentAssistance
              .ilstbusUIAppWithdrawalApplicationDocuments.length > 0
          ) {
            this.router.navigateByUrl(
              '/home/make-withdrawl/government-assistance/government-assistance-step11'
            );
          } else {
            this.router.navigateByUrl(
              '/home/make-withdrawl/government-assistance/government-assistance-step10'
            );
          }
        }
      });
  }
  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
}
