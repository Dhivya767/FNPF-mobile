import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { GovernmentAssistanceStep9Page } from './government-assistance-step9.page';

const routes: Routes = [
  {
    path: '',
    component: GovernmentAssistanceStep9Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class GovernmentAssistanceStep9PageRoutingModule {}
