import { ComponentFixture, TestBed } from '@angular/core/testing';
import { GovernmentAssistanceStep9Page } from './government-assistance-step9.page';

describe('GovernmentAssistanceStep9Page', () => {
  let component: GovernmentAssistanceStep9Page;
  let fixture: ComponentFixture<GovernmentAssistanceStep9Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(GovernmentAssistanceStep9Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
