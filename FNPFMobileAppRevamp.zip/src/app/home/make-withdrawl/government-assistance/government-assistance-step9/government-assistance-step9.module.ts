import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { GovernmentAssistanceStep9PageRoutingModule } from './government-assistance-step9-routing.module';

import { GovernmentAssistanceStep9Page } from './government-assistance-step9.page';
import { MessagesModule } from "../../../../app-core/template/messages/messages.module";

@NgModule({
    declarations: [GovernmentAssistanceStep9Page],
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        GovernmentAssistanceStep9PageRoutingModule,
        MessagesModule
    ]
})
export class GovernmentAssistanceStep9PageModule {}
