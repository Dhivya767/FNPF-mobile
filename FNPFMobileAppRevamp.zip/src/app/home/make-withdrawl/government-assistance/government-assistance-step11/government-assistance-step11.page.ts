import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ModalController } from '@ionic/angular';
import { CameraService } from 'src/app/app-core/mobile-service/camera/camera.service';
import { AppService } from 'src/app/app.service';
import {
  busUIAppWithdrawalApplicationDocuments,
  busUIMemberProfile,
} from 'src/app/common/api-services/admin-api/admin-api.classes';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { MicrobusinessAssistanceService } from '../../partial-withdrawl/microbusiness-assistance/microbusiness-assistance.service';
import { GovernmentAssistanceService } from '../government-assistance.service';

@Component({
  selector: 'app-government-assistance-step11',
  templateUrl: './government-assistance-step11.page.html',
  styleUrls: ['./government-assistance-step11.page.scss'],
})
export class GovernmentAssistanceStep11Page implements OnInit {
  selectedDocument = new busUIAppWithdrawalApplicationDocuments();
  selectedDocumentRAW = new busUIAppWithdrawalApplicationDocuments();
  memProfile = new busUIMemberProfile();
  @ViewChild('nativeFileUpload')
  nativeFileUpload!: ElementRef;
  documentIndex = 0;
  id = '';
  isMandatory = false;
  isShowUpload = false;
  errorMessage = '';
  instructionMessage = '';
  title = '';
  fileTypes: any = [];
  fileSize = 0;
  constructor(
    public route: ActivatedRoute,
    public governmentAssistanceService: GovernmentAssistanceService,
    public cameraService: CameraService,
    public data: DataService,
    public appService: AppService,
    public applicationService: ApplicationApiService,
    public router: Router,
    public modal: ModalController
  ) {
    this.route.paramMap.subscribe((params) => {
      this.init();
    });
    this.selectedDocument = JSON.parse(
      JSON.stringify(
        this.governmentAssistanceService.governmentAssistance
          .ilstbusUIAppWithdrawalApplicationDocuments[this.documentIndex]
      )
    );
  }

  ngOnInit() {}
  init() {
    this.selectedDocument = new busUIAppWithdrawalApplicationDocuments();
    this.selectedDocumentRAW = new busUIAppWithdrawalApplicationDocuments();
    this.isMandatory = false;
    this.isShowUpload = false;
    this.errorMessage = '';
    this.instructionMessage = '';
    this.title = '';

    let id: any = this.route.snapshot.paramMap.get('id');
    this.id = id;

    let documentList =
      this.governmentAssistanceService.governmentAssistance
        ?.ilstbusUIAppWithdrawalApplicationDocuments;
    if (documentList) {
      let index = documentList
        .map((e: any) => e.document_type_value)
        .indexOf(this.id);
      if (index > -1) {
        this.selectedDocument = documentList[index];
        this.selectedDocument.withdrawal_application_id =
          this.governmentAssistanceService.governmentAssistance.withdrawal_application_id;
        this.selectedDocumentRAW.withdrawal_application_id =
          this.governmentAssistanceService.governmentAssistance.withdrawal_application_id;
        this.selectedDocumentRAW.document_type_description =
          this.selectedDocument.document_type_description;
        this.selectedDocumentRAW.document_type_id =
          this.selectedDocument.document_type_id;
        this.selectedDocumentRAW.document_type_value =
          this.selectedDocument.document_type_value;
        this.selectedDocumentRAW.modified_date =
          this.selectedDocument.modified_date;
        this.checkWeatherCurrentDocumentTypeIsMandatoryOrNot();
      }
    }
    this.getLowBalanceWithdrawalFileTypes();
  }
  getLowBalanceWithdrawalFileTypes() {
    this.applicationService
      .getEducationWithdrawalFileTypes()
      .subscribe((success: any) => {
        if (success) {
          this.fileTypes = [];
          this.fileTypes = success;
        } else {
          this.fileTypes = [];
          this.fileTypes.push('jpg');
          this.fileTypes.push('jpeg');
          this.fileTypes.push('pdf');
        }

        this.getLowBalanceFileSize();
      });
  }
  getLowBalanceFileSize() {
    this.applicationService
      .getEducationWithdrawalFileSize(
        this.governmentAssistanceService.governmentAssistance
      )
      .subscribe((success: any) => {
        if (success) {
          this.fileSize = success;
        } else {
          this.fileSize = 3;
        }
      });
  }

  checkWeatherCurrentDocumentTypeIsMandatoryOrNot() {
    this.isMandatory = false;
    this.isShowUpload = false;
    this.instructionMessage = '';
    this.title = '';
    if (this.isShowUpload) {
      this.errorMessage =
        'Please take or upload a Picture of ' +
        this.selectedDocument.document_type_description +
        ' for the registration of mobile app.';
    } else {
      this.errorMessage =
        'Please take a Picture of ' +
        this.selectedDocument.document_type_description +
        ' for the registration of mobile app.';
    }
  }

  fileError(event: any) {
    this.data.constructErrorMessage(event);
  }

  clearFile() {
    this.selectedDocument = JSON.parse(
      JSON.stringify(this.selectedDocumentRAW)
    );
  }
  fileSelected(event: any) {
    this.selectedDocument.file_name = event.fileName;
    this.selectedDocument.size = event.fileSizeinBytes;
    this.selectedDocument.type = event.fileType;
    this.selectedDocument.ImageFile = event.imageFile;
  }

  async captureImage() {
    let image = await this.cameraService.captureImage();
    if (image !== '') {
      let document = {
        fileName:
          this.selectedDocument.document_type_description +
          '_' +
          this.appService.getDateTimeStamp() +
          '.jpeg',
        imageFile: image,
        fileType: 'jpeg',
        fileSizeinBytes: 0,
      };
      this.fileSelected(document);
    }
  }

  gotoNext() {
    if (this.selectedDocument.isMandatory === 'Y') {
      if (
        this.selectedDocument.ImageFile === '' ||
        !this.selectedDocument.ImageFile ||
        this.selectedDocument.file_name === '' ||
        !this.selectedDocument.file_name
      ) {
        if (this.selectedDocument.withdrawal_application_document_id <= 0) {
          this.data.constructErrorMessage(
            'Please take or upload a photo of the ' +
              this.selectedDocument.document_type_description
          );
          return;
        }
      }
    }

    this.selectedDocument.withdrawal_application_id =
      this.governmentAssistanceService.governmentAssistance.withdrawal_application_id;
    this.applicationService
      .saveGovernmentAssistanceApplicationDocument(this.selectedDocument)
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.governmentAssistanceService.governmentAssistance.ilstbusUIAppWithdrawalApplicationDocuments[
            this.documentIndex
          ] = success;

          if (
            this.governmentAssistanceService.governmentAssistance
              .ilstbusUIAppWithdrawalApplicationDocuments.length -
              1 >
            this.documentIndex
          ) {
            this.documentIndex = this.documentIndex + 1;
            this.selectedDocument = JSON.parse(
              JSON.stringify(
                this.governmentAssistanceService.governmentAssistance
                  .ilstbusUIAppWithdrawalApplicationDocuments[
                  this.documentIndex
                ]
              )
            );
          } else {
            this.router.navigateByUrl(
              '/home/make-withdrawl/government-assistance/government-assistance-step10'
            );
          }
        }
      });
  }
  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }

  goToHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
  goNext() {
    this.router.navigateByUrl(
      '/home/make-withdrawl/government-assistance/government-assistance-step12'
    );
  }
}
