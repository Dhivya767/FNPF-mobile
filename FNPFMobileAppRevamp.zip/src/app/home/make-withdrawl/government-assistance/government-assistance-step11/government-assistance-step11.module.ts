import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { GovernmentAssistanceStep11PageRoutingModule } from './government-assistance-step11-routing.module';

import { GovernmentAssistanceStep11Page } from './government-assistance-step11.page';
import { MessagesModule } from '../../../../app-core/template/messages/messages.module';
import { FileUploadComponent } from '../../../../app-core/template/file-upload/file-upload.component';

@NgModule({
  declarations: [GovernmentAssistanceStep11Page],
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    GovernmentAssistanceStep11PageRoutingModule,
    MessagesModule,
    FileUploadComponent,
  ],
})
export class GovernmentAssistanceStep11PageModule {}
