import { ComponentFixture, TestBed } from '@angular/core/testing';
import { GovernmentAssistanceStep11Page } from './government-assistance-step11.page';

describe('GovernmentAssistanceStep11Page', () => {
  let component: GovernmentAssistanceStep11Page;
  let fixture: ComponentFixture<GovernmentAssistanceStep11Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(GovernmentAssistanceStep11Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
