import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { GovernmentAssistanceStep11Page } from './government-assistance-step11.page';

const routes: Routes = [
  {
    path: '',
    component: GovernmentAssistanceStep11Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class GovernmentAssistanceStep11PageRoutingModule {}
