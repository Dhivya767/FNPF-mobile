import { ComponentFixture, TestBed } from '@angular/core/testing';
import { GovernmentAssistanceStep13Page } from './government-assistance-step13.page';

describe('GovernmentAssistanceStep13Page', () => {
  let component: GovernmentAssistanceStep13Page;
  let fixture: ComponentFixture<GovernmentAssistanceStep13Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(GovernmentAssistanceStep13Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
