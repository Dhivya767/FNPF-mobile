import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from 'src/app/app.service';
import { busUIMemberProfile } from 'src/app/common/api-services/admin-api/admin-api.classes';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { MicrobusinessAssistanceService } from '../../partial-withdrawl/microbusiness-assistance/microbusiness-assistance.service';
import { GovernmentAssistanceService } from '../government-assistance.service';

@Component({
  selector: 'app-government-assistance-step13',
  templateUrl: './government-assistance-step13.page.html',
  styleUrls: ['./government-assistance-step13.page.scss'],
})
export class GovernmentAssistanceStep13Page implements OnInit {
  isEmail = true;
  isMobile = false;
  memProfile = new busUIMemberProfile();
  constructor(
    public router: Router,
    public governmentAssistanceService: GovernmentAssistanceService,
    public appService: AppService,
    public applicationService: ApplicationApiService,
    public data: DataService
  ) {
    this.memProfile = this.governmentAssistanceService.memProfile;
    this.isEmail = false;
    this.isMobile = false;
    if (this.memProfile.email_id.length > 0) {
      this.isEmail = true;
    }
    if (this.memProfile.masked_contactno.length > 0) {
      this.isMobile = true;
    }
  }

  ngOnInit() {}
  goToHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
  sendOTPToEmailForGovernmentAssistance() {
    let obj = {
      istApplicationId:
        this.governmentAssistanceService.governmentAssistance
          .withdrawal_application_id,
      istrEmailId: this.memProfile.email_id,
    };
    this.applicationService
      .sendOTPToEmailForGovernmentAssistance(obj)
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
          this.data.getErrorMessageByCode('ICSWD', this.appService.appMessages);
        } else {
          this.governmentAssistanceService.governmentAssistance.otp =
            success.otp;
          this.governmentAssistanceService.governmentAssistance.otp_generated_time =
            success.otp_generated_time;
          this.governmentAssistanceService.emailTo = 'Email';
          this.router.navigateByUrl(
            '/home/make-withdrawl/government-assistance/government-assistance-step14'
          );
        }
      });
  }
  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
  sendOTPToMobileForGovernmentAssistance() {
    let obj = {
      istApplicationId:
        this.governmentAssistanceService.governmentAssistance
          .withdrawal_application_id,
      istrMobileId: this.memProfile.mobile_no,
    };
    this.applicationService
      .sendOTPToMobileForGovernmentAssistance(obj)
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
          this.data.getErrorMessageByCode('ICSWD', this.appService.appMessages);
        } else {
          this.governmentAssistanceService.governmentAssistance.otp =
            success.otp;
          this.governmentAssistanceService.governmentAssistance.otp_generated_time =
            success.otp_generated_time;
          this.governmentAssistanceService.emailTo = 'Mobile';
          this.router.navigateByUrl(
            '/home/make-withdrawl/government-assistance/government-assistance-step14'
          );
        }
      });
  }
}
