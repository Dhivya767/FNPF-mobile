import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { GovernmentAssistanceStep13PageRoutingModule } from './government-assistance-step13-routing.module';

import { GovernmentAssistanceStep13Page } from './government-assistance-step13.page';
import { MessagesModule } from "../../../../app-core/template/messages/messages.module";

@NgModule({
    declarations: [GovernmentAssistanceStep13Page],
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        GovernmentAssistanceStep13PageRoutingModule,
        MessagesModule
    ]
})
export class GovernmentAssistanceStep13PageModule {}
