import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from 'src/app/app.service';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { GovernmentAssistanceService } from '../government-assistance.service';

@Component({
  selector: 'app-government-assistance-step1',
  templateUrl: './government-assistance-step1.page.html',
  styleUrls: ['./government-assistance-step1.page.scss'],
})
export class GovernmentAssistanceStep1Page implements OnInit {
  errorTrue = false;
  errorMessages = {};
  ddlGenderValue: any = [];
  constructor(
    public router: Router,
    public governmentAssistanceService: GovernmentAssistanceService,
    public data: DataService,
    public appService: AppService,
    public applicationService: ApplicationApiService
  ) {
    this.ddlGenderValue = this.governmentAssistanceService.DDL.ddlGenderValue;
  }

  ngOnInit() {}
  goHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
  gotoNext() {
    this.applicationService
      .saveGovernmentAssistanceApplication(
        this.governmentAssistanceService.governmentAssistance
      )
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.governmentAssistanceService.governmentAssistance = success;
          this.router.navigateByUrl(
            '/home/make-withdrawl/government-assistance/government-assistance-step2'
          );
        }
      });
  }
  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
}
