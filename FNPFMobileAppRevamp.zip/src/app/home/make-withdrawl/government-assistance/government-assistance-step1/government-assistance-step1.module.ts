import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { GovernmentAssistanceStep1PageRoutingModule } from './government-assistance-step1-routing.module';

import { GovernmentAssistanceStep1Page } from './government-assistance-step1.page';
import { FormInputModule } from 'src/app/app-core/form-input/form-input.module';
import { MessagesModule } from 'src/app/app-core/template/messages/messages.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    GovernmentAssistanceStep1PageRoutingModule,
    FormInputModule,
    MessagesModule,
  ],
  declarations: [GovernmentAssistanceStep1Page],
})
export class GovernmentAssistanceStep1PageModule {}
