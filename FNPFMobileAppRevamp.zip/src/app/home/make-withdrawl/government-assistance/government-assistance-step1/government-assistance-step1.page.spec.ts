import { ComponentFixture, TestBed } from '@angular/core/testing';
import { GovernmentAssistanceStep1Page } from './government-assistance-step1.page';

describe('GovernmentAssistanceStep1Page', () => {
  let component: GovernmentAssistanceStep1Page;
  let fixture: ComponentFixture<GovernmentAssistanceStep1Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(GovernmentAssistanceStep1Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
