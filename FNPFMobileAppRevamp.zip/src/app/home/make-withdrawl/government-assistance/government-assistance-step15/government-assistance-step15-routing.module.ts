import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { GovernmentAssistanceStep15Page } from './government-assistance-step15.page';

const routes: Routes = [
  {
    path: '',
    component: GovernmentAssistanceStep15Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class GovernmentAssistanceStep15PageRoutingModule {}
