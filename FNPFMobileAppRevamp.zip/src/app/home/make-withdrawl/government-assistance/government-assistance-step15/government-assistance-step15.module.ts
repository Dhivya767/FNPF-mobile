import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { GovernmentAssistanceStep15PageRoutingModule } from './government-assistance-step15-routing.module';

import { GovernmentAssistanceStep15Page } from './government-assistance-step15.page';
import { MessagesModule } from "../../../../app-core/template/messages/messages.module";
import { RatingComponent } from "../../../../app-core/template/rating/rating.component";

@NgModule({
    declarations: [GovernmentAssistanceStep15Page],
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        GovernmentAssistanceStep15PageRoutingModule,
        MessagesModule,
        RatingComponent
    ]
})
export class GovernmentAssistanceStep15PageModule {}
