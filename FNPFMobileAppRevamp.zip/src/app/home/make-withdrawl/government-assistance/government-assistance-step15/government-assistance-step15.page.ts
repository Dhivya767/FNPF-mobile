import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-government-assistance-step15',
  templateUrl: './government-assistance-step15.page.html',
  styleUrls: ['./government-assistance-step15.page.scss'],
})
export class GovernmentAssistanceStep15Page implements OnInit {

  constructor(
    public router : Router
  ) { }

  ngOnInit() {
  }
  DownloadRegistrationForm(){}
  GoToWithdrawalHistory(){}
  goToHome(){
    this.router.navigateByUrl('/home')
  }
}
