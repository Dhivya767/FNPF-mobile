import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from 'src/app/app.service';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { GovernmentAssistanceService } from '../government-assistance.service';
import { busUIMemberProfile } from 'src/app/common/api-services/application-api/application-api.classes';

@Component({
  selector: 'app-government-assistance-step6',
  templateUrl: './government-assistance-step6.page.html',
  styleUrls: ['./government-assistance-step6.page.scss'],
})
export class GovernmentAssistanceStep6Page implements OnInit {
  selectedBankId: any;
  errorTrue = false;
  banks: any = [];
  previouslyUsedBanks: any = [];
  bankOrgId = 0;
  isTermsAccepted = false;
  selectedBankOrgId: any;
  memProfile = new busUIMemberProfile();
  selectedBankAccountNumber = '';
  isNewBankDetail = false;
  isNoBankSelected = false;
  PostOffices: any[];
  additionalBankOption = {
    bank_account_id: null,
    bank_name: 'I have a new bank account.',
    bank_org_ref_no: '',
    bank_org_id: '',
    account_number: '',
    bank_id: '',
  };
  constructor(
    public appService: AppService,
    public router: Router,
    public governmentAssistanceService: GovernmentAssistanceService,
    public data: DataService,
    public applicationService: ApplicationApiService
  ) {
    this.isNewBankDetail = false;
    this.selectedBankOrgId = '0';
    this.selectedBankId = '0';

    this.memProfile = this.governmentAssistanceService.memProfile;
    this.PostOffices = this.governmentAssistanceService.DDL.PostOffices;
    this.banks = this.governmentAssistanceService.DDL.Banks;
    this.previouslyUsedBanks =
      this.governmentAssistanceService.DDL.PreviouslyUsedBanks;
    this.isTermsAccepted = false;

    if (
      this.governmentAssistanceService.governmentAssistance
        .ibusUIAppWithdrawalUnemploymentAdditionalInfo
    ) {
      this.selectedBankId =
        this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_account_id;
    } else {
      this.selectedBankId = '0';
    }
    if (
      this.governmentAssistanceService.governmentAssistance
        .ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_org_id === 0
    ) {
      this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_org_id = 0;
    }
    if (
      !this.governmentAssistanceService.governmentAssistance
        .ibusUIAppWithdrawalUnemploymentAdditionalInfo.account_name
    ) {
      this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.account_name =
        this.appService.memProfile.full_name;
    }
  }

  ngOnInit() {
    this.loadDefaultValuesIfExists();
    this.loadCheckbox();
    this.loadNoBank();
    this.loadPaymentModeDDLForGovernmentAssistanceApplication();
  }

  loadCheckbox() {
    if (
      this.governmentAssistanceService.governmentAssistance
        .ibusUIAppWithdrawalUnemploymentAdditionalInfo
        .is_payment_deposits_agree === 'Y'
    ) {
      this.isTermsAccepted = true;
    }
  }
  loadNoBank() {
    if (
      this.governmentAssistanceService.governmentAssistance
        .no_bank_account_flag == 'Y'
    ) {
      this.isNoBankSelected = true;
    }
  }

  loadDefaultValuesIfExists() {
    this.previouslyUsedBanks.push(this.additionalBankOption);

    if (
      this.governmentAssistanceService.governmentAssistance
        .ibusUIAppWithdrawalUnemploymentAdditionalInfo.payment_mode_value !==
      'DDBA'
    ) {
      if (
        this.governmentAssistanceService.governmentAssistance
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo
          .payment_to_mobile_no === '' ||
        !this.governmentAssistanceService.governmentAssistance
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo.payment_to_mobile_no
      ) {
        this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.payment_to_mobile_no =
          this.governmentAssistanceService.governmentAssistance.member_contact_no;
      }
    }
  }
  loadPaymentModeDDLForGovernmentAssistanceApplication() {
    if (this.governmentAssistanceService.governmentAssistance) {
      this.applicationService
        .loadPaymentModeDDLForGovernmentAssistanceApplication(
          this.governmentAssistanceService.governmentAssistance
        )
        .subscribe((success: any) => {
          if (success?.ilstErrorMessages?.length > 0) {
            this.data.getErrorMessageByCode(
              'ICSWD',
              this.appService.appMessages
            );
          } else {
            this.banks =
              this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.ilstUIBanks;
            this.previouslyUsedBanks =
              this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.ilstUIPreviouslyUsedBank;
          }
        });
    }
  }
  goHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
  goNext() {
    if (
      this.governmentAssistanceService.governmentAssistance
        .payment_mode_value === 'DDBA'
    ) {
      if (!this.isNoBankSelected) {
        if (
          !this.governmentAssistanceService.governmentAssistance
            .ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_org_id ||
          this.governmentAssistanceService.governmentAssistance
            .ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_org_id === 0
        ) {
          this.data.getErrorMessageByCode('PSBKD', this.appService.appMessages);
          return;
        }

        if (
          this.governmentAssistanceService.governmentAssistance
            .ibusUIAppWithdrawalUnemploymentAdditionalInfo.account_no === '' ||
          !this.governmentAssistanceService.governmentAssistance
            .ibusUIAppWithdrawalUnemploymentAdditionalInfo.account_no
        ) {
          this.data.getErrorMessageByCode('PPACN', this.appService.appMessages);
          return;
        }

        if (this.selectedBankId !== 0) {
          if (
            this.selectedBankAccountNumber !== '' &&
            this.selectedBankAccountNumber
          ) {
            if (
              this.selectedBankAccountNumber.toLowerCase() !==
              this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.account_no.toLowerCase()
            ) {
              this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_account_id = 0;
            }
          }
        }
      } else {
        this.governmentAssistanceService.governmentAssistance.no_bank_account_flag =
          'Y';
      }
    } else if (
      this.governmentAssistanceService.governmentAssistance
        .payment_mode_value === 'PTMO'
    ) {
      let MobileNo =
        this.governmentAssistanceService.governmentAssistance
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo.payment_to_mobile_no;

      if (!MobileNo) {
        this.data.getErrorMessageByCode('PPPNO', this.appService.appMessages);
        return;
      } else {
        if (MobileNo?.length !== 7) {
          this.data.getErrorMessageByCode('YPNMD', this.appService.appMessages);
          return;
        }
      }
    } else if (
      this.governmentAssistanceService.governmentAssistance
        .payment_mode_value === 'PMMT'
    ) {
      let mobileNo =
        this.governmentAssistanceService.governmentAssistance
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo.payment_to_mobile_no;
      if (!mobileNo) {
        this.data.getErrorMessageByCode('PPMBO', this.appService.appMessages);
        return;
      } else {
        if (mobileNo.length !== 7) {
          this.data.getErrorMessageByCode('YMNMD', this.appService.appMessages);
          return;
        }
      }
    } else if (
      this.governmentAssistanceService.governmentAssistance
        .payment_mode_value === 'TLTR'
    ) {
      if (
        !this.governmentAssistanceService.governmentAssistance
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_name ||
        this.governmentAssistanceService.governmentAssistance
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_name === '' ||
        this.governmentAssistanceService.governmentAssistance
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_name.length === 0
      ) {
        this.data.constructErrorMessage('Please enter bank name.');
        return;
      }

      if (
        !this.governmentAssistanceService.governmentAssistance
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo.account_no ||
        this.governmentAssistanceService.governmentAssistance
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo.account_no === '' ||
        this.governmentAssistanceService.governmentAssistance
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo.account_no.length === 0
      ) {
        //Please provide an Account Number.
        this.data.getErrorMessageByCode('PPACN', this.appService.appMessages);
        return;
      }

      if (
        !this.governmentAssistanceService.governmentAssistance
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo.bsb_routing_no ||
        this.governmentAssistanceService.governmentAssistance
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo.bsb_routing_no ===
          '' ||
        this.governmentAssistanceService.governmentAssistance
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo.bsb_routing_no
          .length === 0
      ) {
        this.data.getErrorMessageByCode('27', this.appService.appMessages);
        return;
      }

      if (
        !this.governmentAssistanceService.governmentAssistance
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo.swift_code ||
        this.governmentAssistanceService.governmentAssistance
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo.swift_code === '' ||
        this.governmentAssistanceService.governmentAssistance
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo.swift_code.length === 0
      ) {
        this.data.getErrorMessageByCode('28', this.appService.appMessages);
        return;
      }

      if (
        !this.governmentAssistanceService.governmentAssistance
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_address ||
        this.governmentAssistanceService.governmentAssistance
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_address === '' ||
        this.governmentAssistanceService.governmentAssistance
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_address.length ===
          0
      ) {
        this.data.getErrorMessageByCode('29', this.appService.appMessages);
        return;
      }

      if (
        this.selectedBankId &&
        this.selectedBankId !== '' &&
        this.selectedBankId !== '0'
      ) {
        if (
          this.selectedBankAccountNumber &&
          this.selectedBankAccountNumber !== '' &&
          this.selectedBankAccountNumber.length > 0
        ) {
          if (
            this.selectedBankAccountNumber.toLowerCase() !==
            this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.account_no.toLowerCase()
          ) {
            this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_account_id = 0;
          }
        }
      }
    }
    if (!this.isNoBankSelected) {
      if (this.isTermsAccepted) {
        this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.is_payment_deposits_agree =
          'Y';
      } else {
        //You must confirm to the above  by selecting the check-box to proceed.
        this.data.getErrorMessageByCode('YMCTP', this.appService.appMessages);
        this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.is_payment_deposits_agree =
          'N';
        return;
      }
    }
    this.updateApplication();
  }
  updateApplication() {
    this.applicationService
      .updateGovernmentAssistanceApplication(
        this.governmentAssistanceService.governmentAssistance
      )
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.data.getErrorMessageByCode('ICSWD', this.appService.appMessages);
        } else {
          this.governmentAssistanceService.governmentAssistance = success;
          this.router.navigateByUrl(
            '/home/make-withdrawl/government-assistance/government-assistance-step7'
          );
        }
      });
  }

  checkIfBankStatementMandatoryOrNot() {
    this.applicationService
      .checkIfIsNormalUnemploymentDocumentMandatoryOrNot(
        this.governmentAssistanceService.governmentAssistance
      )
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.isDocumentMandatory =
            'N';
          this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.ibusUIBankStatement.isMandatory =
            'N';
          this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.isDocumentMandatory =
            success.ibusUIAppWithdrawalUnemploymentAdditionalInfo.isDocumentMandatory;
          debugger;
          if (
            this.governmentAssistanceService.governmentAssistance
              .ibusUIAppWithdrawalUnemploymentAdditionalInfo
              .isDocumentMandatory === 'Y'
          ) {
            this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.ibusUIBankStatement.isMandatory =
              'Y';
          }
          this.router.navigateByUrl(
            '/home/make-withdrawl/partial-withdrawl/unemployment-assistance/unemployment-assistance-step7'
          );
        }
      });
  }
  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
  checkIfTerminationLetterIsMandatoryOrNot() {
    this.applicationService
      .checkIfIsNormalUnemploymentDocumentMandatoryOrNot(
        this.governmentAssistanceService.governmentAssistance
      )
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.isDocumentMandatory =
            'N';
          this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.ibusUIBankStatement.isMandatory =
            'N';
          this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.isDocumentMandatory =
            success.ibusUIAppWithdrawalUnemploymentAdditionalInfo.isDocumentMandatory;

          if (
            this.governmentAssistanceService.governmentAssistance
              .ibusUIAppWithdrawalUnemploymentAdditionalInfo
              .isDocumentMandatory === 'Y'
          )
            this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.ibusUIBankStatement.isMandatory =
              'Y';

          this.router.navigateByUrl(
            '/home/make-withdrawl/partial-withdrawl/unemployment-assistance/unemployment-assistance-step8'
          );
        }
      });
  }
  onChangePreviouslyUsedBank(accountId: any) {
    if (accountId === '' || !accountId) {
      this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_name =
        '';
      this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_org_ref_no =
        '';
      this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_org_id = 0;
      this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_account_id = 0;
      this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.account_no =
        '';
      this.selectedBankAccountNumber = '';
      this.selectedBankOrgId = 0;
      this.isNewBankDetail = true;
      return;
    } else {
      this.isNewBankDetail = false;
    }

    if (this.previouslyUsedBanks?.length > 0) {
      for (let i = 0; i < this.previouslyUsedBanks.length; i++) {
        if (this.previouslyUsedBanks[i].bank_account_id === accountId) {
          this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_name =
            this.previouslyUsedBanks[i].bank_name;
          this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_org_ref_no =
            this.previouslyUsedBanks[i].bank_org_ref_no;
          this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_org_id =
            this.previouslyUsedBanks[i].bank_id;
          this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_account_id =
            this.previouslyUsedBanks[i].bank_account_id;
          this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.account_no =
            this.previouslyUsedBanks[i].account_number;
          this.selectedBankAccountNumber =
            this.previouslyUsedBanks[i].account_number;
          this.selectedBankOrgId = this.previouslyUsedBanks[i].bank_id;
          return;
        }
      }
    }
  }
  onChangeBank(bankOrgId: any) {
    if (this.banks.length > 0) {
      for (let i = 0; i < this.banks.length; i++) {
        if (this.banks[i].config_id === bankOrgId) {
          this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_org_id =
            this.banks[i].config_id;
          this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_org_ref_no =
            this.banks[i].config_constant;
          this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_name =
            this.banks[i].config_const_description;

          if (
            this.selectedBankOrgId !==
            this.governmentAssistanceService.governmentAssistance
              .ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_org_id
          ) {
            if (this.selectedBankId !== 0) {
              this.selectedBankId = 0;
            }

            this.selectedBankAccountNumber = '';
            this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.account_no =
              '';
          }

          return;
        }
      }
    }
  }

  onChangeAccountNo(accountNo: any) {
    let actNo = accountNo;
    let bankName =
      this.governmentAssistanceService.governmentAssistance
        .ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_name;
    let orgRefNo =
      this.governmentAssistanceService.governmentAssistance
        .ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_org_ref_no;
    this.checkAccountNo(actNo, bankName, orgRefNo);
  }

  checkAccountNo(actNo: any, bankName: any, orgRefNo: any) {
    if (actNo.length > 0 && bankName.length > 0) {
      let IsValid = true;

      if (
        bankName.includes('WESTPAC BANKING CORP') ||
        orgRefNo == 'EN10126491H'
      ) {
        if (actNo.length < 8 || actNo.length > 10) {
          IsValid = false;
        }
        if (!this.isValidAccount(actNo)) {
          IsValid = false;
        }

        if (!IsValid) {
          this.data.getErrorMessageByCode('NWPBA', this.appService.appMessages);
          return;
        }
      } else if (
        bankName.includes('ANZ BANKING GRP LTD') ||
        orgRefNo == 'EN10126488U'
      ) {
        if (actNo.length < 6 || actNo.length > 8) {
          IsValid = false;
        }
        if (!this.isValidAccount(actNo)) {
          IsValid = false;
        }
        if (!IsValid) {
          this.data.getErrorMessageByCode('NAZBA', this.appService.appMessages);
          return;
        }
      } else if (
        bankName.includes('BANK OF BARODA') ||
        orgRefNo == 'EN10126492K'
      ) {
        if (actNo.length != 14) {
          IsValid = false;
        }
        if (!this.isValidAccount(actNo)) {
          IsValid = false;
        }
        if (!IsValid) {
          this.data.getErrorMessageByCode('NBOBA', this.appService.appMessages);
          return;
        }
      } else if (
        bankName.includes('HOME FINANCE COMPANY LIMITED') ||
        orgRefNo == 'EN10010979G'
      ) {
        if (actNo.length < 6 || actNo.length > 8) {
          IsValid = false;
        }
        if (this.checkCharacter('s', actNo) == -1) {
          IsValid = false;
        }
        let RemovedString = this.removeCharacter('s', actNo);
        if (!this.isValidAccount(RemovedString)) {
          IsValid = false;
        }

        if (!IsValid) {
          this.data.getErrorMessageByCode('NHFCA', this.appService.appMessages);
          return;
        }
      } else if (
        bankName.includes('BANK OF SOUTH PACIFIC') ||
        orgRefNo == 'EN10126489W'
      ) {
        if (actNo.length < 7 || actNo.length > 8) {
          IsValid = false;
        }
        if (!this.isValidAccount(actNo)) {
          IsValid = false;
        }

        if (!IsValid) {
          this.data.getErrorMessageByCode('NBSPA', this.appService.appMessages);
          return;
        }
      } else if (
        bankName.includes('BRED BANK (FIJI) LIMITED') ||
        orgRefNo == 'EN10021248B'
      ) {
        if (actNo.length != 11) {
          IsValid = false;
        }
        if (!this.isValidAccount(actNo)) {
          IsValid = false;
        }

        if (!IsValid) {
          this.data.getErrorMessageByCode('NBRDA', this.appService.appMessages);
          return;
        }
      }
    }
  }
  public removeCharacter(Character: any, string: any) {
    let Account = string.toLowerCase();
    let Char = Character.toLowerCase();
    let reg = new RegExp(Char);
    return Account.replace(reg, '');
  }

  public checkCharacter(Character: any, string: any) {
    let Account = string.toLowerCase();
    let Char = Character.toLowerCase();

    return Account.indexOf(Char);
  }
  public isValidAccount(AccountNo: any) {
    var NumericValidation = /^[0-9()+]+$/;
    return NumericValidation.test(AccountNo);
  }
  onClickTerms(val: any) {
    if (val.detail.checked) {
      this.isTermsAccepted = true;
    } else {
      this.isTermsAccepted = false;
    }
  }

  onClickNoBank(val: any) {
    if (val) {
      this.isNoBankSelected = true;
      this.governmentAssistanceService.governmentAssistance.ibusUIWithdrawalApplicationPaymentInfo.bank_org_id = 0;
      this.governmentAssistanceService.governmentAssistance.ibusUIWithdrawalApplicationPaymentInfo.account_no =
        '';
      this.governmentAssistanceService.governmentAssistance.ibusUIWithdrawalApplicationPaymentInfo.bank_name =
        '';
      this.governmentAssistanceService.governmentAssistance.ibusUIWithdrawalApplicationPaymentInfo.bank_account_id = 0;
      this.selectedBankId = 0;
    } else {
      this.isNoBankSelected = false;
    }
  }
}
