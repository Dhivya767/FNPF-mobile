import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { GovernmentAssistanceStep6PageRoutingModule } from './government-assistance-step6-routing.module';

import { GovernmentAssistanceStep6Page } from './government-assistance-step6.page';
import { MessagesModule } from 'src/app/app-core/template/messages/messages.module';
import { FormInputModule } from 'src/app/app-core/form-input/form-input.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    GovernmentAssistanceStep6PageRoutingModule,
    MessagesModule,
    FormInputModule,
  ],
  declarations: [GovernmentAssistanceStep6Page],
})
export class GovernmentAssistanceStep6PageModule {}
