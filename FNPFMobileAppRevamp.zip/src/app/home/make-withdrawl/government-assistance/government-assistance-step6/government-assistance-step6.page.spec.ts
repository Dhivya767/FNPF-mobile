import { ComponentFixture, TestBed } from '@angular/core/testing';
import { GovernmentAssistanceStep6Page } from './government-assistance-step6.page';

describe('GovernmentAssistanceStep6Page', () => {
  let component: GovernmentAssistanceStep6Page;
  let fixture: ComponentFixture<GovernmentAssistanceStep6Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(GovernmentAssistanceStep6Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
