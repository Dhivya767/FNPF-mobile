import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { GovernmentAssistanceStep6Page } from './government-assistance-step6.page';

const routes: Routes = [
  {
    path: '',
    component: GovernmentAssistanceStep6Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class GovernmentAssistanceStep6PageRoutingModule {}
