import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-government-assistance-step16',
  templateUrl: './government-assistance-step16.page.html',
  styleUrls: ['./government-assistance-step16.page.scss'],
})
export class GovernmentAssistanceStep16Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
