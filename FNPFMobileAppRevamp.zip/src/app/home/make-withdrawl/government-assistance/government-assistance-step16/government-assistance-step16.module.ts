import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { GovernmentAssistanceStep16PageRoutingModule } from './government-assistance-step16-routing.module';

import { GovernmentAssistanceStep16Page } from './government-assistance-step16.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    GovernmentAssistanceStep16PageRoutingModule
  ],
  declarations: [GovernmentAssistanceStep16Page]
})
export class GovernmentAssistanceStep16PageModule {}
