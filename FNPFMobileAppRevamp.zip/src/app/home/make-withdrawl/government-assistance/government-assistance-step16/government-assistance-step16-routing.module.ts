import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { GovernmentAssistanceStep16Page } from './government-assistance-step16.page';

const routes: Routes = [
  {
    path: '',
    component: GovernmentAssistanceStep16Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class GovernmentAssistanceStep16PageRoutingModule {}
