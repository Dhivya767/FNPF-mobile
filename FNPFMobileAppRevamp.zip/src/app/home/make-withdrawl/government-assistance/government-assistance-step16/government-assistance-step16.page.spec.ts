import { ComponentFixture, TestBed } from '@angular/core/testing';
import { GovernmentAssistanceStep16Page } from './government-assistance-step16.page';

describe('GovernmentAssistanceStep16Page', () => {
  let component: GovernmentAssistanceStep16Page;
  let fixture: ComponentFixture<GovernmentAssistanceStep16Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(GovernmentAssistanceStep16Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
