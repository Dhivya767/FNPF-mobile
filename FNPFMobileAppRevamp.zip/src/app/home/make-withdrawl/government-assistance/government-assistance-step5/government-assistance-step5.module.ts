import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { GovernmentAssistanceStep5PageRoutingModule } from './government-assistance-step5-routing.module';

import { GovernmentAssistanceStep5Page } from './government-assistance-step5.page';
import { MessagesModule } from 'src/app/app-core/template/messages/messages.module';
import { FormInputModule } from 'src/app/app-core/form-input/form-input.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    GovernmentAssistanceStep5PageRoutingModule,
    MessagesModule,
    FormInputModule,
  ],
  declarations: [GovernmentAssistanceStep5Page],
})
export class GovernmentAssistanceStep5PageModule {}
