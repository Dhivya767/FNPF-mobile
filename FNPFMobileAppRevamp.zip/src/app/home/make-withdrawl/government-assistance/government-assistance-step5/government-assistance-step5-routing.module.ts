import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { GovernmentAssistanceStep5Page } from './government-assistance-step5.page';

const routes: Routes = [
  {
    path: '',
    component: GovernmentAssistanceStep5Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class GovernmentAssistanceStep5PageRoutingModule {}
