import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from 'src/app/app.service';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { GovernmentAssistanceService } from '../government-assistance.service';

@Component({
  selector: 'app-government-assistance-step5',
  templateUrl: './government-assistance-step5.page.html',
  styleUrls: ['./government-assistance-step5.page.scss'],
})
export class GovernmentAssistanceStep5Page implements OnInit {
  errorTrue = false;
  errorMessages = {};
  ddlPaymentModeValue: any = [];
  constructor(
    public router: Router,
    public governmentAssistanceService: GovernmentAssistanceService,
    public data: DataService,
    public appService: AppService,
    public applicationService: ApplicationApiService
  ) {
    this.ddlPaymentModeValue =
      this.governmentAssistanceService.DDL.ddlPaymentModeValue;
  }

  ngOnInit() {}
  goHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
  gotoNext() {
    if (
      !this.governmentAssistanceService.governmentAssistance
        .payment_mode_value ||
      this.governmentAssistanceService.governmentAssistance
        .payment_mode_value === '' ||
      this.governmentAssistanceService.governmentAssistance.payment_mode_value
        .length === 0
    ) {
      this.data.getErrorMessageByCode('23', this.appService.appMessages);
      return;
    }
    this.applicationService
      .saveGovernmentAssistanceApplication(
        this.governmentAssistanceService.governmentAssistance
      )
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.governmentAssistanceService.governmentAssistance = success;
          this.router.navigateByUrl(
            '/home/make-withdrawl/government-assistance/government-assistance-step6'
          );
        }
      });
  }
  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
}
