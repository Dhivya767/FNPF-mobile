import { ComponentFixture, TestBed } from '@angular/core/testing';
import { GovernmentAssistanceStep5Page } from './government-assistance-step5.page';

describe('GovernmentAssistanceStep5Page', () => {
  let component: GovernmentAssistanceStep5Page;
  let fixture: ComponentFixture<GovernmentAssistanceStep5Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(GovernmentAssistanceStep5Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
