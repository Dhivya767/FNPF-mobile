import { TestBed } from '@angular/core/testing';

import { GovernmentAssistanceService } from './government-assistance.service';

describe('GovernmentAssistanceService', () => {
  let service: GovernmentAssistanceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GovernmentAssistanceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
