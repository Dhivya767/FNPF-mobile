import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from 'src/app/app.service';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { GovernmentAssistanceService } from '../government-assistance.service';

@Component({
  selector: 'app-government-assistance-step2',
  templateUrl: './government-assistance-step2.page.html',
  styleUrls: ['./government-assistance-step2.page.scss'],
})
export class GovernmentAssistanceStep2Page implements OnInit {
  errorTrue = false;
  errorMessages = {};
  constructor(
    public router: Router,
    public governmentAssistanceService: GovernmentAssistanceService,
    public data: DataService,
    public appService: AppService,
    public applicationService: ApplicationApiService
  ) {}

  ngOnInit() {}
  restrictSpecialChars(event: any) {
    let newValue = event.target.value;
    let regExp = new RegExp('^[A-Za-z0-9? ]+$');
    if (!regExp.test(newValue)) {
      event.target.value = newValue.slice(0, -1);
    }
  }
  gotoNext() {
    if (
      this.governmentAssistanceService.governmentAssistance.IsTinMandatory ===
      'Y'
    ) {
      if (
        !this.governmentAssistanceService.governmentAssistance.tin ||
        this.governmentAssistanceService.governmentAssistance.tin === '' ||
        this.governmentAssistanceService.governmentAssistance.tin.length === 0
      ) {
        this.data.getErrorMessageByCode('7', this.appService.appMessages);
        return;
      }
    }

    if (
      this.governmentAssistanceService.governmentAssistance.IsBrnMandatory ===
      'Y'
    ) {
      if (
        this.governmentAssistanceService.governmentAssistance.brn ||
        this.governmentAssistanceService.governmentAssistance.brn === '' ||
        this.governmentAssistanceService.governmentAssistance.brn.length === 0
      ) {
        this.data.getErrorMessageByCode('8', this.appService.appMessages);
        return;
      }
    }

    if (
      this.governmentAssistanceService.governmentAssistance
        .IsVoterRegNoMandatory === 'Y'
    ) {
      if (
        !this.governmentAssistanceService.governmentAssistance
          .ibusUIGovernmentAssistanceAdditionalInfo.voter_reg_no ||
        this.governmentAssistanceService.governmentAssistance
          .ibusUIGovernmentAssistanceAdditionalInfo.voter_reg_no === '' ||
        this.governmentAssistanceService.governmentAssistance
          .ibusUIGovernmentAssistanceAdditionalInfo.voter_reg_no.length === 0
      ) {
        this.data.constructErrorMessage('Please enter voter reg number');
        return;
      }
      this.applicationService
        .saveGovernmentAssistanceApplication(
          this.governmentAssistanceService.governmentAssistance
        )
        .subscribe((success: any) => {
          if (success?.ilstErrorMessages?.length > 0) {
            this.checkForError(success);
          } else {
            this.governmentAssistanceService.governmentAssistance = success;
            this.router.navigateByUrl(
              '/home/make-withdrawl/government-assistance/government-assistance-step3'
            );
          }
        });
    }
  }
  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
  goHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
}
