import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { GovernmentAssistanceStep2PageRoutingModule } from './government-assistance-step2-routing.module';

import { GovernmentAssistanceStep2Page } from './government-assistance-step2.page';
import { MessagesModule } from 'src/app/app-core/template/messages/messages.module';
import { FormInputModule } from 'src/app/app-core/form-input/form-input.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    GovernmentAssistanceStep2PageRoutingModule,
    MessagesModule,
    FormInputModule,
  ],
  declarations: [GovernmentAssistanceStep2Page],
})
export class GovernmentAssistanceStep2PageModule {}
