import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { GovernmentAssistanceStep2Page } from './government-assistance-step2.page';

const routes: Routes = [
  {
    path: '',
    component: GovernmentAssistanceStep2Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class GovernmentAssistanceStep2PageRoutingModule {}
