import { ComponentFixture, TestBed } from '@angular/core/testing';
import { GovernmentAssistanceStep2Page } from './government-assistance-step2.page';

describe('GovernmentAssistanceStep2Page', () => {
  let component: GovernmentAssistanceStep2Page;
  let fixture: ComponentFixture<GovernmentAssistanceStep2Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(GovernmentAssistanceStep2Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
