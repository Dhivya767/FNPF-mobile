import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { GovernmentAssistanceStep12PageRoutingModule } from './government-assistance-step12-routing.module';

import { GovernmentAssistanceStep12Page } from './government-assistance-step12.page';
import { MessagesModule } from "../../../../app-core/template/messages/messages.module";

@NgModule({
    declarations: [GovernmentAssistanceStep12Page],
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        GovernmentAssistanceStep12PageRoutingModule,
        MessagesModule
    ]
})
export class GovernmentAssistanceStep12PageModule {}
