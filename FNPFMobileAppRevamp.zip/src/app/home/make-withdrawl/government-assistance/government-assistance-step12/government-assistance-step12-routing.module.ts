import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { GovernmentAssistanceStep12Page } from './government-assistance-step12.page';

const routes: Routes = [
  {
    path: '',
    component: GovernmentAssistanceStep12Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class GovernmentAssistanceStep12PageRoutingModule {}
