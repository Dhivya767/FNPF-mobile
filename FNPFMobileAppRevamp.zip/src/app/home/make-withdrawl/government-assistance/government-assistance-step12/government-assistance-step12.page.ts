import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ModalController } from '@ionic/angular';
import { CameraService } from 'src/app/app-core/mobile-service/camera/camera.service';
import { SignatureComponent } from 'src/app/app-core/signature/signature.component';
import { AppService } from 'src/app/app.service';
import {
  busUIAppWithdrawalApplicationDocuments,
  busUIMemberProfile,
} from 'src/app/common/api-services/admin-api/admin-api.classes';
import { AdminApiService } from 'src/app/common/api-services/admin-api/admin-api.service';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { RegistrationService } from 'src/app/start/registration/registration.service';
import { MicrobusinessAssistanceService } from '../../partial-withdrawl/microbusiness-assistance/microbusiness-assistance.service';
import { GovernmentAssistanceService } from '../government-assistance.service';

@Component({
  selector: 'app-government-assistance-step12',
  templateUrl: './government-assistance-step12.page.html',
  styleUrls: ['./government-assistance-step12.page.scss'],
})
export class GovernmentAssistanceStep12Page implements OnInit {
  selectedDocument = new busUIAppWithdrawalApplicationDocuments();
  imagePath = '';
  base64Image = '';
  memProfile = new busUIMemberProfile();
  constructor(
    public router: Router,
    public modalCtrl: ModalController,
    public cameraService: CameraService,
    public data: DataService,
    public appService: AppService,
    public applicationService: ApplicationApiService,
    public modal: ModalController,
    public governmentAssistanceService: GovernmentAssistanceService
  ) {
    this.memProfile = this.governmentAssistanceService.memProfile;
    if (
      this.governmentAssistanceService.governmentAssistance
        .ibusUIAppWithdrawalApplicationMemberPhoto.ImageFile != ''
    ) {
      this.base64Image =
        this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalApplicationMemberPhoto.ImageFile;
    }
  }

  ngOnInit() {}
  fileSelected(event: any) {
    this.selectedDocument.file_name = event.fileName;
    this.selectedDocument.size = event.fileSizeinBytes;
    this.selectedDocument.type = event.fileType;
    this.selectedDocument.ImageFile = event.imageFile;
  }

  async captureImage() {
    let image = await this.cameraService.captureImage();
    if (image !== '') {
      let document = {
        fileName:
          this.selectedDocument.document_type_description +
          '_' +
          this.appService.getDateTimeStamp() +
          '.jpeg',
        imageFile: image,
        fileType: 'jpeg',
        fileSizeinBytes: 0,
      };
      this.fileSelected(document);
    }
  }

  async gotoNext() {
    if (
      this.governmentAssistanceService.governmentAssistance
        .ibusUIAppWithdrawalApplicationMemberPhoto.ImageFile === ''
    ) {
      this.data.getErrorMessageByCode('PTAPT', this.appService.appMessages);
      return;
    }

    this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalApplicationMemberPhoto.withdrawal_application_id =
      this.governmentAssistanceService.governmentAssistance.withdrawal_application_id;
    this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalApplicationMemberPhoto.document_type_value =
      'MEMPT';
    this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalApplicationMemberPhoto.document_type_id = 5106;
    this.governmentAssistanceService.governmentAssistance
      .withdrawal_application_id;
    this.saveGovernmentAssistanceApplicationDocument(
      this.governmentAssistanceService.governmentAssistance
        .ibusUIAppWithdrawalApplicationMemberPhoto
    );
  }
  saveGovernmentAssistanceApplicationDocument(document: any) {
    this.applicationService
      .saveGovernmentAssistanceApplicationDocument(
        this.governmentAssistanceService.governmentAssistance
          .ibusUIAppWithdrawalApplicationMemberPhoto
      )
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
          this.data.getErrorMessageByCode('ICSWD', this.appService.appMessages);
        } else {
          this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalApplicationMemberPhoto =
            success;
          this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalApplicationMemberPhoto =
            this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalApplicationMemberPhoto;
          this.redirectToNextPage();
          this.imagePath = '';
        }
      });
  }
  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
  redirectToNextPage() {
    this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalApplicationMemberSignature.withdrawal_application_id =
      this.governmentAssistanceService.governmentAssistance.withdrawal_application_id;
    this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalApplicationMemberSignature.document_type_value =
      'MESGN';
    this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalApplicationMemberSignature.document_type_id = 5106;
    this.saveGovtAssistanceDocumentSignature(
      this.governmentAssistanceService.governmentAssistance
        .ibusUIAppWithdrawalApplicationMemberSignature
    );
  }
  async saveGovtAssistanceDocumentSignature(val: any) {
    const modal = await this.modalCtrl.create({
      component: SignatureComponent,
      componentProps: {
        label: 'Draw your signature image',
        submitBtnText: 'Go Next',
      },
    });
    await modal.present();
    const { data } = await modal.onWillDismiss();
    if (data?.dismissed) {
      if (data.signature !== '') {
        //     this.
        // governmentAssistanceService.governmentAssistance.signature = data.signature;
        this.applicationService
          .saveGovernmentAssistanceApplicationDocument(
            this.governmentAssistanceService.governmentAssistance
              .ibusUIAppWithdrawalApplicationMemberSignature
          )
          .subscribe((success: any) => {
            if (success?.ilstErrorMessages?.length > 0) {
              this.checkForError(success);
              this.data.getErrorMessageByCode(
                'ICSWD',
                this.appService.appMessages
              );
            } else {
              this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalApplicationMemberSignature =
                success;
              this.router.navigateByUrl(
                '/home/make-withdrawl/government-assistance/government-assistance-step13'
              );
            }
          });
      }
    }
  }

  goToHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
}
