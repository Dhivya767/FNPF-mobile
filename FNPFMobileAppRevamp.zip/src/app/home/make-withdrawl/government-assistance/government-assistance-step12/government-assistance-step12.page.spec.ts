import { ComponentFixture, TestBed } from '@angular/core/testing';
import { GovernmentAssistanceStep12Page } from './government-assistance-step12.page';

describe('GovernmentAssistanceStep12Page', () => {
  let component: GovernmentAssistanceStep12Page;
  let fixture: ComponentFixture<GovernmentAssistanceStep12Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(GovernmentAssistanceStep12Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
