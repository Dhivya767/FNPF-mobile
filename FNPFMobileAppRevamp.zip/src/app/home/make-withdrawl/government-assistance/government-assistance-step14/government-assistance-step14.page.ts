import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-government-assistance-step14',
  templateUrl: './government-assistance-step14.page.html',
  styleUrls: ['./government-assistance-step14.page.scss'],
})
export class GovernmentAssistanceStep14Page implements OnInit {

  constructor(
    public router : Router
  ) { }

  ngOnInit() {
  }
  goBack(){
    this.router.navigateByUrl('/home/make-withdrawl/government-assistance/government-assistance-step13')
  }
  goToHome(){
    this.router.navigateByUrl('/home')
  }
  ValidateOTP(){
    this.router.navigateByUrl('/home/make-withdrawl/government-assistance/government-assistance-step15')
  }
  ResendOTP(){
    this.router.navigateByUrl('/home/make-withdrawl/government-assistance/government-assistance-step13')
  }
}
