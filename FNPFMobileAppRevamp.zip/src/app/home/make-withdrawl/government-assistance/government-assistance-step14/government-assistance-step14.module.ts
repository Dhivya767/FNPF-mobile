import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { GovernmentAssistanceStep14PageRoutingModule } from './government-assistance-step14-routing.module';

import { GovernmentAssistanceStep14Page } from './government-assistance-step14.page';
import { MessagesModule } from "../../../../app-core/template/messages/messages.module";
import { FormInputModule } from "../../../../app-core/form-input/form-input.module";

@NgModule({
    declarations: [GovernmentAssistanceStep14Page],
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        GovernmentAssistanceStep14PageRoutingModule,
        MessagesModule,
        FormInputModule
    ]
})
export class GovernmentAssistanceStep14PageModule {}
