import { ComponentFixture, TestBed } from '@angular/core/testing';
import { GovernmentAssistanceStep14Page } from './government-assistance-step14.page';

describe('GovernmentAssistanceStep14Page', () => {
  let component: GovernmentAssistanceStep14Page;
  let fixture: ComponentFixture<GovernmentAssistanceStep14Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(GovernmentAssistanceStep14Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
