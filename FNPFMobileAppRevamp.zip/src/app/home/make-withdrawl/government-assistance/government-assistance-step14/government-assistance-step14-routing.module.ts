import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { GovernmentAssistanceStep14Page } from './government-assistance-step14.page';

const routes: Routes = [
  {
    path: '',
    component: GovernmentAssistanceStep14Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class GovernmentAssistanceStep14PageRoutingModule {}
