import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from 'src/app/app.service';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { GovernmentAssistanceService } from '../government-assistance.service';

@Component({
  selector: 'app-government-assistance-step4',
  templateUrl: './government-assistance-step4.page.html',
  styleUrls: ['./government-assistance-step4.page.scss'],
})
export class GovernmentAssistanceStep4Page implements OnInit {
  errorTrue = false;
  errorMessages = {};
  ddlPreferredCommunication: any = [];
  constructor(
    public router: Router,
    public governmentAssistanceService: GovernmentAssistanceService,
    public data: DataService,
    public appService: AppService,
    public applicationService: ApplicationApiService
  ) {
    this.ddlPreferredCommunication =
      this.governmentAssistanceService.DDL.ddlPreferredCommunication;
  }

  ngOnInit() {}
  restrictSpecialChars(event: any) {
    let newValue = event.target.value;
    let regExp = new RegExp('^[A-Za-z0-9? ]+$');
    if (!regExp.test(newValue)) {
      event.target.value = newValue.slice(0, -1);
    }
  }
  async gotoNext() {
    if (
      !this.governmentAssistanceService.governmentAssistance
        .member_contact_no ||
      this.governmentAssistanceService.governmentAssistance
        .member_contact_no === '' ||
      this.governmentAssistanceService.governmentAssistance.member_contact_no
        .length == 0
    ) {
      this.data.getErrorMessageByCode('24', this.appService.appMessages);
      return;
    }

    if (
      !this.governmentAssistanceService.governmentAssistance
        .preferred_communication_value ||
      this.governmentAssistanceService.governmentAssistance
        .preferred_communication_value === '' ||
      this.governmentAssistanceService.governmentAssistance
        .preferred_communication_value.length === 0
    ) {
      this.data.getErrorMessageByCode('10', this.appService.appMessages);
      return;
    }

    if (
      this.governmentAssistanceService.governmentAssistance.member_email_id &&
      this.governmentAssistanceService.governmentAssistance.member_email_id
        .length > 0
    ) {
      let isEmail = await this.governmentAssistanceService.validateEmail(
        this.governmentAssistanceService.governmentAssistance.member_email_id
      );
      if (!isEmail) {
        this.data.constructErrorMessage(
          'The Email ID format is invalid. Please enter a valid Email ID.'
        );
        return;
      }
    }

    if (
      this.governmentAssistanceService.governmentAssistance
        .preferred_communication_value === 'EML'
    ) {
      if (
        !this.governmentAssistanceService.governmentAssistance
          .member_email_id ||
        this.governmentAssistanceService.governmentAssistance
          .member_email_id === '' ||
        this.governmentAssistanceService.governmentAssistance.member_email_id
          .length === 0
      ) {
        this.data.constructErrorMessage('Email cannot be empty.');
        return;
      }
    }

    this.applicationService
      .saveGovernmentAssistanceApplication(
        this.governmentAssistanceService.governmentAssistance
      )
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.governmentAssistanceService.governmentAssistance = success;
          this.router.navigateByUrl(
            '/home/make-withdrawl/government-assistance/government-assistance-step5'
          );
        }
      });
  }
  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
  goHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
}
