import { ComponentFixture, TestBed } from '@angular/core/testing';
import { GovernmentAssistanceStep4Page } from './government-assistance-step4.page';

describe('GovernmentAssistanceStep4Page', () => {
  let component: GovernmentAssistanceStep4Page;
  let fixture: ComponentFixture<GovernmentAssistanceStep4Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(GovernmentAssistanceStep4Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
