import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { GovernmentAssistanceStep4PageRoutingModule } from './government-assistance-step4-routing.module';

import { GovernmentAssistanceStep4Page } from './government-assistance-step4.page';
import { MessagesModule } from 'src/app/app-core/template/messages/messages.module';
import { FormInputModule } from 'src/app/app-core/form-input/form-input.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    GovernmentAssistanceStep4PageRoutingModule,
    MessagesModule,
    FormInputModule,
  ],
  declarations: [GovernmentAssistanceStep4Page],
})
export class GovernmentAssistanceStep4PageModule {}
