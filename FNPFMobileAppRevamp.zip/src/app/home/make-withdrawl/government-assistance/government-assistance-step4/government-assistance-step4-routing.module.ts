import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { GovernmentAssistanceStep4Page } from './government-assistance-step4.page';

const routes: Routes = [
  {
    path: '',
    component: GovernmentAssistanceStep4Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class GovernmentAssistanceStep4PageRoutingModule {}
