import { Injectable } from '@angular/core';
import { busUIMemberProfile } from 'src/app/common/api-services/admin-api/admin-api.classes';
import { busUIAppWithdrawalApplication } from 'src/app/common/api-services/application-api/application-api.classes';

@Injectable({
  providedIn: 'root',
})
export class GovernmentAssistanceService {
  withdrawalApplication_Id = 0;
  unemployment_additional_info_Id = 0;
  unemploymentCategory = '';
  unemploymentReason = '';
  TerminationDate: any;
  SelectedpaymentMode = '';
  DDL = {
    ddlGenderValue: [],
    ddlPreferredCommunication: [],
    ddlPaymentModeValue: [],
    ddlAddressTypeValue: [],
    ddlCountryValue: [],
    ddlZone: [],
    PostOffices: [],
    Banks: [],
    PreviouslyUsedBanks: [],
    ddltEligibilityStatement: [],
  };

  governmentAssistance = new busUIAppWithdrawalApplication();
  memProfile = new busUIMemberProfile();

  memberDetail = {
    ilstbusUIEmploymentHistory: [],
  };
  emailTo = '';
  constructor() {}
  async validateEmail(email: string): Promise<boolean> {
    let re =
      /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
  }
}
