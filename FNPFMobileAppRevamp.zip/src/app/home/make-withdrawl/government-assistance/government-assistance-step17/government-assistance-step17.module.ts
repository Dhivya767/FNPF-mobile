import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { GovernmentAssistanceStep17PageRoutingModule } from './government-assistance-step17-routing.module';

import { GovernmentAssistanceStep17Page } from './government-assistance-step17.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    GovernmentAssistanceStep17PageRoutingModule
  ],
  declarations: [GovernmentAssistanceStep17Page]
})
export class GovernmentAssistanceStep17PageModule {}
