import { ComponentFixture, TestBed } from '@angular/core/testing';
import { GovernmentAssistanceStep17Page } from './government-assistance-step17.page';

describe('GovernmentAssistanceStep17Page', () => {
  let component: GovernmentAssistanceStep17Page;
  let fixture: ComponentFixture<GovernmentAssistanceStep17Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(GovernmentAssistanceStep17Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
