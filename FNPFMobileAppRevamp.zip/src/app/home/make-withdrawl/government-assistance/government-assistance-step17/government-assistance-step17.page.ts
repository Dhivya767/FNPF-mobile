import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-government-assistance-step17',
  templateUrl: './government-assistance-step17.page.html',
  styleUrls: ['./government-assistance-step17.page.scss'],
})
export class GovernmentAssistanceStep17Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
