import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from 'src/app/app.service';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { GovernmentAssistanceService } from '../government-assistance.service';
import { format } from 'date-fns';

@Component({
  selector: 'app-government-assistance-step7',
  templateUrl: './government-assistance-step7.page.html',
  styleUrls: ['./government-assistance-step7.page.scss'],
})
export class GovernmentAssistanceStep7Page implements OnInit {
  errorTrue = false;
  errorMessages = {};
  firstjabdate: any;
  constructor(
    public router: Router,
    public governmentAssistanceService: GovernmentAssistanceService,
    public data: DataService,
    public appService: AppService,
    public applicationService: ApplicationApiService
  ) {
    this.firstjabdate =
      this.governmentAssistanceService.governmentAssistance.ibusUIGovernmentAssistanceAdditionalInfo.first_jab_date;
  }

  ngOnInit() {}
  restrictSpecialChars(event: any) {
    let newValue = event.target.value;
    let regExp = new RegExp('^[A-Za-z0-9? ]+$');
    if (!regExp.test(newValue)) {
      event.target.value = newValue.slice(0, -1);
    }
  }
  goHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
  gotoNext() {
    if (
      this.governmentAssistanceService.governmentAssistance
        .IsVaccineRegNoMandatory === 'Y'
    ) {
      if (
        !this.governmentAssistanceService.governmentAssistance
          .ibusUIGovernmentAssistanceAdditionalInfo
          .first_jab_vaccination_reg_no ||
        this.governmentAssistanceService.governmentAssistance
          .ibusUIGovernmentAssistanceAdditionalInfo
          .first_jab_vaccination_reg_no === '' ||
        this.governmentAssistanceService.governmentAssistance
          .ibusUIGovernmentAssistanceAdditionalInfo.first_jab_vaccination_reg_no
          .length === 0
      ) {
        this.data.getErrorMessageByCode('37', this.appService.appMessages);
        return;
      }
    }

    if (
      !this.governmentAssistanceService.governmentAssistance
        .ibusUIGovernmentAssistanceAdditionalInfo.first_jab_place ||
      this.governmentAssistanceService.governmentAssistance
        .ibusUIGovernmentAssistanceAdditionalInfo.first_jab_place == '' ||
      this.governmentAssistanceService.governmentAssistance
        .ibusUIGovernmentAssistanceAdditionalInfo.first_jab_place.length == 0
    ) {
      this.data.getErrorMessageByCode('38', this.appService.appMessages);
      return;
    }

    if (!this.firstjabdate || this.firstjabdate.length === 0) {
      this.data.getErrorMessageByCode('39', this.appService.appMessages);
      return;
    } else {
      let ConvertedDate = format(new Date(this.firstjabdate), 'dd/MM/yyyy');
      this.governmentAssistanceService.governmentAssistance.ibusUIGovernmentAssistanceAdditionalInfo.first_jab_date =
        ConvertedDate;
    }

    if (
      this.governmentAssistanceService.governmentAssistance
        .ibusUIGovernmentAssistanceAdditionalInfo.first_jab_flag === 'N'
    ) {
      this.data.getErrorMessageByCode('36', this.appService.appMessages);
      return;
    }

    this.applicationService
      .saveGovernmentAssistanceApplication(
        this.governmentAssistanceService.governmentAssistance
      )
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.governmentAssistanceService.governmentAssistance = success;
          if (
            this.governmentAssistanceService.governmentAssistance
              .ibusUIGovernmentAssistanceAdditionalInfo
              .enable_second_jab_page === 'Y'
          ) {
            this.router.navigateByUrl(
              '/home/make-withdrawl/government-assistance/government-assistance-step8'
            );
          } else {
            this.router.navigateByUrl(
              '/home/make-withdrawl/government-assistance/government-assistance-step9'
            );
          }
        }
      });
  }
  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
}
