import { ComponentFixture, TestBed } from '@angular/core/testing';
import { GovernmentAssistanceStep7Page } from './government-assistance-step7.page';

describe('GovernmentAssistanceStep7Page', () => {
  let component: GovernmentAssistanceStep7Page;
  let fixture: ComponentFixture<GovernmentAssistanceStep7Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(GovernmentAssistanceStep7Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
