import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { GovernmentAssistanceStep7Page } from './government-assistance-step7.page';

const routes: Routes = [
  {
    path: '',
    component: GovernmentAssistanceStep7Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class GovernmentAssistanceStep7PageRoutingModule {}
