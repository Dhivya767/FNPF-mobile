import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { GovernmentAssistanceStep7PageRoutingModule } from './government-assistance-step7-routing.module';

import { GovernmentAssistanceStep7Page } from './government-assistance-step7.page';
import { MessagesModule } from 'src/app/app-core/template/messages/messages.module';
import { FormInputModule } from 'src/app/app-core/form-input/form-input.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    GovernmentAssistanceStep7PageRoutingModule,
    MessagesModule,
    FormInputModule,
  ],
  declarations: [GovernmentAssistanceStep7Page],
})
export class GovernmentAssistanceStep7PageModule {}
