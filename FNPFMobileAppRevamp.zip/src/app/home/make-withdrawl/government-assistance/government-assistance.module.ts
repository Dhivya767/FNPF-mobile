import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { GovernmentAssistancePageRoutingModule } from './government-assistance-routing.module';

import { GovernmentAssistancePage } from './government-assistance.page';
import { MessagesModule } from 'src/app/app-core/template/messages/messages.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    GovernmentAssistancePageRoutingModule,
    MessagesModule,
  ],
  declarations: [GovernmentAssistancePage],
})
export class GovernmentAssistancePageModule {}
