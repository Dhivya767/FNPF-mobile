import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { GovernmentAssistanceService } from './government-assistance.service';
import { AppService } from 'src/app/app.service';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';

@Component({
  selector: 'app-government-assistance',
  templateUrl: './government-assistance.page.html',
  styleUrls: ['./government-assistance.page.scss'],
})
export class GovernmentAssistancePage implements OnInit {
  errorTrue = false;
  memberProfiledata: any;
  UnemploymentCategory: any = [];
  constructor(
    public router: Router,
    public governmentAssistanceService: GovernmentAssistanceService,
    public data: DataService,
    public appService: AppService,
    public applicationService: ApplicationApiService
  ) {
    this.memberProfiledata = this.governmentAssistanceService.memProfile;
  }

  ngOnInit() {}
  createNewUnemploymentWithdrawalApplication(val: any) {
    let obj = {
      fnpfid: this.memberProfiledata.fnpf_no,
      islockdownwithdrawal: val,
    };

    this.applicationService
      .createNewUnemploymentWithdrawalApplication(obj)
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.governmentAssistanceService.governmentAssistance = success;
          this.UnemploymentCategory = [];
          if (
            this.governmentAssistanceService.governmentAssistance &&
            this.governmentAssistanceService.governmentAssistance
              .ibusUIAppWithdrawalUnemploymentAdditionalInfo != null &&
            this.governmentAssistanceService.governmentAssistance
              .ibusUIAppWithdrawalUnemploymentAdditionalInfo != undefined
          ) {
            if (
              this.governmentAssistanceService.governmentAssistance
                .ibusUIAppWithdrawalUnemploymentAdditionalInfo
                .ilstUIUnemploymentCategories &&
              this.governmentAssistanceService.governmentAssistance
                .ibusUIAppWithdrawalUnemploymentAdditionalInfo
                .ilstUIUnemploymentCategories.length > 0
            ) {
              this.UnemploymentCategory =
                this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.ilstUIUnemploymentCategories;
            }
          }
          this.setInIonicStorageForUnemployment();
          this.router.navigateByUrl(
            '/home/make-withdrawl/partial-withdrawl/pandemic-withdrawal'
          );
        }
      });
  }

  private setInIonicStorageForUnemployment() {
    if (
      this.governmentAssistanceService.governmentAssistance &&
      this.governmentAssistanceService.governmentAssistance
        .withdrawal_application_id
    ) {
      this.governmentAssistanceService.withdrawalApplication_Id =
        this.governmentAssistanceService.governmentAssistance.withdrawal_application_id;
    }

    if (
      this.governmentAssistanceService.governmentAssistance &&
      this.governmentAssistanceService.governmentAssistance
        .ibusUIAppWithdrawalUnemploymentAdditionalInfo
    ) {
      this.governmentAssistanceService.unemployment_additional_info_Id =
        this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.app_withdrawal_unemployment_additional_info_id;
    }

    this.governmentAssistanceService.unemploymentCategory =
      this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.category_value;

    this.governmentAssistanceService.unemploymentReason =
      this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.reason_value;

    this.governmentAssistanceService.TerminationDate = null;
    this.governmentAssistanceService.SelectedpaymentMode =
      this.governmentAssistanceService.governmentAssistance.ibusUIAppWithdrawalUnemploymentAdditionalInfo.payment_mode_value;
  }

  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
  gotoNext() {
    this.router.navigateByUrl(
      '/home/make-withdrawl/government-assistance/government-assistance-step1'
    );
  }
}
