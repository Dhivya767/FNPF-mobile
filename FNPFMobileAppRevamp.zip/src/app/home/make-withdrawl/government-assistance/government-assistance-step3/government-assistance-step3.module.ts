import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { GovernmentAssistanceStep3PageRoutingModule } from './government-assistance-step3-routing.module';

import { GovernmentAssistanceStep3Page } from './government-assistance-step3.page';
import { FormInputModule } from 'src/app/app-core/form-input/form-input.module';
import { MessagesModule } from 'src/app/app-core/template/messages/messages.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    GovernmentAssistanceStep3PageRoutingModule,
    FormInputModule,
    MessagesModule,
  ],
  declarations: [GovernmentAssistanceStep3Page],
})
export class GovernmentAssistanceStep3PageModule {}
