import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from 'src/app/app.service';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { GovernmentAssistanceService } from '../government-assistance.service';

@Component({
  selector: 'app-government-assistance-step3',
  templateUrl: './government-assistance-step3.page.html',
  styleUrls: ['./government-assistance-step3.page.scss'],
})
export class GovernmentAssistanceStep3Page implements OnInit {
  errorTrue = false;
  errorMessages = {};
  ddlCountryValue: any = [];
  constructor(
    public router: Router,
    public governmentAssistanceService: GovernmentAssistanceService,
    public data: DataService,
    public appService: AppService,
    public applicationService: ApplicationApiService
  ) {
    this.ddlCountryValue = this.governmentAssistanceService.DDL.ddlCountryValue;
  }

  ngOnInit() {}
  restrictSpecialChars(event: any) {
    let newValue = event.target.value;
    let regExp = new RegExp('^[A-Za-z0-9? ]+$');
    if (!regExp.test(newValue)) {
      event.target.value = newValue.slice(0, -1);
    }
  }
  goHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
  gotoNext() {
    if (
      !this.governmentAssistanceService.governmentAssistance
        .ibusUIGovernmentAssistanceAdditionalInfo.ibusUIResidentialAddress
        .address_line_1 ||
      this.governmentAssistanceService.governmentAssistance
        .ibusUIGovernmentAssistanceAdditionalInfo.ibusUIResidentialAddress
        .address_line_1 === '' ||
      this.governmentAssistanceService.governmentAssistance
        .ibusUIGovernmentAssistanceAdditionalInfo.ibusUIResidentialAddress
        .address_line_1.length === 0
    ) {
      this.data.getErrorMessageByCode('16', this.appService.appMessages);
      return;
    }

    if (
      !this.governmentAssistanceService.governmentAssistance
        .ibusUIGovernmentAssistanceAdditionalInfo.ibusUIResidentialAddress
        .city ||
      this.governmentAssistanceService.governmentAssistance
        .ibusUIGovernmentAssistanceAdditionalInfo.ibusUIResidentialAddress
        .city === '' ||
      this.governmentAssistanceService.governmentAssistance
        .ibusUIGovernmentAssistanceAdditionalInfo.ibusUIResidentialAddress.city
        .length === 0
    ) {
      this.data.getErrorMessageByCode('17', this.appService.appMessages);
      return;
    }

    if (
      !this.governmentAssistanceService.governmentAssistance
        .ibusUIGovernmentAssistanceAdditionalInfo.ibusUIResidentialAddress
        .country_value ||
      this.governmentAssistanceService.governmentAssistance
        .ibusUIGovernmentAssistanceAdditionalInfo.ibusUIResidentialAddress
        .country_value === '' ||
      this.governmentAssistanceService.governmentAssistance
        .ibusUIGovernmentAssistanceAdditionalInfo.ibusUIResidentialAddress
        .country_value.length === 0
    ) {
      this.data.getErrorMessageByCode('19', this.appService.appMessages);
      return;
    }
    this.governmentAssistanceService.governmentAssistance.ibusUIGovernmentAssistanceAdditionalInfo.ibusUIResidentialAddress.fnpf_id =
      this.governmentAssistanceService.governmentAssistance.fnpf_id;
    this.applicationService
      .saveLowBalanceWithdrawalApplicationAddress(
        this.governmentAssistanceService.governmentAssistance
          .ibusUIGovernmentAssistanceAdditionalInfo.ibusUIResidentialAddress
      )
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.governmentAssistanceService.governmentAssistance.ibusUIGovernmentAssistanceAdditionalInfo.ibusUIResidentialAddress =
            success;
          if (
            this.governmentAssistanceService.governmentAssistance
              .ibusUIGovernmentAssistanceAdditionalInfo.ibusUIResidentialAddress
              .address_id > 0
          ) {
            this.governmentAssistanceService.governmentAssistance.ibusUIGovernmentAssistanceAdditionalInfo.residential_address_id =
              this.governmentAssistanceService.governmentAssistance.ibusUIGovernmentAssistanceAdditionalInfo.ibusUIResidentialAddress.address_id;
          }
          this.router.navigateByUrl(
            '/home/make-withdrawl/government-assistance/government-assistance-step4'
          );
        }
      });
  }
  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
}
