import { ComponentFixture, TestBed } from '@angular/core/testing';
import { GovernmentAssistanceStep3Page } from './government-assistance-step3.page';

describe('GovernmentAssistanceStep3Page', () => {
  let component: GovernmentAssistanceStep3Page;
  let fixture: ComponentFixture<GovernmentAssistanceStep3Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(GovernmentAssistanceStep3Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
