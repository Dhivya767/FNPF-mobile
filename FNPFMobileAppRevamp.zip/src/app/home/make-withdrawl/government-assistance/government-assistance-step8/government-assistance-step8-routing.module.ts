import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { GovernmentAssistanceStep8Page } from './government-assistance-step8.page';

const routes: Routes = [
  {
    path: '',
    component: GovernmentAssistanceStep8Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class GovernmentAssistanceStep8PageRoutingModule {}
