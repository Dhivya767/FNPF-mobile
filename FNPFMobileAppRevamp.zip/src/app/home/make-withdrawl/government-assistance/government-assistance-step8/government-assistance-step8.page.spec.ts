import { ComponentFixture, TestBed } from '@angular/core/testing';
import { GovernmentAssistanceStep8Page } from './government-assistance-step8.page';

describe('GovernmentAssistanceStep8Page', () => {
  let component: GovernmentAssistanceStep8Page;
  let fixture: ComponentFixture<GovernmentAssistanceStep8Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(GovernmentAssistanceStep8Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
