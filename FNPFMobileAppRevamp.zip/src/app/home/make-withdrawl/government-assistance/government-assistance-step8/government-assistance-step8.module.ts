import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { GovernmentAssistanceStep8PageRoutingModule } from './government-assistance-step8-routing.module';

import { GovernmentAssistanceStep8Page } from './government-assistance-step8.page';
import { MessagesModule } from "../../../../app-core/template/messages/messages.module";
import { FormInputModule } from "../../../../app-core/form-input/form-input.module";

@NgModule({
    declarations: [GovernmentAssistanceStep8Page],
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        GovernmentAssistanceStep8PageRoutingModule,
        MessagesModule,
        FormInputModule
    ]
})
export class GovernmentAssistanceStep8PageModule {}
