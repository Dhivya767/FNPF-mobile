import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { format } from 'date-fns';
import { AppService } from 'src/app/app.service';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { GovernmentAssistanceService } from '../government-assistance.service';

@Component({
  selector: 'app-government-assistance-step8',
  templateUrl: './government-assistance-step8.page.html',
  styleUrls: ['./government-assistance-step8.page.scss'],
})
export class GovernmentAssistanceStep8Page implements OnInit {
  errorTrue = false;
  errorMessages = {};
  secondjabdate: any;
  constructor(
    public router: Router,
    public governmentAssistanceService: GovernmentAssistanceService,
    public data: DataService,
    public appService: AppService,
    public applicationService: ApplicationApiService
  ) {
    this.secondjabdate =
      this.governmentAssistanceService.governmentAssistance.ibusUIGovernmentAssistanceAdditionalInfo.second_jab_date;
  }

  ngOnInit() {}
  restrictSpecialChars(event: any) {
    let newValue = event.target.value;
    let regExp = new RegExp('^[A-Za-z0-9? ]+$');
    if (!regExp.test(newValue)) {
      event.target.value = newValue.slice(0, -1);
    }
  }
  goHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
  gotoNext() {
    if (
      this.governmentAssistanceService.governmentAssistance
        .IsVaccineRegNoMandatory === 'Y'
    ) {
      if (
        !this.governmentAssistanceService.governmentAssistance
          .ibusUIGovernmentAssistanceAdditionalInfo
          .second_jab_vaccination_reg_no ||
        this.governmentAssistanceService.governmentAssistance
          .ibusUIGovernmentAssistanceAdditionalInfo
          .second_jab_vaccination_reg_no === '' ||
        this.governmentAssistanceService.governmentAssistance
          .ibusUIGovernmentAssistanceAdditionalInfo
          .second_jab_vaccination_reg_no.length === 0
      ) {
        this.data.getErrorMessageByCode('37', this.appService.appMessages);
        return;
      }
    }

    if (
      !this.governmentAssistanceService.governmentAssistance
        .ibusUIGovernmentAssistanceAdditionalInfo.second_jab_place ||
      this.governmentAssistanceService.governmentAssistance
        .ibusUIGovernmentAssistanceAdditionalInfo.second_jab_place == '' ||
      this.governmentAssistanceService.governmentAssistance
        .ibusUIGovernmentAssistanceAdditionalInfo.second_jab_place.length == 0
    ) {
      this.data.getErrorMessageByCode('38', this.appService.appMessages);
      return;
    }

    if (!this.secondjabdate || this.secondjabdate.length === 0) {
      this.data.getErrorMessageByCode('39', this.appService.appMessages);
      return;
    } else {
      let ConvertedDate = format(new Date(this.secondjabdate), 'dd/MM/yyyy');
      this.governmentAssistanceService.governmentAssistance.ibusUIGovernmentAssistanceAdditionalInfo.second_jab_date =
        ConvertedDate;
    }

    if (
      this.governmentAssistanceService.governmentAssistance
        .ibusUIGovernmentAssistanceAdditionalInfo.first_jab_flag === 'N'
    ) {
      this.data.getErrorMessageByCode('36', this.appService.appMessages);
      return;
    }

    this.applicationService
      .saveGovernmentAssistanceApplication(
        this.governmentAssistanceService.governmentAssistance
      )
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.governmentAssistanceService.governmentAssistance = success;
          this.router.navigateByUrl(
            '/home/make-withdrawl/government-assistance/government-assistance-step9'
          );
        }
      });
  }
  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
  goNext() {
    this.router.navigateByUrl(
      '/home/make-withdrawl/government-assistance/government-assistance-step9'
    );
  }
  goBack() {
    this.router.navigateByUrl(
      '/home/make-withdrawl/government-assistance/government-assistance-step7'
    );
  }
  goToHome() {
    this.router.navigateByUrl('/home');
  }
}
