import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { GovernmentAssistancePage } from './government-assistance.page';

const routes: Routes = [
  {
    path: '',
    component: GovernmentAssistancePage,
  },

  {
    path: 'government-assistance-step1',
    loadChildren: () =>
      import(
        './government-assistance-step1/government-assistance-step1.module'
      ).then((m) => m.GovernmentAssistanceStep1PageModule),
  },
  {
    path: 'government-assistance-step2',
    loadChildren: () =>
      import(
        './government-assistance-step2/government-assistance-step2.module'
      ).then((m) => m.GovernmentAssistanceStep2PageModule),
  },
  {
    path: 'government-assistance-step3',
    loadChildren: () =>
      import(
        './government-assistance-step3/government-assistance-step3.module'
      ).then((m) => m.GovernmentAssistanceStep3PageModule),
  },
  {
    path: 'government-assistance-step4',
    loadChildren: () =>
      import(
        './government-assistance-step4/government-assistance-step4.module'
      ).then((m) => m.GovernmentAssistanceStep4PageModule),
  },
  {
    path: 'government-assistance-step5',
    loadChildren: () =>
      import(
        './government-assistance-step5/government-assistance-step5.module'
      ).then((m) => m.GovernmentAssistanceStep5PageModule),
  },
  {
    path: 'government-assistance-step6',
    loadChildren: () =>
      import(
        './government-assistance-step6/government-assistance-step6.module'
      ).then((m) => m.GovernmentAssistanceStep6PageModule),
  },
  {
    path: 'government-assistance-step7',
    loadChildren: () =>
      import(
        './government-assistance-step7/government-assistance-step7.module'
      ).then((m) => m.GovernmentAssistanceStep7PageModule),
  },
  {
    path: 'government-assistance-step8',
    loadChildren: () =>
      import(
        './government-assistance-step8/government-assistance-step8.module'
      ).then((m) => m.GovernmentAssistanceStep8PageModule),
  },
  {
    path: 'government-assistance-step9',
    loadChildren: () =>
      import(
        './government-assistance-step9/government-assistance-step9.module'
      ).then((m) => m.GovernmentAssistanceStep9PageModule),
  },
  {
    path: 'government-assistance-step10',
    loadChildren: () =>
      import(
        './government-assistance-step10/government-assistance-step10.module'
      ).then((m) => m.GovernmentAssistanceStep10PageModule),
  },
  {
    path: 'government-assistance-step11',
    loadChildren: () =>
      import(
        './government-assistance-step11/government-assistance-step11.module'
      ).then((m) => m.GovernmentAssistanceStep11PageModule),
  },
  {
    path: 'government-assistance-step12',
    loadChildren: () =>
      import(
        './government-assistance-step12/government-assistance-step12.module'
      ).then((m) => m.GovernmentAssistanceStep12PageModule),
  },
  {
    path: 'government-assistance-step13',
    loadChildren: () =>
      import(
        './government-assistance-step13/government-assistance-step13.module'
      ).then((m) => m.GovernmentAssistanceStep13PageModule),
  },
  {
    path: 'government-assistance-step14',
    loadChildren: () =>
      import(
        './government-assistance-step14/government-assistance-step14.module'
      ).then((m) => m.GovernmentAssistanceStep14PageModule),
  },
  {
    path: 'government-assistance-step15',
    loadChildren: () =>
      import(
        './government-assistance-step15/government-assistance-step15.module'
      ).then((m) => m.GovernmentAssistanceStep15PageModule),
  },
  {
    path: 'government-assistance-step16',
    loadChildren: () =>
      import(
        './government-assistance-step16/government-assistance-step16.module'
      ).then((m) => m.GovernmentAssistanceStep16PageModule),
  },
  {
    path: 'government-assistance-step17',
    loadChildren: () =>
      import(
        './government-assistance-step17/government-assistance-step17.module'
      ).then((m) => m.GovernmentAssistanceStep17PageModule),
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class GovernmentAssistancePageRoutingModule {}
