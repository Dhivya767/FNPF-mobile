import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdviceOfDeathStep3PageRoutingModule } from './advice-of-death-step3-routing.module';

import { AdviceOfDeathStep3Page } from './advice-of-death-step3.page';
import { FormInputModule } from "../../../../../app-core/form-input/form-input.module";
import { MessagesModule } from "../../../../../app-core/template/messages/messages.module";

@NgModule({
    declarations: [AdviceOfDeathStep3Page],
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        AdviceOfDeathStep3PageRoutingModule,
        FormInputModule,
        MessagesModule
    ]
})
export class AdviceOfDeathStep3PageModule {}
