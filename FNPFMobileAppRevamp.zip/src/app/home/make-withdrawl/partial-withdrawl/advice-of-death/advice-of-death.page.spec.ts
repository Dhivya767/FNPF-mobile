import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AdviceOfDeathPage } from './advice-of-death.page';

describe('AdviceOfDeathPage', () => {
  let component: AdviceOfDeathPage;
  let fixture: ComponentFixture<AdviceOfDeathPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(AdviceOfDeathPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
