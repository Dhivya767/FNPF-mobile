import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdviceOfDeathPageRoutingModule } from './advice-of-death-routing.module';

import { AdviceOfDeathPage } from './advice-of-death.page';
import { MessagesModule } from '../../../../app-core/template/messages/messages.module';

@NgModule({
  declarations: [AdviceOfDeathPage],
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdviceOfDeathPageRoutingModule,
    MessagesModule,
  ],
})
export class AdviceOfDeathPageModule {}
