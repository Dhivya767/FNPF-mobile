import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdviceOfDeathStep2PageRoutingModule } from './advice-of-death-step2-routing.module';

import { AdviceOfDeathStep2Page } from './advice-of-death-step2.page';
import { FormInputModule } from "../../../../../app-core/form-input/form-input.module";
import { MessagesModule } from 'src/app/app-core/template/messages/messages.module';

@NgModule({
    declarations: [AdviceOfDeathStep2Page],
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        AdviceOfDeathStep2PageRoutingModule,
        FormInputModule,
        MessagesModule
    ]
})
export class AdviceOfDeathStep2PageModule {}
