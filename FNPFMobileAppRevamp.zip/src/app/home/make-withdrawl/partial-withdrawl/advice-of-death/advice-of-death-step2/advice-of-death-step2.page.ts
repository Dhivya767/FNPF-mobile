import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from 'src/app/app.service';
import { AdviceOfDeathService } from '../advice-of-death.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { format } from 'date-fns';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';

@Component({
  selector: 'app-advice-of-death-step2',
  templateUrl: './advice-of-death-step2.page.html',
  styleUrls: ['./advice-of-death-step2.page.scss'],
})
export class AdviceOfDeathStep2Page implements OnInit {
  errorTrue = false;
  errorMessages = {};
  deathDate = '';
  constructor(
    public appService: AppService,
    public router: Router,
    public adviceOfDeathService: AdviceOfDeathService,
    public data: DataService,
    public applicationService: ApplicationApiService
  ) {
    this.deathDate = this.adviceOfDeathService.adviceOfDeath.death_date;
  }

  ngOnInit() {}
  goToHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
  goNext(l: any) {
    // if (l.valid) {
    //   this.errorTrue = false;
    if (
      !this.adviceOfDeathService.adviceOfDeath.received_location_value ||
      this.adviceOfDeathService.adviceOfDeath.received_location_value === ''
    ) {
      this.data.getErrorMessageByCode('307', this.appService.appMessages);
      return;
    }
    if (
      !this.adviceOfDeathService.adviceOfDeath.relationship_to_deceased_value ||
      this.adviceOfDeathService.adviceOfDeath.relationship_to_deceased_value ===
        ''
    ) {
      this.data.getErrorMessageByCode('308', this.appService.appMessages);
      return;
    }
    if (
      !this.adviceOfDeathService.adviceOfDeath
        .detailed_relationship_to_deceased_value ||
      this.adviceOfDeathService.adviceOfDeath
        .detailed_relationship_to_deceased_value === ''
    ) {
      this.data.getErrorMessageByCode('309', this.appService.appMessages);
      return;
    }
    if (!this.deathDate || this.deathDate === '') {
      this.data.getErrorMessageByCode('310', this.appService.appMessages);
      return;
    } else {
      let convertedDate = format(new Date(this.deathDate), 'dd/MM/yyyy');
      this.adviceOfDeathService.adviceOfDeath.death_date = convertedDate;
    }
    if (
      !this.adviceOfDeathService.adviceOfDeath.mode_of_contact_value ||
      this.adviceOfDeathService.adviceOfDeath.mode_of_contact_value === ''
    ) {
      this.data.getErrorMessageByCode('324', this.appService.appMessages);
      return;
    }
    if (
      this.adviceOfDeathService.adviceOfDeath.mode_of_contact_value === 'CODNO'
    ) {
      if (
        !this.adviceOfDeathService.adviceOfDeath.informant_telephone_no ||
        this.adviceOfDeathService.adviceOfDeath.informant_telephone_no === ''
      ) {
        this.data.getErrorMessageByCode('371', this.appService.appMessages);
        return;
      }
    }
    if (
      this.adviceOfDeathService.adviceOfDeath.mode_of_contact_value == 'EMAIL'
    ) {
      if (
        !this.adviceOfDeathService.adviceOfDeath.informant_email_address ||
        this.adviceOfDeathService.adviceOfDeath.informant_email_address === ''
      ) {
        this.data.getErrorMessageByCode('372', this.appService.appMessages);
        return;
      }
    }
    this.applicationService
      .saveAdviceOfDeath(this.adviceOfDeathService.adviceOfDeath)
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.adviceOfDeathService.adviceOfDeath = success;
          this.router.navigateByUrl(
            '/home/make-withdrawl/partial-withdrawl/advice-of-death/advice-of-death-step3'
          );
        }
      });
    // } else {
    //   this.errorTrue = true;
    // }
  }
  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
}
