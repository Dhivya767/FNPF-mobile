import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AdviceOfDeathStep2Page } from './advice-of-death-step2.page';

describe('AdviceOfDeathStep2Page', () => {
  let component: AdviceOfDeathStep2Page;
  let fixture: ComponentFixture<AdviceOfDeathStep2Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(AdviceOfDeathStep2Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
