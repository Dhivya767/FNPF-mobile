import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdviceOfDeathStep11PageRoutingModule } from './advice-of-death-step11-routing.module';

import { AdviceOfDeathStep11Page } from './advice-of-death-step11.page';
import { MessagesModule } from '../../../../../app-core/template/messages/messages.module';

@NgModule({
  declarations: [AdviceOfDeathStep11Page],
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdviceOfDeathStep11PageRoutingModule,
    MessagesModule,
  ],
})
export class AdviceOfDeathStep11PageModule {}
