import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdviceOfDeathService } from '../advice-of-death.service';

@Component({
  selector: 'app-advice-of-death-step11',
  templateUrl: './advice-of-death-step11.page.html',
  styleUrls: ['./advice-of-death-step11.page.scss'],
})
export class AdviceOfDeathStep11Page implements OnInit {
  constructor(
    public router: Router,
    public adviceOfDeathService: AdviceOfDeathService
  ) {}

  ngOnInit() {}

  gotoWithdrawals() {
    this.router.navigateByUrl('/home/make-withdrawl');
  }
  gotoHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
}
