import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdviceOfDeathStep11Page } from './advice-of-death-step11.page';

const routes: Routes = [
  {
    path: '',
    component: AdviceOfDeathStep11Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdviceOfDeathStep11PageRoutingModule {}
