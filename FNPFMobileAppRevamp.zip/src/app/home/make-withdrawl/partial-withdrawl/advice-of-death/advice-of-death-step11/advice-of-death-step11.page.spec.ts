import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AdviceOfDeathStep11Page } from './advice-of-death-step11.page';

describe('AdviceOfDeathStep11Page', () => {
  let component: AdviceOfDeathStep11Page;
  let fixture: ComponentFixture<AdviceOfDeathStep11Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(AdviceOfDeathStep11Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
