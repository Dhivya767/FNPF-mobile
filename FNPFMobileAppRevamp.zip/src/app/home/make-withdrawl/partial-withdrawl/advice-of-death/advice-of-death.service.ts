import { Injectable } from '@angular/core';
import { AppService } from 'src/app/app.service';
import { busUIMemberProfile } from 'src/app/common/api-services/admin-api/admin-api.classes';
import { busUIAdviceOfDeath } from 'src/app/common/api-services/application-api/application-api.classes';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';

@Injectable({
  providedIn: 'root',
})
export class AdviceOfDeathService {
  adviceOfDeath = new busUIAdviceOfDeath();
  DDL = {
    ddlLocation: [],
    ddlRelationship: [],
    ddlDetailedRelationship: [],
    ddlMaritalStaus: [],
    ddlDeathCause: [],
  };
  memProfile = new busUIMemberProfile();
  memberDetail = {
    ilstbusUIEmploymentHistory: [],
  };
  constructor(
    public applicationService: ApplicationApiService,
    public appService: AppService
  ) {}
  ngOnInit() {}
}
