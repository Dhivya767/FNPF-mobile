import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdviceOfDeathStep1Page } from './advice-of-death-step1.page';

const routes: Routes = [
  {
    path: '',
    component: AdviceOfDeathStep1Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdviceOfDeathStep1PageRoutingModule {}
