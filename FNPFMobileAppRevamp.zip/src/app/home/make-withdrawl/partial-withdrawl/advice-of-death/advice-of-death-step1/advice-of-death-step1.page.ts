import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from 'src/app/app.service';
import { AdviceOfDeathService } from '../advice-of-death.service';

@Component({
  selector: 'app-advice-of-death-step1',
  templateUrl: './advice-of-death-step1.page.html',
  styleUrls: ['./advice-of-death-step1.page.scss'],
})
export class AdviceOfDeathStep1Page implements OnInit {
  indexPage2 = 0;
  constructor(
    public router: Router,
    public appService: AppService,
    public adviceOfDeathService: AdviceOfDeathService
  ) {
    this.indexPage2=this.adviceOfDeathService.adviceOfDeath?.ilstUIAODRequirementsPage2?.length;
  }

  ngOnInit() {}
  goToHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
  gotoNext() {
    this.router.navigateByUrl(
      '/home/make-withdrawl/partial-withdrawl/advice-of-death/advice-of-death-step2'
    );
  }
}
