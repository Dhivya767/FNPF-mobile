import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AdviceOfDeathStep1Page } from './advice-of-death-step1.page';

describe('AdviceOfDeathStep1Page', () => {
  let component: AdviceOfDeathStep1Page;
  let fixture: ComponentFixture<AdviceOfDeathStep1Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(AdviceOfDeathStep1Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
