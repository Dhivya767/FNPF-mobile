import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdviceOfDeathStep1PageRoutingModule } from './advice-of-death-step1-routing.module';

import { AdviceOfDeathStep1Page } from './advice-of-death-step1.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdviceOfDeathStep1PageRoutingModule
  ],
  declarations: [AdviceOfDeathStep1Page]
})
export class AdviceOfDeathStep1PageModule {}
