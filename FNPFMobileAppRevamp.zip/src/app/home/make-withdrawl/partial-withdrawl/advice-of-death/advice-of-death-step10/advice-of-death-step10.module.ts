import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdviceOfDeathStep10PageRoutingModule } from './advice-of-death-step10-routing.module';

import { AdviceOfDeathStep10Page } from './advice-of-death-step10.page';
import { MessagesModule } from '../../../../../app-core/template/messages/messages.module';

@NgModule({
  declarations: [AdviceOfDeathStep10Page],
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdviceOfDeathStep10PageRoutingModule,
    MessagesModule,
  ],
})
export class AdviceOfDeathStep10PageModule {}
