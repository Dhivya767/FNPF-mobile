import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AdviceOfDeathStep10Page } from './advice-of-death-step10.page';

describe('AdviceOfDeathStep10Page', () => {
  let component: AdviceOfDeathStep10Page;
  let fixture: ComponentFixture<AdviceOfDeathStep10Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(AdviceOfDeathStep10Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
