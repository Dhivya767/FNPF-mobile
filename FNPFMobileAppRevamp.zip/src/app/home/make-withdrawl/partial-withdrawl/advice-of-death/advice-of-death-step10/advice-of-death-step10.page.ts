import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdviceOfDeathService } from '../advice-of-death.service';
import { AppService } from 'src/app/app.service';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';

@Component({
  selector: 'app-advice-of-death-step10',
  templateUrl: './advice-of-death-step10.page.html',
  styleUrls: ['./advice-of-death-step10.page.scss'],
})
export class AdviceOfDeathStep10Page implements OnInit {
  constructor(
    public router: Router,
    public adviceOfDeathService: AdviceOfDeathService,
    public data: DataService,
    public appService: AppService,
    public applicationService: ApplicationApiService
  ) { }

  ngOnInit() { }

  goToHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
  gotoNext() {
    this.applicationService
      .submitAdviceOfDeathApplication(this.adviceOfDeathService.adviceOfDeath)
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.adviceOfDeathService.adviceOfDeath = success;
          this.router.navigateByUrl(
            '/home/make-withdrawl/partial-withdrawl/advice-of-death/advice-of-death-step11'
          );
        }
      });
  }
  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
}
