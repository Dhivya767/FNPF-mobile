import { TestBed } from '@angular/core/testing';

import { AdviceOfDeathService } from './advice-of-death.service';

describe('AdviceOfDeathService', () => {
  let service: AdviceOfDeathService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AdviceOfDeathService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
