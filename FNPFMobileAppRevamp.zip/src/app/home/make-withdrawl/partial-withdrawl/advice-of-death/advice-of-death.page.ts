import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from 'src/app/app.service';
import { AdviceOfDeathService } from './advice-of-death.service';

@Component({
  selector: 'app-advice-of-death',
  templateUrl: './advice-of-death.page.html',
  styleUrls: ['./advice-of-death.page.scss'],
})
export class AdviceOfDeathPage implements OnInit {
  constructor(
    public appService: AppService,
    public router: Router,
    public adviceOfDeathService: AdviceOfDeathService
  ) {}

  ngOnInit() {}
  goToHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
  gotoNext() {
    this.router.navigateByUrl(
      '/home/make-withdrawl/partial-withdrawl/advice-of-death/advice-of-death-step1'
    );
  }
}
