import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdviceOfDeathPage } from './advice-of-death.page';

const routes: Routes = [
  {
    path: '',
    component: AdviceOfDeathPage
  },
  {
    path: 'advice-of-death-step1',
    loadChildren: () => import('./advice-of-death-step1/advice-of-death-step1.module').then( m => m.AdviceOfDeathStep1PageModule)
  },
  {
    path: 'advice-of-death-step2',
    loadChildren: () => import('./advice-of-death-step2/advice-of-death-step2.module').then( m => m.AdviceOfDeathStep2PageModule)
  },
  {
    path: 'advice-of-death-step3',
    loadChildren: () => import('./advice-of-death-step3/advice-of-death-step3.module').then( m => m.AdviceOfDeathStep3PageModule)
  },
  {
    path: 'advice-of-death-step4',
    loadChildren: () => import('./advice-of-death-step4/advice-of-death-step4.module').then( m => m.AdviceOfDeathStep4PageModule)
  },
  {
    path: 'advice-of-death-step5',
    loadChildren: () => import('./advice-of-death-step5/advice-of-death-step5.module').then( m => m.AdviceOfDeathStep5PageModule)
  },
  {
    path: 'advice-of-death-step6',
    loadChildren: () => import('./advice-of-death-step6/advice-of-death-step6.module').then( m => m.AdviceOfDeathStep6PageModule)
  },
  {
    path: 'advice-of-death-step7',
    loadChildren: () => import('./advice-of-death-step7/advice-of-death-step7.module').then( m => m.AdviceOfDeathStep7PageModule)
  },
  {
    path: 'advice-of-death-step8',
    loadChildren: () => import('./advice-of-death-step8/advice-of-death-step8.module').then( m => m.AdviceOfDeathStep8PageModule)
  },
  {
    path: 'advice-of-death-step9',
    loadChildren: () => import('./advice-of-death-step9/advice-of-death-step9.module').then( m => m.AdviceOfDeathStep9PageModule)
  },
  {
    path: 'advice-of-death-step10',
    loadChildren: () => import('./advice-of-death-step10/advice-of-death-step10.module').then( m => m.AdviceOfDeathStep10PageModule)
  },
  {
    path: 'advice-of-death-step11',
    loadChildren: () => import('./advice-of-death-step11/advice-of-death-step11.module').then( m => m.AdviceOfDeathStep11PageModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdviceOfDeathPageRoutingModule {}
