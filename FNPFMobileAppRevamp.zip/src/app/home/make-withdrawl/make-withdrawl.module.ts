import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MakeWithdrawlPageRoutingModule } from './make-withdrawl-routing.module';

import { MakeWithdrawlPage } from './make-withdrawl.page';
import { MessagesModule } from "../../app-core/template/messages/messages.module";

@NgModule({
    declarations: [MakeWithdrawlPage],
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        MakeWithdrawlPageRoutingModule,
        MessagesModule
    ]
})
export class MakeWithdrawlPageModule {}
