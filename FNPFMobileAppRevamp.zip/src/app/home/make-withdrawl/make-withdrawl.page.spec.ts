import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MakeWithdrawlPage } from './make-withdrawl.page';

describe('MakeWithdrawlPage', () => {
  let component: MakeWithdrawlPage;
  let fixture: ComponentFixture<MakeWithdrawlPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(MakeWithdrawlPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
