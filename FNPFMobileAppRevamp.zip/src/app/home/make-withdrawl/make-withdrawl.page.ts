import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from 'src/app/app.service';

@Component({
  selector: 'app-make-withdrawl',
  templateUrl: './make-withdrawl.page.html',
  styleUrls: ['./make-withdrawl.page.scss'],
})
export class MakeWithdrawlPage implements OnInit {
  constructor(public appService: AppService, public router: Router) {}

  ngOnInit() {}
  fullWithdrawal() {
    this.router.navigateByUrl('/home/make-withdrawl/full-withdrawl');
  }
  partialWithdrawal() {
    this.router.navigateByUrl('/home/make-withdrawl/partial-withdrawl');
  }
  government() {
    this.router.navigateByUrl('/home/make-withdrawl/government-assistance');
  }

  backToMain() {
    this.router.navigateByUrl('/home');
  }
}
