import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { FullWithdrawlPageRoutingModule } from './full-withdrawl-routing.module';

import { FullWithdrawlPage } from './full-withdrawl.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    FullWithdrawlPageRoutingModule
  ],
  declarations: [FullWithdrawlPage]
})
export class FullWithdrawlPageModule {}
