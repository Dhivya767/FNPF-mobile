import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from 'src/app/app.service';
import { busUIMemberProfile } from 'src/app/common/api-services/admin-api/admin-api.classes';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { SmallAccountsService } from './small-accounts/small-accounts.service';

@Component({
  selector: 'app-full-withdrawl',
  templateUrl: './full-withdrawl.page.html',
  styleUrls: ['./full-withdrawl.page.scss'],
})
export class FullWithdrawlPage implements OnInit {
  memberProfile = new busUIMemberProfile();
  constructor(
    public appService: AppService,
    public router: Router,
    public applicationService: ApplicationApiService,
    public data: DataService,
    public smallAccountsService: SmallAccountsService
  ) {}

  ngOnInit() {}

  lowBalance() {
    let obj = {
      fnpfid: this.memberProfile.fnpf_no,
    };

    this.applicationService
      .createNewLowBalanceWithdrawalApplication(obj)
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.smallAccountsService.memProfile = this.memberProfile;
          this.smallAccountsService.lowBalanceWithdrawalApplication = success;
          this.smallAccountsService.DDL.ddlGenderValue =
            this.smallAccountsService.lowBalanceWithdrawalApplication.ilstUIGenderValue;
          this.smallAccountsService.DDL.ddlPreferredCommunication =
            this.smallAccountsService.lowBalanceWithdrawalApplication.ilstUIPreferredCommunicationValue;
          this.smallAccountsService.DDL.ddlPaymentModeValue =
            this.smallAccountsService.lowBalanceWithdrawalApplication.ilstUIPaymentModeValue;
          this.smallAccountsService.DDL.ddlAddressTypeValue =
            this.smallAccountsService.lowBalanceWithdrawalApplication.ilstUIAddressType;
          this.smallAccountsService.DDL.ddlCountryValue =
            this.smallAccountsService.lowBalanceWithdrawalApplication.ilstUICountry;
          this.smallAccountsService.DDL.ddlZone =
            this.smallAccountsService.lowBalanceWithdrawalApplication.ilstUIZone;
          this.smallAccountsService.DDL.ddltEligibilityStatement =
            this.smallAccountsService.lowBalanceWithdrawalApplication.ilstEligibilityStatement;
          this.router.navigateByUrl('/home/small-accounts-step1');
        }
      });
  }
  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
}
