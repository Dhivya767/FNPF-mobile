import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FullWithdrawlPage } from './full-withdrawl.page';

const routes: Routes = [
  {
    path: '',
    component: FullWithdrawlPage,
  },
  {
    path: 'small-accounts-step1',
    loadChildren: () =>
      import(
        './small-accounts/small-accounts-step1/small-accounts-step1.module'
      ).then((m) => m.SmallAccountsStep1PageModule),
  },
  {
    path: 'small-accounts-step2',
    loadChildren: () =>
      import(
        './small-accounts/small-accounts-step2/small-accounts-step2.module'
      ).then((m) => m.SmallAccountsStep2PageModule),
  },
  {
    path: 'small-accounts-step3',
    loadChildren: () =>
      import(
        './small-accounts/small-accounts-step3/small-accounts-step3.module'
      ).then((m) => m.SmallAccountsStep3PageModule),
  },
  {
    path: 'small-accounts-step4',
    loadChildren: () =>
      import(
        './small-accounts/small-accounts-step4/small-accounts-step4.module'
      ).then((m) => m.SmallAccountsStep4PageModule),
  },
  {
    path: 'small-accounts-step5',
    loadChildren: () =>
      import(
        './small-accounts/small-accounts-step5/small-accounts-step5.module'
      ).then((m) => m.SmallAccountsStep5PageModule),
  },
  {
    path: 'small-accounts-step6',
    loadChildren: () =>
      import(
        './small-accounts/small-accounts-step6/small-accounts-step6.module'
      ).then((m) => m.SmallAccountsStep6PageModule),
  },
  {
    path: 'small-accounts-step7',
    loadChildren: () =>
      import(
        './small-accounts/small-accounts-step7/small-accounts-step7.module'
      ).then((m) => m.SmallAccountsStep7PageModule),
  },
  {
    path: 'small-accounts-step8',
    loadChildren: () =>
      import(
        './small-accounts/small-accounts-step8/small-accounts-step8.module'
      ).then((m) => m.SmallAccountsStep8PageModule),
  },
  {
    path: 'small-accounts-step9',
    loadChildren: () =>
      import(
        './small-accounts/small-accounts-step9/small-accounts-step9.module'
      ).then((m) => m.SmallAccountsStep9PageModule),
  },
  {
    path: 'small-accounts-step10',
    loadChildren: () =>
      import(
        './small-accounts/small-accounts-step10/small-accounts-step10.module'
      ).then((m) => m.SmallAccountsStep10PageModule),
  },
  {
    path: 'small-accounts-step11',
    loadChildren: () =>
      import(
        './small-accounts/small-accounts-step11/small-accounts-step11.module'
      ).then((m) => m.SmallAccountsStep11PageModule),
  },
  {
    path: 'small-accounts-step14',
    loadChildren: () =>
      import(
        './small-accounts/small-accounts-step14/small-accounts-step14.module'
      ).then((m) => m.SmallAccountsStep14PageModule),
  },
  {
    path: 'small-accounts-step12',
    loadChildren: () =>
      import(
        './small-accounts/small-accounts-step12/small-accounts-step12.module'
      ).then((m) => m.SmallAccountsStep12PageModule),
  },
  {
    path: 'small-accounts-step13',
    loadChildren: () =>
      import(
        './small-accounts/small-accounts-step13/small-accounts-step13.module'
      ).then((m) => m.SmallAccountsStep13PageModule),
  },
  {
    path: 'small-accounts-step15',
    loadChildren: () =>
      import(
        './small-accounts/small-accounts-step15/small-accounts-step15.module'
      ).then((m) => m.SmallAccountsStep15PageModule),
  },
  {
    path: 'small-accounts-step16',
    loadChildren: () => import('./small-accounts/small-accounts-step16/small-accounts-step16.module').then( m => m.SmallAccountsStep16PageModule)
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FullWithdrawlPageRoutingModule {}
