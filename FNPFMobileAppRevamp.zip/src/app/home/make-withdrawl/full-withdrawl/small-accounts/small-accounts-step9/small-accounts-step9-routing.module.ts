import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SmallAccountsStep9Page } from './small-accounts-step9.page';

const routes: Routes = [
  {
    path: '',
    component: SmallAccountsStep9Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SmallAccountsStep9PageRoutingModule {}
