import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { AppService } from 'src/app/app.service';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { SmallAccountsService } from '../small-accounts.service';

@Component({
  selector: 'app-small-accounts-step9',
  templateUrl: './small-accounts-step9.page.html',
  styleUrls: ['./small-accounts-step9.page.scss'],
})
export class SmallAccountsStep9Page implements OnInit {
  ddlPaymentModeValue: any = [];
  constructor(
    public appService: AppService,
    public smallAccountService: SmallAccountsService,
    public data: DataService,
    public alertController: AlertController,
    public applicationService: ApplicationApiService,
    public router: Router
  ) {
    this.ddlPaymentModeValue = this.smallAccountService.DDL.ddlPaymentModeValue;
  }

  ngOnInit() {}

  goNext() {
    if (
      !this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIAppWithdrawalUnemploymentAdditionalInfo.payment_mode_value ||
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIAppWithdrawalUnemploymentAdditionalInfo.payment_mode_value ===
        '' ||
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIAppWithdrawalUnemploymentAdditionalInfo.payment_mode_value
        .length == 0
    ) {
      this.data.getErrorMessageByCode('23', this.appService.appMessages);

      return;
    }

    if (
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIAppWithdrawalUnemploymentAdditionalInfo.payment_mode_value !==
      'DDBA'
    ) {
      this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_org_id = 0;
      this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_org_ref_no =
        '';
      this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_name =
        '';
      this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_account_id = 0;
    }

    this.applicationService
      .updateLowBalanceWithdrawalApplication(
        this.smallAccountService.lowBalanceWithdrawalApplication
      )
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.smallAccountService.lowBalanceWithdrawalApplication = success;
          this.smallAccountService.DDL.PostOffices =
            this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalUnemploymentAdditionalInfo.ilstUIPostOffices;
          this.smallAccountService.DDL.Banks =
            this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalUnemploymentAdditionalInfo.ilstUIBanks;
          this.smallAccountService.DDL.PreviouslyUsedBanks =
            this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalUnemploymentAdditionalInfo.ilstUIPreviouslyUsedBank;
          this.router.navigateByUrl(
            '/home/make-withdrawl/full-withdrawl/small-accounts-step10'
          );
        }
      });
  }
  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
  goHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
}
