import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SmallAccountsStep9PageRoutingModule } from './small-accounts-step9-routing.module';

import { SmallAccountsStep9Page } from './small-accounts-step9.page';
import { MessagesModule } from '../../../../../app-core/template/messages/messages.module';

@NgModule({
  declarations: [SmallAccountsStep9Page],
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SmallAccountsStep9PageRoutingModule,
    MessagesModule,
  ],
})
export class SmallAccountsStep9PageModule {}
