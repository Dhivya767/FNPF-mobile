import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SmallAccountsStep9Page } from './small-accounts-step9.page';

describe('SmallAccountsStep9Page', () => {
  let component: SmallAccountsStep9Page;
  let fixture: ComponentFixture<SmallAccountsStep9Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(SmallAccountsStep9Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
