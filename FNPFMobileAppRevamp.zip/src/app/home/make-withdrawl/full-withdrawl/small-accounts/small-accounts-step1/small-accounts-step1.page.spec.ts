import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SmallAccountsStep1Page } from './small-accounts-step1.page';

describe('SmallAccountsStep1Page', () => {
  let component: SmallAccountsStep1Page;
  let fixture: ComponentFixture<SmallAccountsStep1Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(SmallAccountsStep1Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
