import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { AppService } from 'src/app/app.service';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { SmallAccountsService } from '../small-accounts.service';

@Component({
  selector: 'app-small-accounts-step1',
  templateUrl: './small-accounts-step1.page.html',
  styleUrls: ['./small-accounts-step1.page.scss'],
})
export class SmallAccountsStep1Page implements OnInit {
  ddltEligibilityStatement: any = [];
  constructor(
    public dataService: DataService,
    public alertController: AlertController,
    public applicationApiService: ApplicationApiService,
    public router: Router,
    public smallAccountService: SmallAccountsService,
    public appService: AppService
  ) {
    this.ddltEligibilityStatement =
      this.smallAccountService.DDL.ddltEligibilityStatement;
  }

  ngOnInit() {}

  goNext() {
    this.router.navigateByUrl(
      '/home/make-withdrawl/full-withdrawl/small-accounts-step2'
    );
  }

  goHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
}
