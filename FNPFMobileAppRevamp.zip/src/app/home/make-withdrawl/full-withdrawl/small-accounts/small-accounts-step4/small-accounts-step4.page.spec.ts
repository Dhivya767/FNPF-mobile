import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SmallAccountsStep4Page } from './small-accounts-step4.page';

describe('SmallAccountsStep4Page', () => {
  let component: SmallAccountsStep4Page;
  let fixture: ComponentFixture<SmallAccountsStep4Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(SmallAccountsStep4Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
