import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SmallAccountsStep4PageRoutingModule } from './small-accounts-step4-routing.module';

import { SmallAccountsStep4Page } from './small-accounts-step4.page';
import { FormInputModule } from 'src/app/app-core/form-input/form-input.module';
import { MessagesModule } from 'src/app/app-core/template/messages/messages.module';

@NgModule({
  declarations: [SmallAccountsStep4Page],
  imports: [
    CommonModule,
    FormsModule,
    FormInputModule,
    IonicModule,
    SmallAccountsStep4PageRoutingModule,
    MessagesModule,
  ],
})
export class SmallAccountsStep4PageModule {}
