import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { AppService } from 'src/app/app.service';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { SmallAccountsService } from '../small-accounts.service';

@Component({
  selector: 'app-small-accounts-step4',
  templateUrl: './small-accounts-step4.page.html',
  styleUrls: ['./small-accounts-step4.page.scss'],
})
export class SmallAccountsStep4Page implements OnInit {
  errorTrue = false;
  ddlCountryValue: any = [];
  constructor(
    public appService: AppService,
    public smallAccountService: SmallAccountsService,
    public data: DataService,
    public alertController: AlertController,
    public applicationService: ApplicationApiService,
    public router: Router
  ) {}

  ngOnInit() {}
  restrictSpecialChars(event: any) {
    let newValue = event.target.value;
    let regExp = new RegExp('^[A-Za-z0-9? ]+$');
    if (!regExp.test(newValue)) {
      event.target.value = newValue.slice(0, -1);
    }
  }
  goNext() {
    if (
      !this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIPostalAddress.address_line_1 ||
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIPostalAddress.address_line_1 === '' ||
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIPostalAddress.address_line_1.length === 0
    ) {
      this.data.getErrorMessageByCode('16', this.appService.appMessages);
      return;
    }

    if (
      !this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIPostalAddress.city ||
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIPostalAddress.city === '' ||
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIPostalAddress.city.length === 0
    ) {
      this.data.getErrorMessageByCode('17', this.appService.appMessages);
      return;
    }

    if (
      !this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIPostalAddress.country_value ||
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIPostalAddress.country_value === '' ||
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIPostalAddress.country_value.length === 0
    ) {
      this.data.getErrorMessageByCode('19', this.appService.appMessages);
      return;
    }
    this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIPostalAddress.fnpf_id =
      this.smallAccountService.lowBalanceWithdrawalApplication.fnpf_id;
    this.applicationService
      .saveLowBalanceWithdrawalApplicationAddress(
        this.smallAccountService.lowBalanceWithdrawalApplication
          .ibusUIPostalAddress
      )
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIPostalAddress =
            success;
          if (
            this.smallAccountService.lowBalanceWithdrawalApplication
              .ibusUIPostalAddress.address_id > 0
          ) {
            this.smallAccountService.lowBalanceWithdrawalApplication.postal_address_id =
              this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIPostalAddress.address_id;
          }
          this.router.navigateByUrl(
            '/home/make-withdrawl/full-withdrawl/small-accounts-step5'
          );
        }
      });
  }
  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
  goHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
}
