import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { ModalController } from '@ionic/angular';
import { CameraService } from 'src/app/app-core/mobile-service/camera/camera.service';
import { SignatureComponent } from 'src/app/app-core/signature/signature.component';
import { AppService } from 'src/app/app.service';
import {
  busUIAppWithdrawalApplicationDocuments,
  busUIMemberProfile,
} from 'src/app/common/api-services/admin-api/admin-api.classes';
import { AdminApiService } from 'src/app/common/api-services/admin-api/admin-api.service';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { RegistrationService } from 'src/app/start/registration/registration.service';
import { MedicalWithdrawlService } from '../../../partial-withdrawl/medical-withdrawl/medical-withdrawl.service';
import { SmallAccountsService } from '../small-accounts.service';
@Component({
  selector: 'app-small-accounts-step13',
  templateUrl: './small-accounts-step13.page.html',
  styleUrls: ['./small-accounts-step13.page.scss'],
})
export class SmallAccountsStep13Page implements OnInit {
  canvasElement: any;
  selectedDocument = new busUIAppWithdrawalApplicationDocuments();
  imagePath = '';
  base64Image = '';
  memProfile = new busUIMemberProfile();
  memberProfiledata: any;
  constructor(
    public router: Router,
    public modalCtrl: ModalController,
    public cameraService: CameraService,
    public data: DataService,
    public appService: AppService,
    public applicationService: ApplicationApiService,
    public modal: ModalController,
    public smallAccountService: SmallAccountsService
  ) {
    this.memberProfiledata = this.smallAccountService.memProfile;
  }

  ngOnInit() {}
  fileSelected(event: any) {
    this.selectedDocument.file_name = event.fileName;
    this.selectedDocument.size = event.fileSizeinBytes;
    this.selectedDocument.type = event.fileType;
    this.selectedDocument.ImageFile = event.imageFile;
  }

  async captureImage() {
    let image = await this.cameraService.captureImage();
    if (image !== '') {
      let document = {
        fileName:
          this.selectedDocument.document_type_description +
          '_' +
          this.appService.getDateTimeStamp() +
          '.jpeg',
        imageFile: image,
        fileType: 'jpeg',
        fileSizeinBytes: 0,
      };
      this.fileSelected(document);
    }
  }

  async gotoNext() {
    if (
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIAppWithdrawalApplicationMemberPhoto
    ) {
      if (
        this.smallAccountService.lowBalanceWithdrawalApplication
          .ibusUIAppWithdrawalApplicationMemberPhoto.ImageFile === '' ||
        !this.smallAccountService.lowBalanceWithdrawalApplication
          .ibusUIAppWithdrawalApplicationMemberPhoto.ImageFile
      ) {
        this.data.getErrorMessageByCode('PTAPT', this.appService.appMessages);
        return;
      }

      this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalApplicationMemberPhoto.withdrawal_application_id =
        this.smallAccountService.lowBalanceWithdrawalApplication.withdrawal_application_id;
      this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalApplicationMemberPhoto.document_type_value =
        'MEMPT';
      this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalApplicationMemberPhoto.document_type_id = 5103;
      this.smallAccountService.lowBalanceWithdrawalApplication
        .withdrawal_application_id;
      this.saveLowBalanceWithdrawalApplicationDocument(
        this.smallAccountService.lowBalanceWithdrawalApplication
          .ibusUIAppWithdrawalApplicationMemberPhoto
      );
    }
  }
  saveLowBalanceWithdrawalApplicationDocument(document: any) {
    this.applicationService
      .saveLowBalanceWithdrawalApplicationDocument(document)
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
          this.data.getErrorMessageByCode('ICSWD', this.appService.appMessages);
        } else {
          this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalApplicationMemberPhoto =
            success;
          this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalApplicationMemberPhoto =
            this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalApplicationMemberPhoto;
          this.redirectToNextPage();
          this.imagePath = '';
          this.base64Image = '';
        }
      });
  }
  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
  redirectToNextPage() {
    let dataUrl = this.canvasElement.toDataURL();
    if (
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIAppWithdrawalApplicationMemberSignature
    ) {
      this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalApplicationMemberSignature.ImageFile =
        dataUrl;

      this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalApplicationMemberSignature.file_name =
        this.memberProfiledata.fnpf_no +
        '_' +
        'MemberSignature_' +
        this.appService.getDateTimeStamp() +
        '.jpeg';
      this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalApplicationMemberSignature.withdrawal_application_id =
        this.smallAccountService.lowBalanceWithdrawalApplication.withdrawal_application_id;
      this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalApplicationMemberSignature.document_type_value =
        'MESGN';
      this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalApplicationMemberSignature.document_type_id = 5103;
      this.saveLowBalanceWithdrawalSignature(
        this.smallAccountService.lowBalanceWithdrawalApplication
          .ibusUIAppWithdrawalApplicationMemberSignature
      );
    }
  }
  async saveLowBalanceWithdrawalSignature(val: any) {
    const modal = await this.modalCtrl.create({
      component: SignatureComponent,
      componentProps: {
        label: 'Draw your signature image',
        submitBtnText: 'Go Next',
      },
    });
    await modal.present();
    const { data } = await modal.onWillDismiss();
    if (data?.dismissed) {
      if (data.signature !== '') {
        //this.funeralService.funeralWithdrawalApplication.signature = data.signature;
        this.applicationService
          .saveMedicalWithdrawalApplicationDocument(
            this.smallAccountService.lowBalanceWithdrawalApplication
              .ibusUIAppWithdrawalApplicationMemberSignature
          )
          .subscribe((success: any) => {
            if (success?.ilstErrorMessages?.length > 0) {
              this.checkForError(success);
              this.data.getErrorMessageByCode(
                'ICSWD',
                this.appService.appMessages
              );
            } else {
              this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalApplicationMemberSignature =
                success;
              this.router.navigateByUrl(
                '/home/make-withdrawl/full-withdrawl/small-accounts-step14'
              );
            }
          });
      }
    }
  }
  goHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
}
