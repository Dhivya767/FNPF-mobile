import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SmallAccountsStep13Page } from './small-accounts-step13.page';

describe('SmallAccountsStep13Page', () => {
  let component: SmallAccountsStep13Page;
  let fixture: ComponentFixture<SmallAccountsStep13Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(SmallAccountsStep13Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
