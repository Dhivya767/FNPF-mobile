import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SmallAccountsStep13Page } from './small-accounts-step13.page';

const routes: Routes = [
  {
    path: '',
    component: SmallAccountsStep13Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SmallAccountsStep13PageRoutingModule {}
