import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SmallAccountsStep13PageRoutingModule } from './small-accounts-step13-routing.module';

import { SmallAccountsStep13Page } from './small-accounts-step13.page';
import { MessagesModule } from '../../../../../app-core/template/messages/messages.module';

@NgModule({
  declarations: [SmallAccountsStep13Page],
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SmallAccountsStep13PageRoutingModule,
    MessagesModule,
  ],
})
export class SmallAccountsStep13PageModule {}
