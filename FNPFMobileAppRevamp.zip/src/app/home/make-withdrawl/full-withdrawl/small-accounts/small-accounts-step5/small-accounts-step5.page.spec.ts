import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SmallAccountsStep5Page } from './small-accounts-step5.page';

describe('SmallAccountsStep5Page', () => {
  let component: SmallAccountsStep5Page;
  let fixture: ComponentFixture<SmallAccountsStep5Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(SmallAccountsStep5Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
