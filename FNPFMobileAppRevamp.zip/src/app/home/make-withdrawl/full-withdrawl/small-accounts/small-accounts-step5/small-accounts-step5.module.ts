import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SmallAccountsStep5PageRoutingModule } from './small-accounts-step5-routing.module';

import { SmallAccountsStep5Page } from './small-accounts-step5.page';
import { FormInputModule } from 'src/app/app-core/form-input/form-input.module';
import { MessagesModule } from 'src/app/app-core/template/messages/messages.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SmallAccountsStep5PageRoutingModule,
    FormInputModule,
    MessagesModule

  ],
  declarations: [SmallAccountsStep5Page]
})
export class SmallAccountsStep5PageModule {}
