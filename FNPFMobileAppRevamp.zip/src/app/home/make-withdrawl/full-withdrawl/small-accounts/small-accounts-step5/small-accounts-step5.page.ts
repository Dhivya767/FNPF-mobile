import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { AppService } from 'src/app/app.service';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { SmallAccountsService } from '../small-accounts.service';

@Component({
  selector: 'app-small-accounts-step5',
  templateUrl: './small-accounts-step5.page.html',
  styleUrls: ['./small-accounts-step5.page.scss'],
})
export class SmallAccountsStep5Page implements OnInit {
  errorTrue = false;
  IsSameasPostal = false;
  IsReadonly = false;
  ddlCountryValue: any = [];
  ddlZone: any = [];
  constructor(
    public appService: AppService,
    public smallAccountService: SmallAccountsService,
    public data: DataService,
    public alertController: AlertController,
    public applicationService: ApplicationApiService,
    public router: Router
  ) {
    this.ddlCountryValue = this.smallAccountService.DDL.ddlCountryValue;
    this.ddlZone = this.smallAccountService.DDL.ddlZone;
  }

  ngOnInit() {}
  restrictSpecialChars(event: any) {
    let newValue = event.target.value;
    let regExp = new RegExp('^[A-Za-z0-9? ]+$');
    if (!regExp.test(newValue)) {
      event.target.value = newValue.slice(0, -1);
    }
  }
  goNext() {
    if (
      !this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIResidentialAddress.address_line_1 ||
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIResidentialAddress.address_line_1 == '' ||
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIResidentialAddress.address_line_1.length == 0
    ) {
      this.data.getErrorMessageByCode('16', this.appService.appMessages);
      return;
    }

    if (
      !this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIResidentialAddress.city ||
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIResidentialAddress.city === '' ||
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIResidentialAddress.city.length === 0
    ) {
      this.data.getErrorMessageByCode('17', this.appService.appMessages);
      return;
    }
    if (
      !this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIResidentialAddress.country_value ||
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIResidentialAddress.country_value === '' ||
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIResidentialAddress.country_value.length === 0
    ) {
      this.data.getErrorMessageByCode('17', this.appService.appMessages);
      return;
    }
    this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIResidentialAddress.fnpf_id =
      this.smallAccountService.lowBalanceWithdrawalApplication.fnpf_id;
    this.applicationService
      .saveLowBalanceWithdrawalApplicationAddress(
        this.smallAccountService.lowBalanceWithdrawalApplication
          .ibusUIResidentialAddress
      )
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIResidentialAddress =
            success;
          if (
            this.smallAccountService.lowBalanceWithdrawalApplication
              .ibusUIResidentialAddress.address_id > 0
          ) {
            this.smallAccountService.lowBalanceWithdrawalApplication.residential_address_id =
              this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIResidentialAddress.address_id;
          }
          this.router.navigateByUrl(
            '/home/make-withdrawl/full-withdrawl/small-accounts-step6'
          );
        }
      });
  }
  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
  onClickSameas(val: any) {
    if (val.detail.checked) {
      this.IsSameasPostal = true;
      this.smallAccountService.lowBalanceWithdrawalApplication.same_as_postal =
        'Y';
      this.IsReadonly = true;
      this.setResidentialAddress();
    } else {
      this.IsSameasPostal = false;
      this.smallAccountService.lowBalanceWithdrawalApplication.same_as_postal =
        'N';
    }
  }
  setResidentialAddress() {
    const Postal =
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIPostalAddress;
    if (Postal) {
      this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIResidentialAddress.address_line_1 =
        Postal.address_line_1;
      this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIResidentialAddress.address_line_2 =
        Postal.address_line_2;
      this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIResidentialAddress.address_line_3 =
        Postal.address_line_3;
      this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIResidentialAddress.address_line_4 =
        Postal.address_line_4;
      this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIResidentialAddress.city =
        Postal.city;
      this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIResidentialAddress.postal_code =
        Postal.postal_code;
      this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIResidentialAddress.country_value =
        Postal.country_value;
      this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIResidentialAddress.zone_value =
        Postal.zone_value;
    }
  }
  goHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
}
