import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SmallAccountsStep14Page } from './small-accounts-step14.page';

describe('SmallAccountsStep14Page', () => {
  let component: SmallAccountsStep14Page;
  let fixture: ComponentFixture<SmallAccountsStep14Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(SmallAccountsStep14Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
