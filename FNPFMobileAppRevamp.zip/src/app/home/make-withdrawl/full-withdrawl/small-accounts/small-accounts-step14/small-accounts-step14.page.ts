import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from 'src/app/app.service';
import { busUIMemberProfile } from 'src/app/common/api-services/admin-api/admin-api.classes';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { MedicalWithdrawlService } from '../../../partial-withdrawl/medical-withdrawl/medical-withdrawl.service';
import { SmallAccountsService } from '../small-accounts.service';

@Component({
  selector: 'app-small-accounts-step14',
  templateUrl: './small-accounts-step14.page.html',
  styleUrls: ['./small-accounts-step14.page.scss'],
})
export class SmallAccountsStep14Page implements OnInit {
  isEmail = true;
  isMobile = false;
  memProfile = new busUIMemberProfile();
  constructor(
    public router: Router,
    public smallAccountService: SmallAccountsService,
    public appService: AppService,
    public applicationService: ApplicationApiService,
    public data: DataService
  ) {
    this.memProfile = this.smallAccountService.memProfile;
    this.isEmail = false;
    this.isMobile = false;
    if (this.memProfile.email_id && this.memProfile.email_id.length > 0) {
      this.isEmail = true;
    }
    if (
      this.memProfile.masked_contactno &&
      this.memProfile.masked_contactno.length > 0
    ) {
      this.isMobile = true;
    }
  }

  ngOnInit() {}
  goToHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
  sendOTPToEmailForLowBalanceWithdrawal() {
    let obj = {
      istApplicationId:
        this.smallAccountService.lowBalanceWithdrawalApplication
          .withdrawal_application_id,
      istrEmailId: this.memProfile.email_id,
    };
    this.applicationService
      .sendOTPToEmailForLowBalanceWithdrawal(obj)
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
          this.data.getErrorMessageByCode('ICSWD', this.appService.appMessages);
        } else {
          this.smallAccountService.lowBalanceWithdrawalApplication.otp =
            success.otp;
          this.smallAccountService.lowBalanceWithdrawalApplication.otp_generated_time =
            success.otp_generated_time;
          this.smallAccountService.emailTo = 'Email';
          this.router.navigateByUrl(
            '/home/make-withdrawl/full-withdrawl/small-accounts-step15'
          );
        }
      });
  }
  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
  sendOTPToMobileForLowBalanceWithdrawal() {
    let obj = {
      istApplicationId:
        this.smallAccountService.lowBalanceWithdrawalApplication
          .withdrawal_application_id,
      istrMobileId: this.memProfile.mobile_no,
    };
    this.applicationService
      .sendOTPToMobileForLowBalanceWithdrawal(obj)
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
          this.data.getErrorMessageByCode('ICSWD', this.appService.appMessages);
        } else {
          this.smallAccountService.lowBalanceWithdrawalApplication.otp =
            success.otp;
          this.smallAccountService.lowBalanceWithdrawalApplication.otp_generated_time =
            success.otp_generated_time;
          this.smallAccountService.emailTo = 'Mobile';
          this.router.navigateByUrl(
            '/home/make-withdrawl/full-withdrawl/small-accounts-step15'
          );
        }
      });
  }

  goHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
}
