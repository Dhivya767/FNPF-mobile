import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SmallAccountsStep14Page } from './small-accounts-step14.page';

const routes: Routes = [
  {
    path: '',
    component: SmallAccountsStep14Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SmallAccountsStep14PageRoutingModule {}
