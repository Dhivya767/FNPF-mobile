import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SmallAccountsStep14PageRoutingModule } from './small-accounts-step14-routing.module';

import { SmallAccountsStep14Page } from './small-accounts-step14.page';
import { MessagesModule } from '../../../../../app-core/template/messages/messages.module';

@NgModule({
  declarations: [SmallAccountsStep14Page],
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SmallAccountsStep14PageRoutingModule,
    MessagesModule,
  ],
})
export class SmallAccountsStep14PageModule {}
