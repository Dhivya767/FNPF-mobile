import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SmallAccountsStep16Page } from './small-accounts-step16.page';

const routes: Routes = [
  {
    path: '',
    component: SmallAccountsStep16Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SmallAccountsStep16PageRoutingModule {}
