import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SmallAccountsStep16Page } from './small-accounts-step16.page';

describe('SmallAccountsStep16Page', () => {
  let component: SmallAccountsStep16Page;
  let fixture: ComponentFixture<SmallAccountsStep16Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(SmallAccountsStep16Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
