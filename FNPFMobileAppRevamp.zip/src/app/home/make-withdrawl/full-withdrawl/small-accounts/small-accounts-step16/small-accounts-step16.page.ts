import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NavController, AlertController } from '@ionic/angular';
import { FileSystemService } from 'src/app/app-core/mobile-service/file-system/file-system.service';
import { AppService } from 'src/app/app.service';
import { busUIMemberProfile } from 'src/app/common/api-services/admin-api/admin-api.classes';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { MedicalWithdrawlService } from '../../../partial-withdrawl/medical-withdrawl/medical-withdrawl.service';
import { SmallAccountsService } from '../small-accounts.service';

@Component({
  selector: 'app-small-accounts-step16',
  templateUrl: './small-accounts-step16.page.html',
  styleUrls: ['./small-accounts-step16.page.scss'],
})
export class SmallAccountsStep16Page implements OnInit {
  stars: any = [];
  starRating = 0;
  deceasedPersonName = '';
  memberProfile = new busUIMemberProfile();
  fileContent = '';
  downloadPath = '';
  emailMsg = '';
  isEmail = false;
  student = '';
  isReceiptViewOpen = false;
  showAdultMemberRegistration = false;
  view_receipt_base64 = '';
  constructor(
    public router: Router,
    public smallAccountService: SmallAccountsService,
    public appService: AppService,
    public applicationService: ApplicationApiService,
    public data: DataService,
    public navCtrl: NavController,
    public alertCtrl: AlertController,
    public fileService: FileSystemService
  ) {
    this.stars = [1, 2, 3, 4, 5];
    this.memberProfile = this.smallAccountService.memProfile;

    this.isEmail = false;
    if (this.memberProfile.email_id && this.memberProfile.email_id.length > 0) {
      this.isEmail = true;
    }
  }

  ngOnInit() {}
  goRating(star: any) {
    this.smallAccountService.lowBalanceWithdrawalApplication.rating = star;
    this.applicationService
      .updateWithdrawalApplicationRating(
        this.smallAccountService.lowBalanceWithdrawalApplication
      )
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.smallAccountService.lowBalanceWithdrawalApplication = success;
        }
      });
  }
  goToWithdrawalHistory() {
    this.applicationService
      .loadWithdrawalHistory(this.memberProfile.person_id)
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
          this.data.getErrorMessageByCode('ICSWD', this.appService.appMessages);
        } else {
          this.memberProfile.ilistbusUIApplication =
            success.ilistbusUIApplication;
          this.router.navigateByUrl('/home/withdrawal-status');
        }
      });
  }
  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }

  viewReceipt() {
    this.applicationService
      .viewreceiptAdditionalContributionPayment(
        this.smallAccountService.lowBalanceWithdrawalApplication
      )
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.smallAccountService.lowBalanceWithdrawalApplication = success;
          this.view_receipt_base64 =
            'data:application/pdf;base64,' + success.view_receipt;
          this.isReceiptViewOpen = true;
        }
      });
  }
  downloadReceipt() {
    this.applicationService
      .downloadLowBalanceWithdrawalRegistrationForm(
        this.smallAccountService.lowBalanceWithdrawalApplication
          .withdrawal_application_id
      )
      .subscribe(async (success: any) => {
        if (success) {
          let name =
            this.smallAccountService.memProfile.fnpf_no +
            '_Form_' +
            this.appService.getDateTimeStamp() +
            '.pdf';
          let writeFile = await this.fileService.fetchAndWriteFile(
            success,
            name
          );
        } else {
          this.data.constructErrorMessage(
            'Unable to download statement. Please try again later.'
          );
        }
      });
  }

  emailMedicalWithdrawalRegistrationForm() {
    this.applicationService
      .emailMedicalWithdrawalRegistrationForm(
        this.smallAccountService.lowBalanceWithdrawalApplication
      )
      .subscribe(async (success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          const alert = await this.alertCtrl.create({
            message:
              'Your Registration Form has been emailed to your email address.',
            buttons: ['OK'],
          });
          await alert.present();
        }
      });
  }
  goHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
}
