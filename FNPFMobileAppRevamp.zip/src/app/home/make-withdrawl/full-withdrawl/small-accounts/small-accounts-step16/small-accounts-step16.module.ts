import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SmallAccountsStep16PageRoutingModule } from './small-accounts-step16-routing.module';

import { SmallAccountsStep16Page } from './small-accounts-step16.page';
import { RatingComponent } from '../../../../../app-core/template/rating/rating.component';
import { MessagesModule } from '../../../../../app-core/template/messages/messages.module';
import { PipesModule } from '../../../../../common/pipes/pipes.module';

@NgModule({
  declarations: [SmallAccountsStep16Page],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SmallAccountsStep16PageRoutingModule,
    RatingComponent,
    MessagesModule,
    PipesModule,
  ],
})
export class SmallAccountsStep16PageModule {}
