import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { AppService } from 'src/app/app.service';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { SmallAccountsService } from '../small-accounts.service';

@Component({
  selector: 'app-small-accounts-step10',
  templateUrl: './small-accounts-step10.page.html',
  styleUrls: ['./small-accounts-step10.page.scss'],
})
export class SmallAccountsStep10Page implements OnInit {
  errorTrue = false;
  isNewBankDetail = false;
  SelectedBankId: any;
  previouslyUsedBanks: any = [];
  PreviouslyUsedBanks: any = [];
  banks: any = [];
  IsTermsAccepted = false;
  IsNoBankSelected = false;
  selectedBankOrgId: any;
  memberProfiledata: any;
  PostOffices: any;
  SelectedBankAccountNumber: any;
  constructor(
    public appService: AppService,
    public smallAccountService: SmallAccountsService,
    public data: DataService,
    public alertController: AlertController,
    public applicationService: ApplicationApiService,
    public router: Router
  ) {
    this.isNewBankDetail = false;

    this.selectedBankOrgId = '0';
    this.SelectedBankId = '0';

    this.memberProfiledata = this.smallAccountService.memProfile;
    this.PostOffices = this.smallAccountService.DDL.PostOffices;
    this.banks = this.smallAccountService.DDL.Banks;
    this.PreviouslyUsedBanks = this.smallAccountService.DDL.PreviouslyUsedBanks;
    this.IsTermsAccepted = false;

    if (
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIAppWithdrawalUnemploymentAdditionalInfo
    ) {
      this.SelectedBankId =
        this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_account_id;
    } else {
      this.SelectedBankId = '0';
    }

    if (
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_org_id === 0 ||
      !this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_org_id
    ) {
      this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_org_id = 0;
    }

    if (
      !this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIAppWithdrawalUnemploymentAdditionalInfo.account_name ||
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIAppWithdrawalUnemploymentAdditionalInfo.account_name.length === 0
    ) {
      this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalUnemploymentAdditionalInfo.account_name =
        this.memberProfiledata.full_name;
    }
  }

  ngOnInit() {
    this.loadValuesFromIonicStorageIfExists();
    this.loadCheckbox();
    this.loadNoBank();
    this.loadPaymentModeDDLForLowBalanceWithdrawalApplication();
  }
  loadPaymentModeDDLForLowBalanceWithdrawalApplication() {
    if (this.smallAccountService.lowBalanceWithdrawalApplication) {
      this.applicationService
        .loadPaymentModeDDLForLowBalanceWithdrawalApplication(
          this.smallAccountService.lowBalanceWithdrawalApplication
        )
        .subscribe((success: any) => {
          if (success?.ilstErrorMessages?.length > 0) {
            this.data.getErrorMessageByCode(
              'ICSWD',
              this.appService.appMessages
            );
          } else {
            this.smallAccountService.lowBalanceWithdrawalApplication = success;
            this.PostOffices =
              this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalUnemploymentAdditionalInfo.ilstUIPostOffices;
            this.banks =
              this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalUnemploymentAdditionalInfo.ilstUIBanks;
            this.PreviouslyUsedBanks =
              this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalUnemploymentAdditionalInfo.ilstUIPreviouslyUsedBank;
          }
        });
    }
  }
  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
  goNext() {
    if (
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIAppWithdrawalUnemploymentAdditionalInfo.payment_mode_value ===
      'DDBA'
    ) {
      if (!this.IsNoBankSelected) {
        if (
          !this.smallAccountService.lowBalanceWithdrawalApplication
            .ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_org_id ||
          this.smallAccountService.lowBalanceWithdrawalApplication
            .ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_org_id === 0
        ) {
          //Please select bank details.
          this.data.getErrorMessageByCode('PSBKD', this.appService.appMessages);
          return;
        }

        if (
          !this.smallAccountService.lowBalanceWithdrawalApplication
            .ibusUIAppWithdrawalUnemploymentAdditionalInfo.account_no ||
          this.smallAccountService.lowBalanceWithdrawalApplication
            .ibusUIAppWithdrawalUnemploymentAdditionalInfo.account_no === '' ||
          this.smallAccountService.lowBalanceWithdrawalApplication
            .ibusUIAppWithdrawalUnemploymentAdditionalInfo.account_no.length ===
            0
        ) {
          //Please provide an Account Number.
          this.data.getErrorMessageByCode('PPACN', this.appService.appMessages);
          return;
        }

        if (
          this.SelectedBankId &&
          this.SelectedBankId !== '' &&
          this.SelectedBankId !== '0'
        ) {
          if (
            this.SelectedBankAccountNumber &&
            this.SelectedBankAccountNumber !== '' &&
            this.SelectedBankAccountNumber.length > 0
          ) {
            if (
              this.SelectedBankAccountNumber.toLowerCase() !=
              this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalUnemploymentAdditionalInfo.account_no.toLowerCase()
            ) {
              this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_account_id = 0;
            }
          }
        }
      } else {
        this.smallAccountService.lowBalanceWithdrawalApplication.no_bank_account_flag =
          'Y';
      }
    } else if (
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIAppWithdrawalUnemploymentAdditionalInfo.payment_mode_value ===
      'PTMO'
    ) {
      let MobileNo =
        this.smallAccountService.lowBalanceWithdrawalApplication
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo.payment_to_mobile_no;

      if (!MobileNo || MobileNo.length === 0) {
        //Please provide a Phone Number.
        this.data.getErrorMessageByCode('PPPNO', this.appService.appMessages);
        return;
      } else {
        if (MobileNo.length !== 7) {
          //Your phone number must have 7 digits.
          this.data.getErrorMessageByCode('YPNMD', this.appService.appMessages);
          return;
        }
      }
    } else if (
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIAppWithdrawalUnemploymentAdditionalInfo.payment_mode_value ===
      'PMMT'
    ) {
      let MobileNo =
        this.smallAccountService.lowBalanceWithdrawalApplication
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo.payment_to_mobile_no;
      if (!MobileNo || MobileNo.length === 0) {
        //Please provide a mobile number.
        this.data.getErrorMessageByCode('PPMBO', this.appService.appMessages);
        return;
      } else {
        if (MobileNo.length !== 7) {
          //Your mobile number must have 7 digits.
          this.data.getErrorMessageByCode('YMNMD', this.appService.appMessages);

          return;
        }
      }
    } else if (
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIAppWithdrawalUnemploymentAdditionalInfo.payment_mode_value ==
      'TLTR'
    ) {
      if (
        !this.smallAccountService.lowBalanceWithdrawalApplication
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_name ||
        this.smallAccountService.lowBalanceWithdrawalApplication
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_name === '' ||
        this.smallAccountService.lowBalanceWithdrawalApplication
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_name.length === 0
      ) {
        this.data.constructErrorMessage('Please enter bank name.');
        return;
      }

      if (
        !this.smallAccountService.lowBalanceWithdrawalApplication
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo.account_no ||
        this.smallAccountService.lowBalanceWithdrawalApplication
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo.account_no === '' ||
        this.smallAccountService.lowBalanceWithdrawalApplication
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo.account_no.length === 0
      ) {
        //Please provide an Account Number.
        this.data.getErrorMessageByCode('PPACN', this.appService.appMessages);
        return;
      }

      if (
        !this.smallAccountService.lowBalanceWithdrawalApplication
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo.bsb_routing_no ||
        this.smallAccountService.lowBalanceWithdrawalApplication
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo.bsb_routing_no ===
          '' ||
        this.smallAccountService.lowBalanceWithdrawalApplication
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo.bsb_routing_no
          .length === 0
      ) {
        this.data.getErrorMessageByCode('27', this.appService.appMessages);

        return;
      }

      if (
        !this.smallAccountService.lowBalanceWithdrawalApplication
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo.swift_code ||
        this.smallAccountService.lowBalanceWithdrawalApplication
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo.swift_code === '' ||
        this.smallAccountService.lowBalanceWithdrawalApplication
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo.swift_code.length === 0
      ) {
        this.data.getErrorMessageByCode('28', this.appService.appMessages);

        return;
      }

      if (
        !this.smallAccountService.lowBalanceWithdrawalApplication
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_address ||
        this.smallAccountService.lowBalanceWithdrawalApplication
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_address === '' ||
        this.smallAccountService.lowBalanceWithdrawalApplication
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_address.length ===
          0
      ) {
        this.data.getErrorMessageByCode('29', this.appService.appMessages);
        return;
      }

      if (
        this.SelectedBankId &&
        this.SelectedBankId !== '' &&
        this.SelectedBankId !== '0'
      ) {
        if (
          this.SelectedBankAccountNumber &&
          this.SelectedBankAccountNumber !== '' &&
          this.SelectedBankAccountNumber.length > 0
        ) {
          if (
            this.SelectedBankAccountNumber.toLowerCase() !=
            this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalUnemploymentAdditionalInfo.account_no.toLowerCase()
          ) {
            this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_account_id = 0;
          }
        }
      }
    }

    if (!this.IsNoBankSelected) {
      if (this.IsTermsAccepted) {
        this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalUnemploymentAdditionalInfo.is_payment_deposits_agree =
          'Y';
      } else {
        //You must confirm to the above  by selecting the check-box to proceed.
        this.data.getErrorMessageByCode('YMCTP', this.appService.appMessages);
        this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalUnemploymentAdditionalInfo.is_payment_deposits_agree =
          'N';
        return;
      }
    }
    this.updateApplication();
  }
  updateApplication() {
    if (this.smallAccountService.lowBalanceWithdrawalApplication) {
      this.applicationService
        .updateLowBalanceWithdrawalApplication(
          this.smallAccountService.lowBalanceWithdrawalApplication
        )
        .subscribe((success: any) => {
          if (success?.ilstErrorMessages?.length > 0) {
            this.data.getErrorMessageByCode(
              'ICSWD',
              this.appService.appMessages
            );
          } else {
            this.smallAccountService.lowBalanceWithdrawalApplication = success;
            this.router.navigateByUrl(
              '/home/make-withdrawl/full-withdrawl/small-accounts-step12'
            );
          }
        });
    }
  }
  goHome() {
    this.router.navigateByUrl('/home/my-balance');
  }

  onChangeAccountNo(AccountNo: any) {
    let ACtNo = AccountNo;
    let BankName =
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_name;
    let OrgRefNo =
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_org_ref_no;
    this.checkAccountNo(ACtNo, BankName, OrgRefNo);
  }
  checkAccountNo(ACtNo: any, BankName: any, OrgRefNo: any) {
    if (ACtNo && ACtNo.length > 0 && BankName && BankName.length > 0) {
      let IsValid = true;

      if (
        BankName.includes('WESTPAC BANKING CORP') ||
        OrgRefNo == 'EN10126491H'
      ) {
        if (ACtNo.length < 8 || ACtNo.length > 10) {
          IsValid = false;
        }
        if (!this.IsValidAccount(ACtNo)) {
          IsValid = false;
        }

        if (!IsValid) {
          //Do note that the bank account number provided is NOT a normal Westpac bank account number. Click "Next" only if you are sure that this is the correct bank account number.
          this.data.getErrorMessageByCode('NWPBA', this.appService.appMessages);
        }
      } else if (
        BankName.includes('ANZ BANKING GRP LTD') ||
        OrgRefNo == 'EN10126488U'
      ) {
        if (ACtNo.length < 6 || ACtNo.length > 8) {
          IsValid = false;
        }
        if (!this.IsValidAccount(ACtNo)) {
          IsValid = false;
        }
        if (!IsValid) {
          //Do note that the bank account number provided is NOT a normal ANZ bank account number. Click "Next" only if you are sure that this is the correct bank account number.
          this.data.getErrorMessageByCode('NAZBA', this.appService.appMessages);
        }
      } else if (
        BankName.includes('BANK OF BARODA') ||
        OrgRefNo == 'EN10126492K'
      ) {
        if (ACtNo.length != 14) {
          IsValid = false;
        }
        if (!this.IsValidAccount(ACtNo)) {
          IsValid = false;
        }
        if (!IsValid) {
          //Do note that the bank account number provided is NOT a normal BoB bank account number. Click "Next" only if you are sure that this is the correct bank account number.
          this.data.getErrorMessageByCode('NBOBA', this.appService.appMessages);
        }
      } else if (
        BankName.includes('HOME FINANCE COMPANY LIMITED') ||
        OrgRefNo == 'EN10010979G'
      ) {
        if (ACtNo.length < 6 || ACtNo.length > 8) {
          IsValid = false;
        }
        if (this.checkCharcter('s', ACtNo) == -1) {
          IsValid = false;
        }
        let RemovedString = this.removeCharcter('s', ACtNo);
        if (!this.IsValidAccount(RemovedString)) {
          IsValid = false;
        }

        if (!IsValid) {
          //Do note that the bank account number provided is NOT a normal HFC bank account number. Click "Next" only if you are sure that this is the correct bank account number.
          this.data.getErrorMessageByCode('NHFCA', this.appService.appMessages);
        }
      } else if (
        BankName.includes('BANK OF SOUTH PACIFIC') ||
        OrgRefNo == 'EN10126489W'
      ) {
        if (ACtNo.length < 7 || ACtNo.length > 8) {
          IsValid = false;
        }
        if (!this.IsValidAccount(ACtNo)) {
          IsValid = false;
        }

        if (!IsValid) {
          //Do note that the bank account number provided is NOT a normal BSP bank account number. Click "Next" only if you are sure that this is the correct bank account number.
          this.data.getErrorMessageByCode('NBSPA', this.appService.appMessages);
        }
      } else if (
        BankName.includes('BRED BANK (FIJI) LIMITED') ||
        OrgRefNo == 'EN10021248B'
      ) {
        if (ACtNo.length != 11) {
          IsValid = false;
        }
        if (!this.IsValidAccount(ACtNo)) {
          IsValid = false;
        }

        if (!IsValid) {
          //Do note that the bank account number provided is NOT a normal Bred bank account number. Click "Next" only if you are sure that this is the correct bank account number.
          this.data.getErrorMessageByCode('NBRDA', this.appService.appMessages);
        }
      }
    }
  }
  public removeCharcter(Character: any, string: any) {
    let Account = string.toLowerCase();
    let Char = Character.toLowerCase();
    let reg = new RegExp(Char);
    return Account.replace(reg, '');
  }

  public checkCharcter(Character: any, string: any) {
    let Account = string.toLowerCase();
    let Char = Character.toLowerCase();

    return Account.indexOf(Char);
  }
  public IsValidAccount(AccountNo: any) {
    var NumericValidation = /^[0-9()+]+$/;
    return NumericValidation.test(AccountNo);
  }
  onChangeBank(BankOrgId: any) {
    if (this.banks && this.banks.length > 0) {
      for (let i = 0; i < this.banks.length; i++) {
        if (this.banks[i].config_id == BankOrgId) {
          this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_org_id =
            this.banks[i].config_id;
          this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_org_ref_no =
            this.banks[i].config_constant;
          this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_name =
            this.banks[i].config_const_description;

          if (
            this.selectedBankOrgId !==
            this.smallAccountService.lowBalanceWithdrawalApplication
              .ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_org_id
          ) {
            if (this.SelectedBankId !== ' ') {
              this.SelectedBankId = '';
            }

            this.SelectedBankAccountNumber = '';
            this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalUnemploymentAdditionalInfo.account_no =
              '';
            // this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_account_id = 0;
          }

          return;
        }
      }
    }
  }

  onChangePostOffice(PostOfficeId: any) {
    if (
      this.PostOffices != null &&
      this.PostOffices != undefined &&
      this.PostOffices.length > 0
    ) {
      for (let i = 0; i < this.PostOffices.length; i++) {
        if (this.PostOffices[i].config_id == PostOfficeId) {
          this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalUnemploymentAdditionalInfo.post_office_org_ref_no =
            this.PostOffices[i].config_constant;
          this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalUnemploymentAdditionalInfo.nearest_post_office_name =
            this.PostOffices[i].config_const_description;
          return;
        }
      }
    }
  }

  onChangePreviouslyUsedBank(accountId: any) {
    if (accountId == ' ') {
      this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_name =
        '';
      this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_org_ref_no =
        '';
      this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_org_id = 0;
      this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_account_id = 0;
      this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalUnemploymentAdditionalInfo.account_no =
        '';
      this.SelectedBankAccountNumber = '';
      this.selectedBankOrgId = 0;
      this.isNewBankDetail = true;
      return;
    } else {
      this.isNewBankDetail = false;
    }

    if (this.PreviouslyUsedBanks && this.PreviouslyUsedBanks.length > 0) {
      for (let i = 0; i < this.PreviouslyUsedBanks.length; i++) {
        if (this.PreviouslyUsedBanks[i].bank_account_id == accountId) {
          this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_name =
            this.PreviouslyUsedBanks[i].bank_name;
          this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_org_ref_no =
            this.PreviouslyUsedBanks[i].bank_org_ref_no;
          this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_org_id =
            this.PreviouslyUsedBanks[i].bank_id;
          this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalUnemploymentAdditionalInfo.bank_account_id =
            this.PreviouslyUsedBanks[i].bank_account_id;
          this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalUnemploymentAdditionalInfo.account_no =
            this.PreviouslyUsedBanks[i].account_number;
          this.SelectedBankAccountNumber =
            this.PreviouslyUsedBanks[i].account_number;
          this.selectedBankOrgId = this.PreviouslyUsedBanks[i].bank_id;
          return;
        }
      }
    }
  }
  loadValuesFromIonicStorageIfExists() {
    if (
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIAppWithdrawalUnemploymentAdditionalInfo.payment_mode_value !=
      'DDBA'
    ) {
      if (
        !this.smallAccountService.lowBalanceWithdrawalApplication
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo.payment_to_mobile_no ||
        this.smallAccountService.lowBalanceWithdrawalApplication
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo
          .payment_to_mobile_no === '' ||
        this.smallAccountService.lowBalanceWithdrawalApplication
          .ibusUIAppWithdrawalUnemploymentAdditionalInfo.payment_to_mobile_no
          .length === 0
      ) {
        this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIAppWithdrawalUnemploymentAdditionalInfo.payment_to_mobile_no =
          this.smallAccountService.lowBalanceWithdrawalApplication.member_contact_no;
      }
    }
  }

  onClickTerms(val: any) {
    if (val.detail.checked) {
      this.IsTermsAccepted = true;
    } else {
      this.IsTermsAccepted = false;
    }
  }

  onClickNoBank(val: any) {
    if (val.detail.checked) {
      this.IsNoBankSelected = true;
    } else {
      this.IsNoBankSelected = false;
    }
  }

  loadCheckbox() {
    if (
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIAppWithdrawalUnemploymentAdditionalInfo
        .is_payment_deposits_agree === 'Y'
    ) {
      this.IsTermsAccepted = true;
    }
  }

  loadNoBank() {
    if (
      this.smallAccountService.lowBalanceWithdrawalApplication
        .no_bank_account_flag === 'Y'
    ) {
      this.IsNoBankSelected = true;
    }
  }
}
