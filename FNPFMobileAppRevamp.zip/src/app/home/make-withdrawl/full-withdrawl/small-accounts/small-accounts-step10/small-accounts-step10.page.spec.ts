import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SmallAccountsStep10Page } from './small-accounts-step10.page';

describe('SmallAccountsStep10Page', () => {
  let component: SmallAccountsStep10Page;
  let fixture: ComponentFixture<SmallAccountsStep10Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(SmallAccountsStep10Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
