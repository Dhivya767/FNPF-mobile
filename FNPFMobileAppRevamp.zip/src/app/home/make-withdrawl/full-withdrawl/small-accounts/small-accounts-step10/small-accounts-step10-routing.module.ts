import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SmallAccountsStep10Page } from './small-accounts-step10.page';

const routes: Routes = [
  {
    path: '',
    component: SmallAccountsStep10Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SmallAccountsStep10PageRoutingModule {}
