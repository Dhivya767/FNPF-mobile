import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SmallAccountsStep10PageRoutingModule } from './small-accounts-step10-routing.module';

import { SmallAccountsStep10Page } from './small-accounts-step10.page';
import { FormInputModule } from 'src/app/app-core/form-input/form-input.module';
import { MessagesModule } from 'src/app/app-core/template/messages/messages.module';

@NgModule({
  declarations: [SmallAccountsStep10Page],
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SmallAccountsStep10PageRoutingModule,
    FormInputModule,
    MessagesModule,
  ],
})
export class SmallAccountsStep10PageModule {}
