import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-small-accounts-step11',
  templateUrl: './small-accounts-step11.page.html',
  styleUrls: ['./small-accounts-step11.page.scss'],
})
export class SmallAccountsStep11Page implements OnInit {
  constructor(public router: Router) {}

  ngOnInit() {}

  goNext() {
    this.router.navigateByUrl(
      '/home/make-withdrawl/full-withdrawl/small-accounts-step12'
    );
  }

  goHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
}
