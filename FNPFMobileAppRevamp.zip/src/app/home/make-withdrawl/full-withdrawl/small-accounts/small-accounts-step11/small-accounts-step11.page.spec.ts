import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SmallAccountsStep11Page } from './small-accounts-step11.page';

describe('SmallAccountsStep11Page', () => {
  let component: SmallAccountsStep11Page;
  let fixture: ComponentFixture<SmallAccountsStep11Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(SmallAccountsStep11Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
