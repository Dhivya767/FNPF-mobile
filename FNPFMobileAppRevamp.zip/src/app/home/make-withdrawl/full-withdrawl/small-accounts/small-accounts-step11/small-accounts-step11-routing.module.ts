import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SmallAccountsStep11Page } from './small-accounts-step11.page';

const routes: Routes = [
  {
    path: '',
    component: SmallAccountsStep11Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SmallAccountsStep11PageRoutingModule {}
