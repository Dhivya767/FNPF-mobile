import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SmallAccountsStep11PageRoutingModule } from './small-accounts-step11-routing.module';

import { SmallAccountsStep11Page } from './small-accounts-step11.page';
import { FormInputModule } from 'src/app/app-core/form-input/form-input.module';
import { MessagesModule } from 'src/app/app-core/template/messages/messages.module';

@NgModule({
  declarations: [SmallAccountsStep11Page],
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SmallAccountsStep11PageRoutingModule,
    FormInputModule,
    MessagesModule,
  ],
})
export class SmallAccountsStep11PageModule {}
