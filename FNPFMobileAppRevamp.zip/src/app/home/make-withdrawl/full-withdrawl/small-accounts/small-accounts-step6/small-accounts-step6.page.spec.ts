import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SmallAccountsStep6Page } from './small-accounts-step6.page';

describe('SmallAccountsStep6Page', () => {
  let component: SmallAccountsStep6Page;
  let fixture: ComponentFixture<SmallAccountsStep6Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(SmallAccountsStep6Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
