import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SmallAccountsStep6Page } from './small-accounts-step6.page';

const routes: Routes = [
  {
    path: '',
    component: SmallAccountsStep6Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SmallAccountsStep6PageRoutingModule {}
