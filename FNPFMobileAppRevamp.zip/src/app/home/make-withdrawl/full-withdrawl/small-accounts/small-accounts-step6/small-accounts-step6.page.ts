import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { AppService } from 'src/app/app.service';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { SmallAccountsService } from '../small-accounts.service';

@Component({
  selector: 'app-small-accounts-step6',
  templateUrl: './small-accounts-step6.page.html',
  styleUrls: ['./small-accounts-step6.page.scss'],
})
export class SmallAccountsStep6Page implements OnInit {
  errorTrue = false;
  ddlPreferredCommunication: any = [];
  memberProfile: any;
  constructor(
    public appService: AppService,
    public smallAccountService: SmallAccountsService,
    public data: DataService,
    public alertController: AlertController,
    public applicationService: ApplicationApiService,
    public router: Router
  ) {
    this.ddlPreferredCommunication =
      this.smallAccountService.DDL.ddlPreferredCommunication;

    this.memberProfile = this.smallAccountService.memProfile;
  }

  ngOnInit() {}

  goHome() {
    this.router.navigateByUrl('/home');
  }

  goNext() {
    if (
      !this.smallAccountService.lowBalanceWithdrawalApplication
        .preferred_communication_value ||
      this.smallAccountService.lowBalanceWithdrawalApplication
        .preferred_communication_value === '' ||
      this.smallAccountService.lowBalanceWithdrawalApplication
        .preferred_communication_value.length === 0
    ) {
      this.data.getErrorMessageByCode('10', this.appService.appMessages);
      return;
    }
    this.applicationService
      .updateLowBalanceWithdrawalApplication(
        this.smallAccountService.lowBalanceWithdrawalApplication
      )
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.smallAccountService.lowBalanceWithdrawalApplication = success;
          this.router.navigateByUrl(
            '/home/make-withdrawl/full-withdrawl/small-accounts-step7'
          );
        }
      });
  }
  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
}
