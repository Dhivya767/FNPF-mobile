import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SmallAccountsStep6PageRoutingModule } from './small-accounts-step6-routing.module';

import { SmallAccountsStep6Page } from './small-accounts-step6.page';
import { MessagesModule } from 'src/app/app-core/template/messages/messages.module';

@NgModule({
  declarations: [SmallAccountsStep6Page],
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SmallAccountsStep6PageRoutingModule,
    MessagesModule,
  ],
})
export class SmallAccountsStep6PageModule {}
