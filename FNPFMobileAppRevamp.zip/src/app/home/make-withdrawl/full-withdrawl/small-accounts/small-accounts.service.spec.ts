import { TestBed } from '@angular/core/testing';

import { SmallAccountsService } from './small-accounts.service';

describe('SmallAccountsService', () => {
  let service: SmallAccountsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SmallAccountsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
