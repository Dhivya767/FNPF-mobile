import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SmallAccountsStep8PageRoutingModule } from './small-accounts-step8-routing.module';

import { SmallAccountsStep8Page } from './small-accounts-step8.page';
import { FormInputModule } from 'src/app/app-core/form-input/form-input.module';
import { MessagesModule } from '../../../../../app-core/template/messages/messages.module';

@NgModule({
  declarations: [SmallAccountsStep8Page],
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SmallAccountsStep8PageRoutingModule,
    FormInputModule,
    MessagesModule,
  ],
})
export class SmallAccountsStep8PageModule {}
