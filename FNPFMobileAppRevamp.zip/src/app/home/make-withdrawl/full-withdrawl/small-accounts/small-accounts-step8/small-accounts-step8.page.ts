import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { AppService } from 'src/app/app.service';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { SmallAccountsService } from '../small-accounts.service';
import { format } from 'date-fns';

@Component({
  selector: 'app-small-accounts-step8',
  templateUrl: './small-accounts-step8.page.html',
  styleUrls: ['./small-accounts-step8.page.scss'],
})
export class SmallAccountsStep8Page implements OnInit {
  showList = false;
  LastEmployementEndDate: any;
  ddlCountryValue: any = [];
  ddlZone: any = [];
  constructor(
    public appService: AppService,
    public smallAccountService: SmallAccountsService,
    public data: DataService,
    public alertController: AlertController,
    public applicationService: ApplicationApiService,
    public router: Router
  ) {
    this.ddlCountryValue = this.smallAccountService.DDL.ddlCountryValue;
    this.ddlZone = this.smallAccountService.DDL.ddlZone;

    this.LastEmployementEndDate =
      this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIWithdrawalApplicationLastEmployementHistory.last_employement_end_date;
  }

  ngOnInit() {}
  restrictSpecialChars(event: any) {
    let newValue = event.target.value;
    let regExp = new RegExp('^[A-Za-z0-9? ]+$');
    if (!regExp.test(newValue)) {
      event.target.value = newValue.slice(0, -1);
    }
  }
  clickEmpname(data: any) {
    if (data) {
      this.showList = false;
      this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIWithdrawalApplicationLastEmployementHistory.employer_name =
        data.employer;

      if (data.end_date) {
        this.LastEmployementEndDate = data.end_date;
      } else {
        this.LastEmployementEndDate = '';
      }
    }
  }
  hideShowList() {
    this.showList = false;
  }
  showShowList() {
    this.showList = true;
  }
  goNext() {
    if (
      !this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIWithdrawalApplicationLastEmployementHistory.employer_name ||
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIWithdrawalApplicationLastEmployementHistory.employer_name ===
        '' ||
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIWithdrawalApplicationLastEmployementHistory.employer_name
        .length == 0
    ) {
      this.data.getErrorMessageByCode('20', this.appService.appMessages);
      return;
    }

    if (
      !this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIWithdrawalApplicationLastEmployementHistory.ibusUIAppAddress
        .address_line_1 ||
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIWithdrawalApplicationLastEmployementHistory.ibusUIAppAddress
        .address_line_1 === '' ||
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIWithdrawalApplicationLastEmployementHistory.ibusUIAppAddress
        .address_line_1.length == 0
    ) {
      this.data.getErrorMessageByCode('16', this.appService.appMessages);
      return;
    }

    if (
      !this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIWithdrawalApplicationLastEmployementHistory.ibusUIAppAddress
        .city ||
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIWithdrawalApplicationLastEmployementHistory.ibusUIAppAddress
        .city === '' ||
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIWithdrawalApplicationLastEmployementHistory.ibusUIAppAddress.city
        .length === 0
    ) {
      this.data.getErrorMessageByCode('17', this.appService.appMessages);
      return;
    }

    if (
      !this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIWithdrawalApplicationLastEmployementHistory.ibusUIAppAddress
        .country_value ||
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIWithdrawalApplicationLastEmployementHistory.ibusUIAppAddress
        .country_value === '' ||
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIWithdrawalApplicationLastEmployementHistory.ibusUIAppAddress
        .country_value.length === 0
    ) {
      this.data.getErrorMessageByCode('19', this.appService.appMessages);
      return;
    }

    if (this.LastEmployementEndDate) {
      let LastEmployementEndDate = format(
        new Date(this.LastEmployementEndDate),
        'dd/MM/yyyy'
      );

      this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIWithdrawalApplicationLastEmployementHistory.last_employement_end_date =
        LastEmployementEndDate;
    }

    this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIWithdrawalApplicationLastEmployementHistory.is_last_employement =
      'Y';

    this.applicationService
      .saveLowBalanceWithdrawalApplicationLastEmployementHistory(
        this.smallAccountService.lowBalanceWithdrawalApplication
      )
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.smallAccountService.lowBalanceWithdrawalApplication = success;
          this.router.navigateByUrl(
            '/home/make-withdrawl/full-withdrawl/small-accounts-step9'
          );
        }
      });
  }
  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
  goHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
}
