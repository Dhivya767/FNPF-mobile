import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SmallAccountsStep8Page } from './small-accounts-step8.page';

describe('SmallAccountsStep8Page', () => {
  let component: SmallAccountsStep8Page;
  let fixture: ComponentFixture<SmallAccountsStep8Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(SmallAccountsStep8Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
