import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { format } from 'date-fns';
import { AppService } from 'src/app/app.service';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { SmallAccountsService } from '../small-accounts.service';

@Component({
  selector: 'app-small-accounts-step2',
  templateUrl: './small-accounts-step2.page.html',
  styleUrls: ['./small-accounts-step2.page.scss'],
})
export class SmallAccountsStep2Page implements OnInit {
  smallAccountMemberDOB: any;
  errorTrue = false;
  ddlGenderValue: any = [];
  constructor(
    public data: DataService,
    public alertController: AlertController,
    public applicationApiService: ApplicationApiService,
    public appService: AppService,
    public router: Router,
    public smallAccountService: SmallAccountsService
  ) {
    this.ddlGenderValue = this.smallAccountService.DDL.ddlGenderValue;
    this.smallAccountMemberDOB =
      this.smallAccountService.lowBalanceWithdrawalApplication.dob;
  }

  ngOnInit() {}
  restrictSpecialChars(event: any) {
    let newValue = event.target.value;
    let regExp = new RegExp('^[A-Za-z0-9? ]+$');
    if (!regExp.test(newValue)) {
      event.target.value = newValue.slice(0, -1);
    }
  }
  goNext() {
    if (
      !this.smallAccountService.lowBalanceWithdrawalApplication.tin ||
      this.smallAccountService.lowBalanceWithdrawalApplication.tin === '' ||
      this.smallAccountService.lowBalanceWithdrawalApplication.tin.length === 0
    ) {
      this.data.getErrorMessageByCode('7', this.appService.appMessages);
      return;
    }

    if (
      !this.smallAccountService.lowBalanceWithdrawalApplication.brn ||
      this.smallAccountService.lowBalanceWithdrawalApplication.brn === '' ||
      this.smallAccountService.lowBalanceWithdrawalApplication.brn.length == 0
    ) {
      this.data.getErrorMessageByCode('8', this.appService.appMessages);
      return;
    }

    if (
      !this.smallAccountMemberDOB ||
      this.smallAccountMemberDOB.length === 0
    ) {
      this.data.getErrorMessageByCode('15', this.appService.appMessages);
      return;
    } else {
      let convertedDate = format(
        new Date(this.smallAccountMemberDOB),
        'dd/MM/yyyy'
      );
      this.smallAccountService.lowBalanceWithdrawalApplication.dob =
        convertedDate;
      this.smallAccountService.lowBalanceWithdrawalApplication.dob =
        this.smallAccountMemberDOB;
    }

    if (
      !this.smallAccountService.lowBalanceWithdrawalApplication.gender_value ||
      this.smallAccountService.lowBalanceWithdrawalApplication.gender_value ===
        '' ||
      this.smallAccountService.lowBalanceWithdrawalApplication.gender_value
        .length == 0
    ) {
      this.data.getErrorMessageByCode('9', this.appService.appMessages);
      return;
    }

    this.applicationApiService
      .saveLowBalanceWithdrawalApplication(
        this.smallAccountService.lowBalanceWithdrawalApplication
      )
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.smallAccountService.lowBalanceWithdrawalApplication = success;
          this.router.navigateByUrl(
            '/home/make-withdrawl/full-withdrawl/small-accounts-step3'
          );
        }
      });
  }

  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }

  goHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
}
