import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SmallAccountsStep2PageRoutingModule } from './small-accounts-step2-routing.module';

import { SmallAccountsStep2Page } from './small-accounts-step2.page';
import { MessagesModule } from 'src/app/app-core/template/messages/messages.module';
import { FormInputModule } from 'src/app/app-core/form-input/form-input.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SmallAccountsStep2PageRoutingModule,
    MessagesModule,
    FormInputModule
  ],
  declarations: [SmallAccountsStep2Page]
})
export class SmallAccountsStep2PageModule {}
