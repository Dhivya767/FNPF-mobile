import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SmallAccountsStep12Page } from './small-accounts-step12.page';

const routes: Routes = [
  {
    path: '',
    component: SmallAccountsStep12Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SmallAccountsStep12PageRoutingModule {}
