import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SmallAccountsStep12PageRoutingModule } from './small-accounts-step12-routing.module';

import { SmallAccountsStep12Page } from './small-accounts-step12.page';
import { MessagesModule } from 'src/app/app-core/template/messages/messages.module';
import { FileUploadComponent } from '../../../../../app-core/template/file-upload/file-upload.component';

@NgModule({
  declarations: [SmallAccountsStep12Page],
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SmallAccountsStep12PageRoutingModule,
    MessagesModule,
    FileUploadComponent,
  ],
})
export class SmallAccountsStep12PageModule {}
