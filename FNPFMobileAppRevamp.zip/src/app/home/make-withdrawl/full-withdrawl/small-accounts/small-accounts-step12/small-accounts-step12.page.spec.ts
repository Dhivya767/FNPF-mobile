import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SmallAccountsStep12Page } from './small-accounts-step12.page';

describe('SmallAccountsStep12Page', () => {
  let component: SmallAccountsStep12Page;
  let fixture: ComponentFixture<SmallAccountsStep12Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(SmallAccountsStep12Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
