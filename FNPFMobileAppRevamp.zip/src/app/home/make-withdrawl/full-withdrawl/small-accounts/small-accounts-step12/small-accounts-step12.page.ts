import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ModalController, AlertController } from '@ionic/angular';
import { CameraService } from 'src/app/app-core/mobile-service/camera/camera.service';
import { AppService } from 'src/app/app.service';
import {
  busUIAppWithdrawalApplicationDocuments,
  busUIMemberProfile,
} from 'src/app/common/api-services/admin-api/admin-api.classes';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { MedicalWithdrawlService } from '../../../partial-withdrawl/medical-withdrawl/medical-withdrawl.service';
import { SmallAccountsService } from '../small-accounts.service';

@Component({
  selector: 'app-small-accounts-step12',
  templateUrl: './small-accounts-step12.page.html',
  styleUrls: ['./small-accounts-step12.page.scss'],
})
export class SmallAccountsStep12Page implements OnInit {
  base64Image = '';
  selectedDocument = new busUIAppWithdrawalApplicationDocuments();
  selectedDocumentRAW = new busUIAppWithdrawalApplicationDocuments();
  memProfile = new busUIMemberProfile();
  @ViewChild('nativeFileUpload')
  nativeFileUpload!: ElementRef;
  documentIndex = 0;
  id = '';
  isMandatory = false;
  isShowUpload = false;
  errorMessage = '';
  instructionMessage = '';
  title = '';
  fileTypes: any = [];
  fileSize = 0;
  memberProfiledata: any;
  @ViewChild('fileinput')
  fileInput!: ElementRef;
  sequencenumber = 0;
  CurrDate: any;
  constructor(
    public route: ActivatedRoute,
    public smallAccountService: SmallAccountsService,
    public cameraService: CameraService,
    public data: DataService,
    public appService: AppService,
    public applicationService: ApplicationApiService,
    public router: Router,
    public modal: ModalController,
    public alertController: AlertController
  ) {
    this.route.paramMap.subscribe((params) => {
      this.init();
    });
    this.memberProfiledata = this.smallAccountService.memProfile;
  }

  ngOnInit() {}
  init() {
    this.isMandatory = false;
    this.isShowUpload = false;
    this.errorMessage = '';
    this.instructionMessage = '';
    this.title = '';

    let id: any = this.route.snapshot.paramMap.get('id');
    this.id = id;

    let documentList =
      this.smallAccountService.lowBalanceWithdrawalApplication
        ?.ilstbusUIAppWithdrawalApplicationDocuments;
    if (documentList) {
      let index = documentList
        .map((e: any) => e.document_type_value)
        .indexOf(this.id);
      if (index > -1) {
        this.selectedDocument = documentList[index];
        this.selectedDocument.withdrawal_application_id =
          this.smallAccountService.lowBalanceWithdrawalApplication.withdrawal_application_id;
        this.selectedDocumentRAW.withdrawal_application_id =
          this.smallAccountService.lowBalanceWithdrawalApplication.withdrawal_application_id;
        this.selectedDocumentRAW.document_type_description =
          this.selectedDocument.document_type_description;
        this.selectedDocumentRAW.document_type_id =
          this.selectedDocument.document_type_id;
        this.selectedDocumentRAW.document_type_value =
          this.selectedDocument.document_type_value;
        this.selectedDocumentRAW.modified_date =
          this.selectedDocument.modified_date;
        this.checkWeatherCurrentDocumentTypeIsMandatoryOrNot();
      }
    }
    this.getLowBalanceWithdrawalFileTypes();
  }

  checkWeatherCurrentDocumentTypeIsMandatoryOrNot() {
    this.isMandatory = false;
    this.isShowUpload = false;
    this.instructionMessage = '';
    this.title = '';
    if (this.isShowUpload) {
      this.errorMessage =
        'Please take or upload a Picture of ' +
        this.selectedDocument.document_type_description +
        ' for the registration of mobile app.';
    } else {
      this.errorMessage =
        'Please take a Picture of ' +
        this.selectedDocument.document_type_description +
        ' for the registration of mobile app.';
    }
  }
  public getLowBalanceWithdrawalFileTypes() {
    this.applicationService
      .getEducationWithdrawalFileTypes()
      .subscribe((success: any) => {
        if (success) {
          this.fileTypes = [];
          this.fileTypes = success;
        } else {
          this.fileTypes = [];
          this.fileTypes.push('jpg');
          this.fileTypes.push('jpeg');
          this.fileTypes.push('pdf');
        }
        this.getLowBalanceFileSize();
      });
  }
  getLowBalanceFileSize() {
    this.applicationService
      .getEducationWithdrawalFileSize()
      .subscribe((success: any) => {
        if (success) {
          this.fileSize = success;
        } else {
          this.fileSize = 3;
        }
        this.loadLowBalanceWithdrawalDocuments();
      });
  }
  public loadLowBalanceWithdrawalDocuments() {
    if (this.smallAccountService.lowBalanceWithdrawalApplication) {
      this.applicationService
        .loadLowBalanceWithdrawalDocuments(
          this.smallAccountService.lowBalanceWithdrawalApplication
        )
        .subscribe((success: any) => {
          if (success?.ilstErrorMessages?.length > 0) {
            this.data.getErrorMessageByCode(
              'ICSWD',
              this.appService.appMessages
            );
          } else {
            this.smallAccountService.lowBalanceWithdrawalApplication = success;
            this.selectedDocument = JSON.parse(
              JSON.stringify(
                this.smallAccountService.lowBalanceWithdrawalApplication
                  .ilstbusUIAppWithdrawalApplicationDocuments[
                  this.documentIndex
                ]
              )
            );

            //Get Configured File Types
            if (success.ilstFileTypes) {
              this.fileTypes = [];
              this.fileTypes = success.ilstFileTypes;
            } else {
              this.fileTypes = [];
              this.fileTypes.push('jpg');
              this.fileTypes.push('jpeg');
              this.fileTypes.push('pdf');
            }

            //Get Configured File Size
            if (success.ilngFileSize) {
              this.fileSize = success.ilngFileSize;
            } else {
              this.fileSize = 3;
            }
          }
        });
    }
  }

  fileError(event: any) {
    this.data.constructErrorMessage(event);
  }

  clearFile() {
    this.selectedDocument.document_file = '';
    this.selectedDocument.type = '';
    this.selectedDocument.size = '';
    this.selectedDocument.file_name = '';
    this.selectedDocument.base_64 = '';
    this.selectedDocument.ImageFile = '';
    this.fileInput.nativeElement.value = '';
  }
  fileSelected(event: any) {
    this.selectedDocument.file_name = event.fileName;
    this.selectedDocument.size = event.fileSizeinBytes;
    this.selectedDocument.type = event.fileType;
    this.selectedDocument.ImageFile = event.imageFile;
  }

  async captureImage() {
    let image = await this.cameraService.captureImage();
    if (image !== '') {
      let document = {
        fileName:
          this.selectedDocument.document_type_description +
          '_' +
          this.appService.getDateTimeStamp() +
          '.jpeg',
        imageFile: image,
        fileType: 'jpeg',
        fileSizeinBytes: 0,
      };
      this.fileSelected(document);
    }
  }

  gotoNext() {
    if (this.selectedDocument.isMandatory === 'Y') {
      if (
        this.selectedDocument.ImageFile === '' ||
        !this.selectedDocument.ImageFile ||
        this.selectedDocument.file_name === '' ||
        !this.selectedDocument.file_name
      ) {
        if (this.selectedDocument.withdrawal_application_document_id <= 0) {
          this.data.constructErrorMessage(
            'Please take or upload a photo of the ' +
              this.selectedDocument.document_type_description
          );
          return;
        }
      }
    }
    this.selectedDocument.withdrawal_application_id =
      this.smallAccountService.lowBalanceWithdrawalApplication.withdrawal_application_id;
    this.applicationService
      .saveLowBalanceWithdrawalApplicationDocument(this.selectedDocument)
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.smallAccountService.lowBalanceWithdrawalApplication.ilstbusUIAppWithdrawalApplicationDocuments[
            this.documentIndex
          ] = success;

          if (
            this.smallAccountService.lowBalanceWithdrawalApplication
              .ilstbusUIAppWithdrawalApplicationDocuments.length -
              1 >
            this.documentIndex
          ) {
            this.documentIndex = this.documentIndex + 1;
            this.selectedDocument = JSON.parse(
              JSON.stringify(
                this.smallAccountService.lowBalanceWithdrawalApplication
                  .ilstbusUIAppWithdrawalApplicationDocuments[
                  this.documentIndex
                ]
              )
            );
          } else {
            this.router.navigateByUrl(
              '/home/make-withdrawl/full-withdrawl/small-accounts-step13'
            );
          }
        }
      });
  }

  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
  goHome() {
    this.router.navigateByUrl('/home/my-balance');
  }

  goNext() {
    this.router.navigateByUrl('/home/small-accounts-step13');
  }
}
