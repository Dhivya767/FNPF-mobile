import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { AppService } from 'src/app/app.service';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { SmallAccountsService } from '../small-accounts.service';
import { format } from 'date-fns';
@Component({
  selector: 'app-small-accounts-step7',
  templateUrl: './small-accounts-step7.page.html',
  styleUrls: ['./small-accounts-step7.page.scss'],
})
export class SmallAccountsStep7Page implements OnInit {
  errorTrue = false;
  showList = false;
  constructor(
    public appService: AppService,
    public smallAccountService: SmallAccountsService,
    public data: DataService,
    public alertController: AlertController,
    public applicationService: ApplicationApiService,
    public router: Router
  ) {}

  ngOnInit() {
    this.loadMemberEmployementNyPersonId();
  }
  loadMemberEmployementNyPersonId() {
    if (
      this.smallAccountService.lowBalanceWithdrawalApplication.person_id > 0
    ) {
      this.applicationService
        .loadMemberEmployementNyPersonId(
          this.smallAccountService.lowBalanceWithdrawalApplication.person_id
        )
        .subscribe((success: any) => {
          this.smallAccountService.memberDetail = success;
        });
    }
  }
  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
  goNext() {
    this.router.navigateByUrl(
      '/home/make-withdrawl/full-withdrawl/small-accounts-step8'
    );
  }
  restrictSpecialChars(event: any) {
    let newValue = event.target.value;
    let regExp = new RegExp('^[A-Za-z0-9? ]+$');
    if (!regExp.test(newValue)) {
      event.target.value = newValue.slice(0, -1);
    }
  }
  showShowList() {
    this.showList = true;
  }
  clickEmpname(data: any) {
    if (data) {
      this.showList = false;
      this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIWithdrawalApplicationEmployementHistory.employer_name =
        data.employer;
      if (data.start_date) {
        let startdate = format(new Date(data.start_date), 'dd/MM/yyyy');
        //13/04/2020
        var startdates = startdate.split('/');
        if (startdates && startdates.length > 2) {
          this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIWithdrawalApplicationEmployementHistory.employement_from_year =
            Number(startdates[2]);
        }
      } else {
        this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIWithdrawalApplicationEmployementHistory.employement_from_year = 0;
      }

      if (data.end_date) {
        let enddate = format(new Date(data.end_date), 'dd/MM/yyyy');
        //13/04/2020
        var enddates = enddate.split('/');
        if (enddates && enddates.length > 2) {
          this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIWithdrawalApplicationEmployementHistory.employement_to_year =
            Number(enddates[2]);
        }
      } else {
        this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIWithdrawalApplicationEmployementHistory.employement_to_year = 0;
      }
    }
  }
  createNewLowBalanceWithdrawalApplicationEmployementHistory() {
    this.applicationService
      .createNewLowBalanceWithdrawalApplicationEmployementHistory(
        this.smallAccountService.lowBalanceWithdrawalApplication
      )
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIWithdrawalApplicationEmployementHistory =
            success;
        }
      });
  }
  saveEmployementHistory() {
    if (
      !this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIWithdrawalApplicationEmployementHistory.employer_name ||
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIWithdrawalApplicationEmployementHistory.employer_name === '' ||
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIWithdrawalApplicationEmployementHistory.employer_name.length ===
        0
    ) {
      this.data.getErrorMessageByCode('20', this.appService.appMessages);
      return;
    }

    if (
      !this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIWithdrawalApplicationEmployementHistory.employement_from_year ||
      this.smallAccountService.lowBalanceWithdrawalApplication
        .ibusUIWithdrawalApplicationEmployementHistory.employement_from_year ==
        0
    ) {
      this.data.getErrorMessageByCode('21', this.appService.appMessages);
      return;
    }

    this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIWithdrawalApplicationEmployementHistory.is_last_employement =
      'N';
    this.applicationService
      .saveLowBalanceWithdrawalApplicationEmployementHistory(
        this.smallAccountService.lowBalanceWithdrawalApplication
      )
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.smallAccountService.lowBalanceWithdrawalApplication = success;
        }
      });
  }
  openLowBalanceWithdrawalApplicationEmployementHistory(val: any) {
    this.applicationService
      .openLowBalanceWithdrawalApplicationEmployementHistory(val)
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIWithdrawalApplicationEmployementHistory =
            success;
        }
      });
  }
  deleteLowBalanceWithdrawalApplicationLastEmployementHistory(val: any) {
    this.smallAccountService.lowBalanceWithdrawalApplication.ibusUIWithdrawalApplicationEmployementHistory =
      val;
    this.applicationService
      .deleteLowBalanceWithdrawalApplicationLastEmployementHistory(
        this.smallAccountService.lowBalanceWithdrawalApplication
      )
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.smallAccountService.lowBalanceWithdrawalApplication = success;
        }
      });
  }
  goHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
}
