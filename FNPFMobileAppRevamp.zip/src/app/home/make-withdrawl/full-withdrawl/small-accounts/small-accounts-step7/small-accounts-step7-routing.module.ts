import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SmallAccountsStep7Page } from './small-accounts-step7.page';

const routes: Routes = [
  {
    path: '',
    component: SmallAccountsStep7Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SmallAccountsStep7PageRoutingModule {}
