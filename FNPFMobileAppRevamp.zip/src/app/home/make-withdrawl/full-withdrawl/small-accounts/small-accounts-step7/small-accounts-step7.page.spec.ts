import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SmallAccountsStep7Page } from './small-accounts-step7.page';

describe('SmallAccountsStep7Page', () => {
  let component: SmallAccountsStep7Page;
  let fixture: ComponentFixture<SmallAccountsStep7Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(SmallAccountsStep7Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
