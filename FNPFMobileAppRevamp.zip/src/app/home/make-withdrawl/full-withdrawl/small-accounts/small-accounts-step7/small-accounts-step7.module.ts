import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SmallAccountsStep7PageRoutingModule } from './small-accounts-step7-routing.module';

import { SmallAccountsStep7Page } from './small-accounts-step7.page';

import { FormInputModule } from 'src/app/app-core/form-input/form-input.module';
import { MessagesModule } from 'src/app/app-core/template/messages/messages.module';

@NgModule({
  declarations: [SmallAccountsStep7Page],
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SmallAccountsStep7PageRoutingModule,
    MessagesModule,
    FormInputModule,
  ],
})
export class SmallAccountsStep7PageModule {}
