import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SmallAccountsStep15Page } from './small-accounts-step15.page';

const routes: Routes = [
  {
    path: '',
    component: SmallAccountsStep15Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SmallAccountsStep15PageRoutingModule {}
