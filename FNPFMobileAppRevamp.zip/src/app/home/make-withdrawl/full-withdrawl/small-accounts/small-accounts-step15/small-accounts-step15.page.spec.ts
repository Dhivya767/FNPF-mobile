import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SmallAccountsStep15Page } from './small-accounts-step15.page';

describe('SmallAccountsStep15Page', () => {
  let component: SmallAccountsStep15Page;
  let fixture: ComponentFixture<SmallAccountsStep15Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(SmallAccountsStep15Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
