import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from 'src/app/app.service';
import { busUIMemberProfile } from 'src/app/common/api-services/admin-api/admin-api.classes';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { MedicalWithdrawlService } from '../../../partial-withdrawl/medical-withdrawl/medical-withdrawl.service';
import { SmallAccountsService } from '../small-accounts.service';

@Component({
  selector: 'app-small-accounts-step15',
  templateUrl: './small-accounts-step15.page.html',
  styleUrls: ['./small-accounts-step15.page.scss'],
})
export class SmallAccountsStep15Page implements OnInit {
  errorTrue = false;
  toEmail = false;
  toMobile = false;
  memberProfile = new busUIMemberProfile();
  to = '';
  enteredOtp = '';
  constructor(
    public router: Router,
    public smallAccountService: SmallAccountsService,
    public appService: AppService,
    public applicationService: ApplicationApiService,
    public data: DataService
  ) {
    this.to = this.smallAccountService.emailTo;
    this.enteredOtp = '';
    this.memberProfile = this.smallAccountService.memProfile;
    this.toMobile = false;
    this.toEmail = false;

    if (this.to === 'Email') {
      this.toEmail = true;
    } else if (this.to === 'Mobile') {
      this.toMobile = true;
    }
  }

  ngOnInit() {}
  validateOTP() {
    if (!this.enteredOtp || this.enteredOtp.length === 0) {
      this.data.getErrorMessageByCode('PDECE', this.appService.appMessages);
      return;
    } else if (this.enteredOtp.length > 0) {
      if (
        this.enteredOtp ===
        this.smallAccountService.lowBalanceWithdrawalApplication.otp
      ) {
        setTimeout(() => {}, 200);
        this.submit();
      } else {
        this.data.getErrorMessageByCode('PDEVC', this.appService.appMessages);
        return;
      }
    }
  }
  submit() {
    this.applicationService
      .submitLowBalanceWithdrawalApplication(
        this.smallAccountService.lowBalanceWithdrawalApplication
      )
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.smallAccountService.lowBalanceWithdrawalApplication = success;
          this.router.navigateByUrl(
            '/home/make-withdrawl/full-withdrawl/small-accounts-step16'
          );
        }
      });
  }
  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
  resendOTP() {
    this.router.navigateByUrl(
      '/home/make-withdrawl/full-withdrawl/small-accounts-step14'
    );
  }
  goHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
}
