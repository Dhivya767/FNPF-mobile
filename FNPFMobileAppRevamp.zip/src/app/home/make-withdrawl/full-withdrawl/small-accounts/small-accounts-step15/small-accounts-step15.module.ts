import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SmallAccountsStep15PageRoutingModule } from './small-accounts-step15-routing.module';

import { SmallAccountsStep15Page } from './small-accounts-step15.page';
import { MessagesModule } from '../../../../../app-core/template/messages/messages.module';
import { FormInputModule } from 'src/app/app-core/form-input/form-input.module';

@NgModule({
  declarations: [SmallAccountsStep15Page],
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SmallAccountsStep15PageRoutingModule,
    MessagesModule,
    FormInputModule,
  ],
})
export class SmallAccountsStep15PageModule {}
