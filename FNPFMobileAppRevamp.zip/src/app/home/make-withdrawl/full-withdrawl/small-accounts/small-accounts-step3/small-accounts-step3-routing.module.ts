import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SmallAccountsStep3Page } from './small-accounts-step3.page';

const routes: Routes = [
  {
    path: '',
    component: SmallAccountsStep3Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SmallAccountsStep3PageRoutingModule {}
