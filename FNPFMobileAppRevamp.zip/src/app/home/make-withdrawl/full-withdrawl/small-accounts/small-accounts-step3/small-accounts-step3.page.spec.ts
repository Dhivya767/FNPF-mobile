import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SmallAccountsStep3Page } from './small-accounts-step3.page';

describe('SmallAccountsStep3Page', () => {
  let component: SmallAccountsStep3Page;
  let fixture: ComponentFixture<SmallAccountsStep3Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(SmallAccountsStep3Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
