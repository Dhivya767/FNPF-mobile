import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { AppService } from 'src/app/app.service';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { SmallAccountsService } from '../small-accounts.service';

@Component({
  selector: 'app-small-accounts-step3',
  templateUrl: './small-accounts-step3.page.html',
  styleUrls: ['./small-accounts-step3.page.scss'],
})
export class SmallAccountsStep3Page implements OnInit {
  errorTrue = false;
  constructor(
    public appService: AppService,
    public smallAccountService: SmallAccountsService,
    public data: DataService,
    public alertController: AlertController,
    public applicationApiService: ApplicationApiService,
    public router: Router
  ) {}

  ngOnInit() {}
  async goNext() {
    if (
      !this.smallAccountService.lowBalanceWithdrawalApplication
        .member_contact_no ||
      this.smallAccountService.lowBalanceWithdrawalApplication
        .member_contact_no === ''
    ) {
      this.data.getErrorMessageByCode('24', this.appService.appMessages);
      return;
    }
    let isEmail = await this.smallAccountService.validateEmail(
      this.smallAccountService.lowBalanceWithdrawalApplication.member_email_id
    );
    if (
      this.smallAccountService.lowBalanceWithdrawalApplication
        .member_email_id &&
      this.smallAccountService.lowBalanceWithdrawalApplication.member_email_id
        .length > 0
    ) {
      if (!isEmail) {
        this.data.constructErrorMessage(
          'The Email ID format is invalid. Please enter a valid Email ID.'
        );
        return;
      }
      this.applicationApiService
        .updateLowBalanceWithdrawalApplication(
          this.smallAccountService.lowBalanceWithdrawalApplication
        )
        .subscribe((success: any) => {
          if (success?.ilstErrorMessages?.length > 0) {
            this.checkForError(success);
          } else {
            this.smallAccountService.lowBalanceWithdrawalApplication = success;
            this.router.navigateByUrl(
              '/home/make-withdrawl/full-withdrawl/small-accounts-step4'
            );
          }
        });
    }
  }
  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
  restrictSpecialChars(event: any) {
    let newValue = event.target.value;
    let regExp = new RegExp('^[A-Za-z0-9? ]+$');
    if (!regExp.test(newValue)) {
      event.target.value = newValue.slice(0, -1);
    }
  }
  goHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
}
