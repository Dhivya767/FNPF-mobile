import { Injectable } from '@angular/core';
import { busUIMemberProfile } from 'src/app/common/api-services/admin-api/admin-api.classes';
import { busUILowBalanceWithdrawalApplication } from 'src/app/common/api-services/application-api/application-api.classes';

@Injectable({
  providedIn: 'root',
})
export class SmallAccountsService {
  DDL = {
    ddlGenderValue: [],
    ddlPreferredCommunication: [],
    ddlPaymentModeValue: [],
    ddlAddressTypeValue: [],
    ddlCountryValue: [],
    ddlZone: [],
    PostOffices: [],
    Banks: [],
    PreviouslyUsedBanks: [],
    ddltEligibilityStatement: [],
  };

  memProfile = new busUIMemberProfile();

  lowBalanceWithdrawalApplication = new busUILowBalanceWithdrawalApplication();

  memberDetail = {
    ilstbusUIEmploymentHistory: [],
  };
  emailTo = '';
  async validateEmail(email: string): Promise<boolean> {
    let re =
      /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
  }
  constructor() {}
}
