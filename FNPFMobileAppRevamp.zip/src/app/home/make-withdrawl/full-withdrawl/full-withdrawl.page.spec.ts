import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FullWithdrawlPage } from './full-withdrawl.page';

describe('FullWithdrawlPage', () => {
  let component: FullWithdrawlPage;
  let fixture: ComponentFixture<FullWithdrawlPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(FullWithdrawlPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
