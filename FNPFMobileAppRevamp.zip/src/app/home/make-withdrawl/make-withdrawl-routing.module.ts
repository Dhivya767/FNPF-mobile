import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MakeWithdrawlPage } from './make-withdrawl.page';

const routes: Routes = [
  {
    path: '',
    component: MakeWithdrawlPage
  },
  {
    path: 'full-withdrawl',
    loadChildren: () => import('./full-withdrawl/full-withdrawl.module').then( m => m.FullWithdrawlPageModule)
  },
  {
    path: 'partial-withdrawl',
    loadChildren: () => import('./partial-withdrawl/partial-withdrawl.module').then( m => m.PartialWithdrawlPageModule)
  },
  {
    path: 'government-assistance',
    loadChildren: () => import('./government-assistance/government-assistance.module').then( m => m.GovernmentAssistancePageModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MakeWithdrawlPageRoutingModule {}
