import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MakeContributionPage } from './make-contribution.page';

describe('MakeContributionPage', () => {
  let component: MakeContributionPage;
  let fixture: ComponentFixture<MakeContributionPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(MakeContributionPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
