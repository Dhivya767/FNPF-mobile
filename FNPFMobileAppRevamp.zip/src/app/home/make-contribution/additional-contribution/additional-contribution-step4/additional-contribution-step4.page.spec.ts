import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AdditionalContributionStep4Page } from './additional-contribution-step4.page';

describe('AdditionalContributionStep4Page', () => {
  let component: AdditionalContributionStep4Page;
  let fixture: ComponentFixture<AdditionalContributionStep4Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(AdditionalContributionStep4Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
