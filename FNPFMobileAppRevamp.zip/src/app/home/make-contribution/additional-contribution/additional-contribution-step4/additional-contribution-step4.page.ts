import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { MakeContributionService } from '../../make-contribution.service';

@Component({
  selector: 'app-additional-contribution-step4',
  templateUrl: './additional-contribution-step4.page.html',
  styleUrls: ['./additional-contribution-step4.page.scss'],
})
export class AdditionalContributionStep4Page implements OnInit {
  general_perc = 0;
  preserved_perc = 0;
  splitChange = false;
  paidTo = '';
  paidBy = '';
  depositAmount = 0;
  constructor(
    public router: Router,
    public makeContributionService: MakeContributionService,
    public data: DataService,
    public applicationService: ApplicationApiService
  ) {

    if (
      makeContributionService.additionalContribution.payment_for_value ==
      "SELF"
    ) {
      this.general_perc =
        this.makeContributionService.memProfile.ibusUIAccountDetail.ibusUIActiveMemberAccountSubAccountDetail.default_general_perc;
      this.preserved_perc =
        this.makeContributionService.memProfile.ibusUIAccountDetail.ibusUIActiveMemberAccountSubAccountDetail.default_preserved_perc;
      this.makeContributionService.additionalContribution.general_ac_split_percentage =
        this.general_perc;
      this.makeContributionService.additionalContribution.preserved_ac_split_percentage =
        this.preserved_perc;
    }
    if (
      makeContributionService.additionalContribution.payment_for_value ==
      "OTHER"
    ) {
      this.general_perc =
        this.makeContributionService.additionalContribution.general_ac_split_percentage;
      this.preserved_perc =
        this.makeContributionService.additionalContribution.preserved_ac_split_percentage;
    }
    if (
      this.general_perc !=
      this.makeContributionService.additionalContribution
        .general_ac_split_percentage ||
      this.preserved_perc !=
      this.makeContributionService.additionalContribution
        .preserved_ac_split_percentage
    ) {
      this.splitChange = true;
    }
  }

  ngOnInit() {
  }
  gotoNext() {
    debugger
    if (
      this.makeContributionService.additionalContribution.general_ac_split_percentage.toString() ===
      '' ||
      this.makeContributionService.additionalContribution
        .general_ac_split_percentage < 0
    ) {
      this.makeContributionService.additionalContribution.general_ac_split_percentage = 0;
    }
    if (
      this.makeContributionService.additionalContribution.preserved_ac_split_percentage.toString() ===
      '' ||
      this.makeContributionService.additionalContribution
        .preserved_ac_split_percentage < 0
    ) {
      this.makeContributionService.additionalContribution.preserved_ac_split_percentage = 0;
    }

    if (
      this.general_perc !==
      this.makeContributionService.additionalContribution
        .general_ac_split_percentage ||
      this.preserved_perc !==
      this.makeContributionService.additionalContribution
        .preserved_ac_split_percentage
    ) {
      this.splitChange = true;
    }
    this.applicationService
      .updateAdditionalContributionPayment(
        this.makeContributionService.additionalContribution
      )
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.makeContributionService.additionalContribution = success;
          // this.makeContributionService.setLocal();

          if (this.splitChange === true) {
            this.redirectToNextPage();
          }
          else {
            this.router.navigateByUrl(
              '/home/make-contribution/additional-contribution/additional-contribution-step6'
            );
          }
        }
      });
  }
  redirectToNextPage() {
    this.router.navigateByUrl(
      '/home/make-contribution/additional-contribution/additional-contribution-step8'
    );
  }
  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
  split() {
    this.router.navigateByUrl(
      '/home/make-contribution/additional-contribution/additional-contribution-step5'
    );
  }
  goToHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
}
