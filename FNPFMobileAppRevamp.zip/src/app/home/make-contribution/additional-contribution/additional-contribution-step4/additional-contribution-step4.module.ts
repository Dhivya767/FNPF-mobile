import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdditionalContributionStep4PageRoutingModule } from './additional-contribution-step4-routing.module';

import { AdditionalContributionStep4Page } from './additional-contribution-step4.page';
import { MessagesModule } from 'src/app/app-core/template/messages/messages.module';
import { FormInputModule } from 'src/app/app-core/form-input/form-input.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdditionalContributionStep4PageRoutingModule,
    MessagesModule,
    FormInputModule
  ],
  declarations: [AdditionalContributionStep4Page],
})
export class AdditionalContributionStep4PageModule { }
