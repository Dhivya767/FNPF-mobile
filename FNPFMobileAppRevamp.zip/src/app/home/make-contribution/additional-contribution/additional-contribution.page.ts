import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { AppService } from 'src/app/app.service';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { MakeContributionService } from '../make-contribution.service';
import { AdminApiService } from 'src/app/common/api-services/admin-api/admin-api.service';

@Component({
  selector: 'app-additional-contribution',
  templateUrl: './additional-contribution.page.html',
  styleUrls: ['./additional-contribution.page.scss'],
})
export class AdditionalContributionPage implements OnInit {
  constructor(
    public data: DataService,
    public alertController: AlertController,
    public router: Router,
    public apiService: AdminApiService,
    public appService: AppService,
    public makeContributionService: MakeContributionService
  ) { }

  ngOnInit() {
    this.getToken();
  }
  getToken() {
    this.apiService.getToken().subscribe((success: any) => {
      this.appService.memProfile.token = success;
    });
  }
  gotoForSelf() {
    let obj = {
      fnpfid: this.appService.memProfile.fnpf_no,
      paymentvalue: 'SELF',
    };
    this.apiService
      .createNewAdditionalContributionPayment(obj)
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.makeContributionService.additionalContribution = success;
          this.makeContributionService.DDL.ddlAmount =
            success.ilstbusUIpaymentamounts;
          this.makeContributionService.DDL.ddlSourceOfFund =
            success.ilstbusUISourceOfFund;
          this.makeContributionService.memProfile = this.appService.memProfile;
          this.redirectToNextPageForSelf();
        }
      });
  }
  gotoForOther() {
    let obj = {
      fnpfid: this.appService.memProfile.fnpf_no,
      paymentvalue: 'OTHER',
    };
    this.apiService
      .createNewAdditionalContributionPayment(obj)
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.makeContributionService.additionalContribution = success;
          this.makeContributionService.DDL.ddlExistingMember =
            success.ilstbusUIAlreadyExistingPayees;
          this.makeContributionService.DDL.ddlAmount =
            success.ilstbusUIpaymentamounts;
          this.makeContributionService.memProfile = this.appService.memProfile;
          this.makeContributionService.DDL.ddlSourceOfFund =
            success.ilstbusUISourceOfFund;
          this.redirectToNextPageForOthers();
        }
      });
  }
  redirectToNextPageForSelf() {
    this.router.navigateByUrl(
      '/home/make-contribution/additional-contribution/additional-contribution-step1'
    );
  }
  redirectToNextPageForOthers() {
    this.router.navigateByUrl(
      '/home/make-contribution/additional-contribution/additional-contribution-step2'
    );
  }
  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
}
