import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdditionalContributionStep5PageRoutingModule } from './additional-contribution-step5-routing.module';

import { AdditionalContributionStep5Page } from './additional-contribution-step5.page';
import { MessagesModule } from 'src/app/app-core/template/messages/messages.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdditionalContributionStep5PageRoutingModule,
    MessagesModule,
  ],
  declarations: [AdditionalContributionStep5Page],
})
export class AdditionalContributionStep5PageModule {}
