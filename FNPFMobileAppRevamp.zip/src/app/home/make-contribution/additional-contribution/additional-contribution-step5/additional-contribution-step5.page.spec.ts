import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AdditionalContributionStep5Page } from './additional-contribution-step5.page';

describe('AdditionalContributionStep5Page', () => {
  let component: AdditionalContributionStep5Page;
  let fixture: ComponentFixture<AdditionalContributionStep5Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(AdditionalContributionStep5Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
