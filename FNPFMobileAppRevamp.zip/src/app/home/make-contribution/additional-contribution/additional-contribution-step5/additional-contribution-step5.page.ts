import { Component, OnInit } from '@angular/core';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { MakeContributionService } from '../../make-contribution.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-additional-contribution-step5',
  templateUrl: './additional-contribution-step5.page.html',
  styleUrls: ['./additional-contribution-step5.page.scss'],
})
export class AdditionalContributionStep5Page implements OnInit {
  contributionHistory: any = [];
  constructor(
    public makeContributionService: MakeContributionService,
    public data: DataService,
    public applicationService: ApplicationApiService,
    public router: Router
  ) {
    if (
      this.makeContributionService &&
      this.makeContributionService.memProfile &&
      this.makeContributionService.memProfile.ibusUIAccountDetail &&
      this.makeContributionService.memProfile.ibusUIAccountDetail
        .ilstUISubAccounts
    ) {
      this.contributionHistory =
        this.makeContributionService.memProfile.ibusUIAccountDetail.ilstUISubAccounts;
    }
  }

  ngOnInit() {
    // this.makeContributionService.getLocal();
  }
  goToHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
}
