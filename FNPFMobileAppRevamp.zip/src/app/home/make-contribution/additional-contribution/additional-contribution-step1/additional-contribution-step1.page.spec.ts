import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AdditionalContributionStep1Page } from './additional-contribution-step1.page';

describe('AdditionalContributionStep1Page', () => {
  let component: AdditionalContributionStep1Page;
  let fixture: ComponentFixture<AdditionalContributionStep1Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(AdditionalContributionStep1Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
