import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { MakeContributionService } from '../../make-contribution.service';

@Component({
  selector: 'app-additional-contribution-step1',
  templateUrl: './additional-contribution-step1.page.html',
  styleUrls: ['./additional-contribution-step1.page.scss'],
})
export class AdditionalContributionStep1Page implements OnInit {
  errorTrue = false;
  yourSelectedModelValue = '';
  errorMessages = {
    contribution_amount: 'Please enter amount to proceed.',
    source_of_fund_value: 'Please select any source of fund to proceed.',
    other_source_of_fund: 'Please enter other source of fund to proceed.'
  };
  constructor(
    public router: Router,
    public makeContributionService: MakeContributionService,
    public data: DataService,
    public applicationService: ApplicationApiService
  ) { }

  ngOnInit() { }

  selectItem(item: any) {
    this.yourSelectedModelValue = item;
    this.makeContributionService.additionalContribution.contribution_amount =
      item;
  }
  goToHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
  navigateStep3(l: any) {
    debugger
    if (l.valid) {
      this.applicationService
        .saveAdditionalContributionPayment(
          this.makeContributionService.additionalContribution
        )
        .subscribe((success: any) => {
          if (success?.ilstErrorMessages?.length > 0) {
            this.checkForError(success);
          } else {
            this.makeContributionService.additionalContribution = success;
            this.redirectToNextPage();
          }
        });
    }
    else {
      this.errorTrue = true;
    }

  }
  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
  redirectToNextPage() {
    this.router.navigateByUrl(
      '/home/make-contribution/additional-contribution/additional-contribution-step3'
    );
  }
}
