import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AdditionalContributionPage } from './additional-contribution.page';

describe('AdditionalContributionPage', () => {
  let component: AdditionalContributionPage;
  let fixture: ComponentFixture<AdditionalContributionPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(AdditionalContributionPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
