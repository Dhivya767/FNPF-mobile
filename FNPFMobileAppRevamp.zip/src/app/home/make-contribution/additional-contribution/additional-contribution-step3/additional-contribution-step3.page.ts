import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { MakeContributionService } from '../../make-contribution.service';

@Component({
  selector: 'app-additional-contribution-step3',
  templateUrl: './additional-contribution-step3.page.html',
  styleUrls: ['./additional-contribution-step3.page.scss'],
})
export class AdditionalContributionStep3Page implements OnInit {
  depositAmount = 0;
  paidTo = '';
  paidBy = '';
  constructor(
    public router: Router,
    public makeContributionService: MakeContributionService,
    public data: DataService,
    public applicationService: ApplicationApiService
  ) {

  }

  ngOnInit() {
  }
  changeDetails() {
    this.router.navigateByUrl(
      '/home/make-contribution/additional-contribution'
    );
  }
  confirm() {
    this.router.navigateByUrl(
      '/home/make-contribution/additional-contribution/additional-contribution-step4'
    );
  }
  goToHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
}
