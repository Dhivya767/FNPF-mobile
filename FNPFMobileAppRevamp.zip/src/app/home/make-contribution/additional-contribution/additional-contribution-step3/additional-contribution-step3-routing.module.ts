import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdditionalContributionStep3Page } from './additional-contribution-step3.page';

const routes: Routes = [
  {
    path: '',
    component: AdditionalContributionStep3Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdditionalContributionStep3PageRoutingModule {}
