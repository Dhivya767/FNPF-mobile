import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdditionalContributionStep3PageRoutingModule } from './additional-contribution-step3-routing.module';

import { AdditionalContributionStep3Page } from './additional-contribution-step3.page';
import { MessagesModule } from 'src/app/app-core/template/messages/messages.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdditionalContributionStep3PageRoutingModule,
    MessagesModule,
  ],
  declarations: [AdditionalContributionStep3Page],
})
export class AdditionalContributionStep3PageModule {}
