import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AdditionalContributionStep3Page } from './additional-contribution-step3.page';

describe('AdditionalContributionStep3Page', () => {
  let component: AdditionalContributionStep3Page;
  let fixture: ComponentFixture<AdditionalContributionStep3Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(AdditionalContributionStep3Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
