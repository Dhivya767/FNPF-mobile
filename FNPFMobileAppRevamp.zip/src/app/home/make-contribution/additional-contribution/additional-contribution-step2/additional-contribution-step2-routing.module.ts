import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdditionalContributionStep2Page } from './additional-contribution-step2.page';

const routes: Routes = [
  {
    path: '',
    component: AdditionalContributionStep2Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdditionalContributionStep2PageRoutingModule {}
