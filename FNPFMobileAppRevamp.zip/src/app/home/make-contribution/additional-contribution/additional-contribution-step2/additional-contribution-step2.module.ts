import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdditionalContributionStep2PageRoutingModule } from './additional-contribution-step2-routing.module';

import { AdditionalContributionStep2Page } from './additional-contribution-step2.page';
import { MessagesModule } from 'src/app/app-core/template/messages/messages.module';
import { FormInputModule } from 'src/app/app-core/form-input/form-input.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdditionalContributionStep2PageRoutingModule,
    MessagesModule,
    FormInputModule,
  ],
  declarations: [AdditionalContributionStep2Page],
})
export class AdditionalContributionStep2PageModule {}
