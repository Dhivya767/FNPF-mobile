import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AdditionalContributionStep2Page } from './additional-contribution-step2.page';

describe('AdditionalContributionStep2Page', () => {
  let component: AdditionalContributionStep2Page;
  let fixture: ComponentFixture<AdditionalContributionStep2Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(AdditionalContributionStep2Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
