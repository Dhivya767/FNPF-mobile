import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MakeContributionService } from '../../make-contribution.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { format } from 'date-fns';
import { AppService } from 'src/app/app.service';

@Component({
  selector: 'app-additional-contribution-step2',
  templateUrl: './additional-contribution-step2.page.html',
  styleUrls: ['./additional-contribution-step2.page.scss'],
})
export class AdditionalContributionStep2Page implements OnInit {
  errorTrue = false;
  birthDate = '';
  endDate = '';
  memberNo = '';
  memberName = '';
  selectDate = false;
  errorMessages: any = {
    birthDate: 'Member date of birth mandatory.',
    other_person_fnpf_id: 'Member no is mandatory.',
  };
  constructor(
    public router: Router,
    public makeContributionService: MakeContributionService,
    public data: DataService,
    public applicationService: ApplicationApiService,
    public appService: AppService
  ) {
    this.birthDate =
      this.makeContributionService.additionalContribution.other_person_dob;
    this.endDate = new Date(
      new Date().setFullYear(new Date().getFullYear())
    ).toISOString();
    this.memberNo =
      this.makeContributionService.additionalContribution?.confirm_additional_contribution_member_no;
  }

  ngOnInit() { }
  async getSelectedData(val: any) {
    this.selectDate = true;
    await this.getFnpf(val);
    await this.getMemberInfo();
  }
  getFnpf(val: any) {
    if (
      this.makeContributionService.additionalContribution
        ?.ilstbusUIAlreadyExistingPayees?.length > 0
    ) {
      let existingMemberInfo =
        this.makeContributionService.additionalContribution.ilstbusUIAlreadyExistingPayees.filter(
          (x: any) => x.other_person_fnpf_id === val
        );

      if (existingMemberInfo && existingMemberInfo?.length > 0) {
        this.birthDate = existingMemberInfo[0]?.other_person_dob;
        let convertedDate = format(
          new Date(existingMemberInfo[0]?.other_person_dob),
          'dd/MM/yyyy'
        );
        this.makeContributionService.additionalContribution.other_person_dob =
          convertedDate;
        this.birthDate = convertedDate;
      }
      if (!this.selectDate) {
        this.makeContributionService.additionalContribution.other_person_dob =
          this.birthDate;
      }
      // if (this.selectDate) {
      //   let convertedDate = format(new Date(this.birthDate), 'dd/MM/yyyy');
      //   this.makeContributionService.additionalContribution.other_person_dob = convertedDate;
      // }
    }
  }
  async getMemberInfo() {
    console.log(this.birthDate);
    if (!this.selectDate) {
      let convertedDate = format(new Date(this.birthDate), 'dd/MM/yyyy');
      this.makeContributionService.additionalContribution.other_person_dob =
        convertedDate;
    } else if (this.selectDate) {
      this.makeContributionService.additionalContribution.other_person_dob =
        this.birthDate;
      this.selectDate = false;
    }
    if (
      !this.makeContributionService.additionalContribution
        .other_person_fnpf_id ||
      this.makeContributionService.additionalContribution
        .other_person_fnpf_id === ''
    ) {
      this.data.getErrorMessageByCode('403', this.appService.appMessages);
      return;
    } else {
      if (
        this.makeContributionService.additionalContribution
          .other_person_fnpf_id &&
        (this.birthDate === '' || !this.birthDate)
      ) {
        await this.getFnpf(
          this.makeContributionService.additionalContribution
            .other_person_fnpf_id
        );
      }
    }
    if (this.birthDate === '' || !this.birthDate) {
      this.data.getErrorMessageByCode('404', this.appService.appMessages);
      return;
    } else {
      await this.getMember();
    }
  }
  async getMember() {
    // if (
    //   this.makeContributionService.additionalContribution.other_person_fnpf_id || this.makeContributionService.additionalContribution.other_person_fnpf_id !== ''
    // ) {
    this.applicationService
      .getMemberProfileByFnpfNoandDOB(
        this.makeContributionService.additionalContribution
      )
      .subscribe(async (success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
          this.memberName = '';
          this.memberNo = '';
        } else {
          this.makeContributionService.othermemberinforAC = success;
          this.memberName = success.Full_Name;
          this.memberNo = success.FNPF_No;
        }
      });
    // }
    // else {
    //   this.errorTrue = true;
    // }
  }
  async getDob(val: any) {
    await this.getFnpf(val);
    await this.getMemberInfo();
  }
  async navigateStep3(l: any) {
    if (this.memberNo !== '' && this.memberNo) {
      // this.getMember();
      if (
        !this.makeContributionService.additionalContribution
          .other_person_fnpf_id ||
        this.birthDate === '' ||
        !this.birthDate
      ) {
        this.errorTrue = true;
      } else {
        this.router.navigateByUrl(
          '/home/make-contribution/additional-contribution/additional-contribution-step1'
        );
      }
    } else {
      this.data.getErrorMessageByCode("365", this.appService.appMessages);
    }
  }
  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
  goToHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
}
