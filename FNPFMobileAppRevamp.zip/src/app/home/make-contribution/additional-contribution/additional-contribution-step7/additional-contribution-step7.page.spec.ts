import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AdditionalContributionStep7Page } from './additional-contribution-step7.page';

describe('AdditionalContributionStep7Page', () => {
  let component: AdditionalContributionStep7Page;
  let fixture: ComponentFixture<AdditionalContributionStep7Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(AdditionalContributionStep7Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
