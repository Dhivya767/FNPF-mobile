import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { format } from 'date-fns';
import { BrowserService } from 'src/app/app-core/mobile-service/browser/browser.service';
import { busUIPaymentTransaction } from 'src/app/common/api-services/application-api/application-api.classes';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { MakeContributionService } from '../../make-contribution.service';

@Component({
  selector: 'app-additional-contribution-step7',
  templateUrl: './additional-contribution-step7.page.html',
  styleUrls: ['./additional-contribution-step7.page.scss'],
})
export class AdditionalContributionStep7Page implements OnInit {
  // transactionDatalist: any = {
  //   actionOverUrl: null,
  //   destinationurl: null,
  //   requestID: 0,
  //   token: null,
  //   aTransactionDate: "2023-03-29T18:33:19.35",
  //   strfnpf_no: null,
  //   strName: null,
  //   strTransactionCode: "101",
  //   strPaidBy: "MN12599311J",
  //   strPaidTo: "MN12599311J",
  //   aPaidToMemberName: null,
  //   aPaidToMemeberContactNo: null,
  //   aPaidByMemberName: null,
  //   aPaidByMemeberContactNo: null,
  //   blisNotificationSend: false,
  //   istrUserId: null,
  //   iinttransactionstatusid: 5022,
  //   istrtransactionstatusvalue: "PSOTD",
  //   isChecked: null,
  //   istrPaidByFnpfandName: null,
  //   istrPaidToFnpfandName: null,
  //   transaction_status_description: null,
  //   ilstUIMPaisaStatus: null,
  //   ilstUIPaymentTransactionPayee: null,
  //   ilstUIbusUIPaymentTransactionStatus: null,
  //   ilstRemittanceStatus: null,
  //   strtransactionstate: "Success",
  //   ibldisablebtn: false,
  //   totalCountOfPending: 0,
  //   strPayerMobileNumber: null,
  //   additional_contribution_payment_id: 0,
  //   response_code: null,
  //   card_type: null,
  //   payment_for_type_value: "ADDCO",
  //   payment_for_type_id: 6001,
  //   transaction_no: "2023037032",
  //   ibusUIAdditionalContributionPayment: {
  //     additional_contribution_payment_id: 6363,
  //     fnpf_id: "MN12599311J",
  //     payment_for_id: 6002,
  //     payment_for_value: "SELF",
  //     contribution_type_id: 6001,
  //     contribution_type_value: "ADDCO",
  //     other_person_fnpf_id: null,
  //     other_person_dob: null,
  //     contribution_amount: 10.00,
  //     general_ac_split_percentage: 100.00,
  //     general_ac_split_amount: 0.00,
  //     preserved_ac_split_percentage: 0.00,
  //     preserved_ac_split_amount: 0.00,
  //     payment_status_id: 6003,
  //     payment_status_value: "MAPCL",
  //     deposit_till_id: 0,
  //     promis_deposit_id: 3297867,
  //     member_account_transaction_id: 0,
  //     confirm_additional_contribution_member_no: null,
  //     confirm_additional_contribution_member_fullname: null,
  //     confirm_additional_contribution_member_name_dob: null,
  //     memberfnpfnoandfirstname: null,
  //     memberfirstname: null,
  //     ilstbuUIAdditionalContributionPaymentStatusHistory: null,
  //     ilstbusUIAdditionalContributionPaymentCommunicationHistory: null,
  //     ilstbusUIAlreadyExistingPayees: null,
  //     ilstbusUIpaymentamounts: null,
  //     rating: 0,
  //     is_accept_condition: null,
  //     split_changed_content: null,
  //     online_payment_content: null,
  //     promis_remittance_id: 3774499,
  //     paymentdate: "2023-03-29T18:32:51.867",
  //     view_receipt: null,
  //     source_of_fund_id: 19000,
  //     source_of_fund_value: "SALR",
  //     other_source_of_fund: null,
  //     ilstbusUISourceOfFund: null,
  //     iInfoMessage: "Data selected and opened successfully.",
  //     ilstErrorMessages: [],
  //     modified_by: "MN12599311J",
  //     modified_date: "2023-03-29T18:33:48.04"
  //   },
  //   payer_mobile_no: null,
  //   payment_id: null,
  //   transaction_id: null,
  //   transaction_time: null,
  //   transaction_initiation_time: null,
  //   card_number: null,
  //   remitter_name: null,
  //   transaction_status_id: 5022,
  //   transaction_status_value: "PSOTD",
  //   ibusUIVoluntaryContributionPayment: null,
  //   bsp_visa_debit_card_transaction_charge: 0.0,
  //   bsp_visa_credit_card_transaction_charge: 0.0,
  //   other_card_transaction_charge: 0.0,
  //   bsp_visa_debit_card_payable_amount: 0.0,
  //   bsp_visa_credit_card_payable_amount: 0.0,
  //   other_cards_payable_amount: 0.0,
  //   iInfoMessage: null,
  //   ilstErrorMessages: [],
  //   modified_by: "MN12599311J",
  //   modified_date: "2023-03-29T18:35:12.91"
  // }
  showSpinner = false;
  showErrorDiv = false;
  url = '';
  timeInterVal: any;
  transactionDate = '';
  paidTo = '';
  paidBy = '';
  amount = 0;
  paidToFirstName = '';
  memberAccoundId = 0;
  transactionData = new busUIPaymentTransaction();
  constructor(
    public router: Router,
    public applicationService: ApplicationApiService,
    public data: DataService,
    public makeContributionService: MakeContributionService,
    public browser: BrowserService
  ) { }

  ngOnInit() {
    this.getPaymentAppURL();
  }

  getPaymentAppURL() {
    this.showSpinner = true;
    this.applicationService.getPaymentAppURL().subscribe((success: any) => {
      if (success?.ilstErrorMessages?.length > 0) {
        this.checkForError(success);
      } else {
        this.url = success;
        this.constructUrl();
      }
    });
  }

  async constructUrl() {
    this.showSpinner = true;
    let params = {
      title: 'Online Additional Contribution Payment',
      fnpfno:
        this.makeContributionService.additionalContribution
          .confirm_additional_contribution_member_no,
      paymentDate: '',
      paymentAmount:
        this.makeContributionService.additionalContribution.contribution_amount,
      paymentCurrency: 'FJD',
      paidBy: this.makeContributionService.additionalContribution.fnpf_id,
      type: 'ADDCO',
      primaryId:
        this.makeContributionService.additionalContribution
          .additional_contribution_payment_id,
    };
    let response = encodeURIComponent(btoa(JSON.stringify(params)));
    let finalUrl = this.url + response;
    this.checkTransactionStatus();
    // let now = moment().format("YYYY-MM-DD HH:mm:ss");
    this.transactionDate = format(new Date(), 'yyyy-MM-dd HH:mm:ss');
    let browserResponse = await this.browser.open(finalUrl);
  }

  checkTransactionStatus() {
    this.timeInterVal = setInterval(() => {
      this.getTransactionStatus();
    }, 10000);
  }

  getTransactionStatus() {
    let option = {
      hideFullSpinner: true
    }
    let obj = {
      paidby: this.makeContributionService.additionalContribution.fnpf_id,
      paidto:
        this.makeContributionService.additionalContribution
          .confirm_additional_contribution_member_no,
      aTransactionDate: this.transactionDate,
      aAmount:
        this.makeContributionService.additionalContribution.contribution_amount,
      contributionid:
        this.makeContributionService.additionalContribution
          .additional_contribution_payment_id,
      PaymentForValue: 'ADDCO',
    };
    this.applicationService
      .getInProgresspaymentTransaction(obj, option)
      .subscribe((success: any) => {
        // if (this.timeInterVal) {
        //   clearInterval(this.timeInterVal);
        // }
        // this.transactionData = this.transactionDatalist;
        // console.log(this.transactionData, 'transactionData');
        // this.sendNotificationToUser();
        if (success) {
          if (success?.ilstErrorMessages?.length > 0) {
            if (this.timeInterVal) {
              clearInterval(this.timeInterVal);
            }
            this.showSpinner = false;
            this.showErrorDiv = true;
            this.checkForError(success);
          } else {
            if (success.payment_transaction_id > 0) {
              if (this.timeInterVal) {
                clearInterval(this.timeInterVal);
              }
              setTimeout(() => {
                this.transactionData.istrUserId =
                  this.makeContributionService.memProfile.fnpf_no;
                if (success && success.ibusUIAdditionalContributionPayment) {
                  this.makeContributionService.additionalContribution =
                    success.ibusUIAdditionalContributionPayment;
                  this.transactionData = success;
                }
                this.sendNotificationToUser();
              }, 200);
            }
          }
        } else {
          this.data.errorMethod('');
        }
      });
  }
  sendNotificationToUser() {
    let option = {
      hideSpinner: true,
    };
    this.applicationService
      .sendPaymentTransactionNotificationForPayer(
        this.makeContributionService.additionalContribution,
        option
      )
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.router.navigateByUrl(
            '/home/make-contribution/additional-contribution/additional-contribution-step10'
          );
        }
      });
  }

  checkForError(response: any) {
    this.showSpinner = false;
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
  goToHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
}
