import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdditionalContributionStep7PageRoutingModule } from './additional-contribution-step7-routing.module';

import { AdditionalContributionStep7Page } from './additional-contribution-step7.page';
import { MessagesModule } from '../../../../app-core/template/messages/messages.module';

@NgModule({
  declarations: [AdditionalContributionStep7Page],
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdditionalContributionStep7PageRoutingModule,
    MessagesModule,
  ],
})
export class AdditionalContributionStep7PageModule {}
