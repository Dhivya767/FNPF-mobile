import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdditionalContributionPage } from './additional-contribution.page';

const routes: Routes = [
  {
    path: '',
    component: AdditionalContributionPage,
  },
  {
    path: 'additional-contribution-step1',
    loadChildren: () =>
      import(
        './additional-contribution-step1/additional-contribution-step1.module'
      ).then((m) => m.AdditionalContributionStep1PageModule),
  },
  {
    path: 'additional-contribution-step2',
    loadChildren: () =>
      import(
        './additional-contribution-step2/additional-contribution-step2.module'
      ).then((m) => m.AdditionalContributionStep2PageModule),
  },
  {
    path: 'additional-contribution-step3',
    loadChildren: () =>
      import(
        './additional-contribution-step3/additional-contribution-step3.module'
      ).then((m) => m.AdditionalContributionStep3PageModule),
  },
  {
    path: 'additional-contribution-step4',
    loadChildren: () =>
      import(
        './additional-contribution-step4/additional-contribution-step4.module'
      ).then((m) => m.AdditionalContributionStep4PageModule),
  },
  {
    path: 'additional-contribution-step5',
    loadChildren: () =>
      import(
        './additional-contribution-step5/additional-contribution-step5.module'
      ).then((m) => m.AdditionalContributionStep5PageModule),
  },
  {
    path: 'additional-contribution-step6',
    loadChildren: () =>
      import(
        './additional-contribution-step6/additional-contribution-step6.module'
      ).then((m) => m.AdditionalContributionStep6PageModule),
  },
  {
    path: 'additional-contribution-step7',
    loadChildren: () =>
      import(
        './additional-contribution-step7/additional-contribution-step7.module'
      ).then((m) => m.AdditionalContributionStep7PageModule),
  },
  {
    path: 'additional-contribution-step8',
    loadChildren: () =>
      import(
        './additional-contribution-step8/additional-contribution-step8.module'
      ).then((m) => m.AdditionalContributionStep8PageModule),
  },
  {
    path: 'additional-contribution-step9',
    loadChildren: () =>
      import(
        './additional-contribution-step9/additional-contribution-step9.module'
      ).then((m) => m.AdditionalContributionStep9PageModule),
  },
  {
    path: 'additional-contribution-step10',
    loadChildren: () =>
      import(
        './additional-contribution-step10/additional-contribution-step10.module'
      ).then((m) => m.AdditionalContributionStep10PageModule),
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdditionalContributionPageRoutingModule {}
