import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdditionalContributionStep9Page } from './additional-contribution-step9.page';

const routes: Routes = [
  {
    path: '',
    component: AdditionalContributionStep9Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdditionalContributionStep9PageRoutingModule {}
