import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AdditionalContributionStep9Page } from './additional-contribution-step9.page';

describe('AdditionalContributionStep9Page', () => {
  let component: AdditionalContributionStep9Page;
  let fixture: ComponentFixture<AdditionalContributionStep9Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(AdditionalContributionStep9Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
