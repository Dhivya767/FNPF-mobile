import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MakeContributionService } from '../../make-contribution.service';

@Component({
  selector: 'app-additional-contribution-step9',
  templateUrl: './additional-contribution-step9.page.html',
  styleUrls: ['./additional-contribution-step9.page.scss'],
})
export class AdditionalContributionStep9Page implements OnInit {
  constructor(
    public router: Router,
    public makeContributionService: MakeContributionService
  ) {}

  ngOnInit() {}
  gotoNext() {
    this.router.navigateByUrl(
      '/home/make-contribution/additional-contribution/additional-contribution-step10'
    );
  }
  goToHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
}
