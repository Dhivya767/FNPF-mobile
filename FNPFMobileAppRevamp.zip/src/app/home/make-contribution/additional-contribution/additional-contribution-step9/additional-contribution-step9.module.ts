import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdditionalContributionStep9PageRoutingModule } from './additional-contribution-step9-routing.module';

import { AdditionalContributionStep9Page } from './additional-contribution-step9.page';
import { MessagesModule } from '../../../../app-core/template/messages/messages.module';

@NgModule({
  declarations: [AdditionalContributionStep9Page],
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdditionalContributionStep9PageRoutingModule,
    MessagesModule,
  ],
})
export class AdditionalContributionStep9PageModule {}
