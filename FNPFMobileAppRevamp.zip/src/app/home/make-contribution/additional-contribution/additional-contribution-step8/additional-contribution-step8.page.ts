import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MakeContributionService } from '../../make-contribution.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { AppService } from 'src/app/app.service';

@Component({
  selector: 'app-additional-contribution-step8',
  templateUrl: './additional-contribution-step8.page.html',
  styleUrls: ['./additional-contribution-step8.page.scss'],
})
export class AdditionalContributionStep8Page implements OnInit {
  errorTrue = false;
  isTermsAccepted = false;
  constructor(
    public router: Router,
    public makeContributionService: MakeContributionService,
    public data: DataService,
    public appService: AppService
  ) {}

  ngOnInit() {
    this.loadCheckbox();
  }
  gotoNext() {
    if (this.isTermsAccepted) {
      this.makeContributionService.additionalContribution.is_accept_condition =
        'Y';
      this.router.navigateByUrl(
        '/home/make-contribution/additional-contribution/additional-contribution-step6'
      );
    } else {
      this.makeContributionService.additionalContribution.is_accept_condition =
        'N';
      this.data.getErrorMessageByCode('408', this.appService.appMessages);
    }
  }
  onClickTerms(val: any) {
    if (val.detail.checked) {
      this.isTermsAccepted = true;
    } else {
      this.isTermsAccepted = false;
    }
  }
  loadCheckbox() {
    if (
      this.makeContributionService.additionalContribution
        .is_accept_condition === 'Y'
    ) {
      this.isTermsAccepted = true;
    }
  }
  goToHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
}
