import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AdditionalContributionStep8Page } from './additional-contribution-step8.page';

describe('AdditionalContributionStep8Page', () => {
  let component: AdditionalContributionStep8Page;
  let fixture: ComponentFixture<AdditionalContributionStep8Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(AdditionalContributionStep8Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
