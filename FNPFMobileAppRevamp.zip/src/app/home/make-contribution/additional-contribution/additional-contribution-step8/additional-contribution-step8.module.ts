import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdditionalContributionStep8PageRoutingModule } from './additional-contribution-step8-routing.module';

import { AdditionalContributionStep8Page } from './additional-contribution-step8.page';
import { MessagesModule } from 'src/app/app-core/template/messages/messages.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdditionalContributionStep8PageRoutingModule,
    MessagesModule,
  ],
  declarations: [AdditionalContributionStep8Page],
})
export class AdditionalContributionStep8PageModule {}
