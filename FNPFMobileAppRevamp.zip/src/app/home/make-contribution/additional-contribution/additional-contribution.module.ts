import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdditionalContributionPageRoutingModule } from './additional-contribution-routing.module';

import { AdditionalContributionPage } from './additional-contribution.page';
import { MessagesModule } from 'src/app/app-core/template/messages/messages.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdditionalContributionPageRoutingModule,
    MessagesModule
  ],
  declarations: [AdditionalContributionPage]
})
export class AdditionalContributionPageModule {}
