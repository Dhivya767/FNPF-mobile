import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdditionalContributionStep10PageRoutingModule } from './additional-contribution-step10-routing.module';

import { AdditionalContributionStep10Page } from './additional-contribution-step10.page';
import { RatingComponent } from '../../../../app-core/template/rating/rating.component';
import { MessagesModule } from '../../../../app-core/template/messages/messages.module';
import { PipesModule } from 'src/app/common/pipes/pipes.module';

@NgModule({
  declarations: [AdditionalContributionStep10Page],
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdditionalContributionStep10PageRoutingModule,
    RatingComponent,
    MessagesModule,
    PipesModule,
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class AdditionalContributionStep10PageModule {}
