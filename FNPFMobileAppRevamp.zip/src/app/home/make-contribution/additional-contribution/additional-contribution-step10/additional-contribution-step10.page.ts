import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MakeContributionService } from '../../make-contribution.service';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { NavController, AlertController } from '@ionic/angular';
import { FileSystemService } from 'src/app/app-core/mobile-service/file-system/file-system.service';
import { AppService } from 'src/app/app.service';
import { DataService } from 'src/app/common/services/data/data.service';

@Component({
  selector: 'app-additional-contribution-step10',
  templateUrl: './additional-contribution-step10.page.html',
  styleUrls: ['./additional-contribution-step10.page.scss'],
})
export class AdditionalContributionStep10Page implements OnInit {
  isReceiptViewOpen = false;
  showAdultMemberRegistration = false;
  view_receipt_base64 = '';

  constructor(
    public router: Router,
    public makeContributionService: MakeContributionService,
    public applicationService: ApplicationApiService,
    public data: DataService,
    public navCtrl: NavController,
    public alertCtrl: AlertController,
    public fileService: FileSystemService,
    public appService: AppService
  ) { }

  ngOnInit() { }

  goRating(star: any) {
    this.makeContributionService.additionalContribution.rating = star;
    this.applicationService
      .updateratingandacceptAdditionalContributionPayment(
        this.makeContributionService.additionalContribution
      )
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.makeContributionService.additionalContribution = success;
        }
      });
  }

  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }

  viewReceipt() {
    this.applicationService
      .viewreceiptAdditionalContributionPayment(
        this.makeContributionService.additionalContribution
      )
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.makeContributionService.additionalContribution = success;
          this.view_receipt_base64 =
            'data:application/pdf;base64,' + success.view_receipt;
          this.isReceiptViewOpen = true;
        }
      });
    // this.view_receipt_base64 =
    //   'data:application/pdf;base64,' + this.appService.receipt;
    // this.isReceiptViewOpen = true;
  }
  async downloadReceipt() {
    this.applicationService
      .downloadAdditionalContributionReceipt(
        this.makeContributionService.additionalContribution
          .additional_contribution_payment_id
      )
      .subscribe(async (success: any) => {
        if (success) {
          let name =
            this.makeContributionService.memProfile.fnpf_no +
            '_Form_' +
            this.appService.getDateTimeStamp() +
            '.pdf';
          let writeFile = await this.fileService.fetchAndWriteFile(
            this.appService.receipt,
            name
          );
        } else {
          this.data.constructErrorMessage(
            'Unable to download statement. Please try again later.'
          );
        }
      });
  }

  emailAdditionalContributionReceipt() {
    this.applicationService
      .emailAdditionalContributionReceipt(
        this.makeContributionService.additionalContribution
      )
      .subscribe(async (success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          const alert = await this.alertCtrl.create({
            message:
              'Your Registration Form has been emailed to your email address.',
            buttons: ['OK'],
          });
          await alert.present();
        }
      });
  }
  goToHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
}
