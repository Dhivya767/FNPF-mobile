import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AdditionalContributionStep10Page } from './additional-contribution-step10.page';

describe('AdditionalContributionStep10Page', () => {
  let component: AdditionalContributionStep10Page;
  let fixture: ComponentFixture<AdditionalContributionStep10Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(AdditionalContributionStep10Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
