import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { MakeContributionService } from '../../make-contribution.service';

@Component({
  selector: 'app-additional-contribution-step6',
  templateUrl: './additional-contribution-step6.page.html',
  styleUrls: ['./additional-contribution-step6.page.scss'],
})
export class AdditionalContributionStep6Page implements OnInit {
  constructor(
    public router: Router,
    public makeContributionService: MakeContributionService,
    public data: DataService,
    public applicationService: ApplicationApiService
  ) { }

  ngOnInit() { }
  gotoNext() {
    this.checkUserExistsOrNotInPromis();
    // this.router.navigateByUrl(
    //   '/home/make-contribution/additional-contribution/additional-contribution-step7'
    // );
  }
  checkUserExistsOrNotInPromis() {
    debugger
    this.applicationService
      .checkUserExistsOrNotInPromis(
        this.makeContributionService.additionalContribution
      )
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.makeContributionService.additionalContribution = success;
          if (
            this.makeContributionService.additionalContribution
              .promis_remittance_id > 0
          ) {
            this.redirectToNextPage();
          } else {
            this.router.navigateByUrl(
              '/home/make-contribution/additional-contribution/additional-contribution-step7'

            );
          }
        }
      });
  }
  redirectToNextPage() {
    this.router.navigateByUrl(
      '/home/make-contribution/additional-contribution/additional-contribution-step10'

    );
  }
  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
  goToHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
}
