import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdditionalContributionStep6PageRoutingModule } from './additional-contribution-step6-routing.module';

import { AdditionalContributionStep6Page } from './additional-contribution-step6.page';
import { MessagesModule } from 'src/app/app-core/template/messages/messages.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdditionalContributionStep6PageRoutingModule,
    MessagesModule,
  ],
  declarations: [AdditionalContributionStep6Page],
})
export class AdditionalContributionStep6PageModule {}
