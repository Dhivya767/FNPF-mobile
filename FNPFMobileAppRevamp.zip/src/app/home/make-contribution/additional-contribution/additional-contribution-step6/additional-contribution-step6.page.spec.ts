import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AdditionalContributionStep6Page } from './additional-contribution-step6.page';

describe('AdditionalContributionStep6Page', () => {
  let component: AdditionalContributionStep6Page;
  let fixture: ComponentFixture<AdditionalContributionStep6Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(AdditionalContributionStep6Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
