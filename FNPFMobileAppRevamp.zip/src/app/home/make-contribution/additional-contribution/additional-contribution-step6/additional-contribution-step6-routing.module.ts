import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdditionalContributionStep6Page } from './additional-contribution-step6.page';

const routes: Routes = [
  {
    path: '',
    component: AdditionalContributionStep6Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdditionalContributionStep6PageRoutingModule {}
