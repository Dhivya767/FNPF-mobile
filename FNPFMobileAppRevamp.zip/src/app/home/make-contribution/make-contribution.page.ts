import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { AppService } from 'src/app/app.service';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';

@Component({
  selector: 'app-make-contribution',
  templateUrl: './make-contribution.page.html',
  styleUrls: ['./make-contribution.page.scss'],
})
export class MakeContributionPage implements OnInit {
  errorTrue = false;
  appMessages: any;
  accountType: any = '';
  isVoluntaryAccount = false;
  constructor(
    public appService: AppService,
    public applicationApiService: ApplicationApiService,
    public data: DataService,
    public alertController: AlertController,
    public router: Router
  ) {
    //this.isVoluntaryAccount = this.checkMemberAccountIsVoluntaryOrNot();
  }

  ngOnInit() { }
  checkMemberAccountIsVoluntaryOrNot() {
    if (
      this.appService.memProfile &&
      this.appService.memProfile.ibusUIAccountDetail
    ) {
      this.accountType =
        this.appService.memProfile.ibusUIAccountDetail.account_type_value;
      console.log(this.accountType);
      if (this.accountType === 'VLTY') {
        this.isVoluntaryAccount = true;
      } else if (this.accountType === 'CMPL') {
        this.isVoluntaryAccount = false;
      }
    }
  }
  gotoAdditional() {
    if (
      this.appService.memProfile &&
      this.appService.memProfile.ibusUIAccountDetail &&
      (this.appService.memProfile.ibusUIAccountDetail.account_status_value ===
        'OPEN' ||
        this.appService.memProfile.ibusUIAccountDetail.account_status_value ===
        'PEND')
    ) {
      this.router.navigateByUrl(
        '/home/make-contribution/additional-contribution'
      );
    } else {
      this.data.constructErrorMessage(
        'Only an open or pending account holder can access this.'
      );
    }
  }
  backToMain() {
    this.router.navigateByUrl('/home/my-balance');
  }
  gotoVoluntary() {
    if (
      this.appService.memProfile &&
      this.appService.memProfile.ibusUIAccountDetail &&
      (this.appService.memProfile.ibusUIAccountDetail.account_status_value ===
        'OPEN' ||
        this.appService.memProfile.ibusUIAccountDetail.account_status_value ===
        'PEND')
    ) {
      this.router.navigateByUrl(
        '/home/make-contribution/voluntary-contribution'
      );
    } else {
      this.data.constructErrorMessage(
        'Only an open or pending account holder can access this.'
      );
    }
  }
  async logout() {
    const alert = await this.alertController.create({
      cssClass: 'my-custom-class',
      header: 'Confirm',
      message: 'Are you sure you want to logout?',
      buttons: [
        {
          text: 'No',
          role: 'No',
          cssClass: 'text-danger',
          handler: (blah) => { },
        },
        {
          text: 'Yes',
          handler: () => {
            this.confirmLogout();
          },
        },
      ],
    });
    await alert.present();
  }
  confirmLogout() {
    sessionStorage.clear();
    // this.storage.clear().then(() => {
    // this.data.isLoggedIn = false;
    this.data.token = '';
    window.location.assign('/landing');
    // });
    // this.dismiss();
  }
}
