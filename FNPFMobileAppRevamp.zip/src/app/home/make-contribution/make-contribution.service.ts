import { Injectable } from '@angular/core';
import {
  busUIAdditionalContributionPayment,
  busUIMemberProfile,
  busUIVoluntaryContributionPayment,
} from 'src/app/common/api-services/application-api/application-api.classes';

@Injectable({
  providedIn: 'root',
})
export class MakeContributionService {
  additionalContribution = new busUIAdditionalContributionPayment();
  voluntaryContribution = new busUIVoluntaryContributionPayment();
  memProfile = new busUIMemberProfile();
  DDL = {
    ddlAmount: [],
    ddlExistingMember: [],
    ddlSourceOfFund: [],
  };
  othermemberinforAC = {
    FNPF_No: '',
    TIN_No: '',
    DOB: '',
    First_Name: '',
    Full_Name: '',
    email_id: '',
    mobile_no: '',
    father_name: '',
    mother_name: '',
    Person_ID: '',
    age: '',
    member_account_balance: '',
  };
  constructor() { }
  setLocal() {
    localStorage.setItem('additionalContribution', JSON.stringify(this.additionalContribution));
  }
  getLocal() {
    let additionalContribution: any = localStorage.getItem('additionalContribution');
    this.additionalContribution = JSON.parse(additionalContribution);
  }

}
