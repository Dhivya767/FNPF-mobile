import { TestBed } from '@angular/core/testing';

import { MakeContributionService } from './make-contribution.service';

describe('MakeContributionService', () => {
  let service: MakeContributionService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MakeContributionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
