import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MakeContributionPage } from './make-contribution.page';

const routes: Routes = [
  {
    path: '',
    component: MakeContributionPage
  },
  {
    path: 'additional-contribution',
    loadChildren: () => import('./additional-contribution/additional-contribution.module').then( m => m.AdditionalContributionPageModule)
  },
  {
    path: 'voluntary-contribution',
    loadChildren: () => import('./voluntary-contribution/voluntary-contribution.module').then( m => m.VoluntaryContributionPageModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MakeContributionPageRoutingModule {}
