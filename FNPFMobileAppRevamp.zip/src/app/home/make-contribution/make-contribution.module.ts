import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MakeContributionPageRoutingModule } from './make-contribution-routing.module';

import { MakeContributionPage } from './make-contribution.page';
import { FormInputModule } from 'src/app/app-core/form-input/form-input.module';
import { MessagesModule } from 'src/app/app-core/template/messages/messages.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MakeContributionPageRoutingModule,
    FormInputModule,
    MessagesModule,
  ],
  declarations: [MakeContributionPage],
})
export class MakeContributionPageModule {}
