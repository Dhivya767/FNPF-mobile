import { ComponentFixture, TestBed } from '@angular/core/testing';
import { VoluntaryContributionPage } from './voluntary-contribution.page';

describe('VoluntaryContributionPage', () => {
  let component: VoluntaryContributionPage;
  let fixture: ComponentFixture<VoluntaryContributionPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(VoluntaryContributionPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
