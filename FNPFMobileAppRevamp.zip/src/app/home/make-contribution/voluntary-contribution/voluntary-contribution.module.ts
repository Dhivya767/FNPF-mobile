import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { VoluntaryContributionPageRoutingModule } from './voluntary-contribution-routing.module';

import { VoluntaryContributionPage } from './voluntary-contribution.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    VoluntaryContributionPageRoutingModule
  ],
  declarations: [VoluntaryContributionPage]
})
export class VoluntaryContributionPageModule {}
