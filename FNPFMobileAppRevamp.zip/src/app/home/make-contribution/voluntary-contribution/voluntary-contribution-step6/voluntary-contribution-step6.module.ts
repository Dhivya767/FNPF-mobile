import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { VoluntaryContributionStep6PageRoutingModule } from './voluntary-contribution-step6-routing.module';

import { VoluntaryContributionStep6Page } from './voluntary-contribution-step6.page';
import { MessagesModule } from '../../../../app-core/template/messages/messages.module';

@NgModule({
  declarations: [VoluntaryContributionStep6Page],
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    VoluntaryContributionStep6PageRoutingModule,
    MessagesModule,
  ],
})
export class VoluntaryContributionStep6PageModule {}
