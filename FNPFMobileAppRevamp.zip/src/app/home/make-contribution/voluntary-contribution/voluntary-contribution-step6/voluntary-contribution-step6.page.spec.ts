import { ComponentFixture, TestBed } from '@angular/core/testing';
import { VoluntaryContributionStep6Page } from './voluntary-contribution-step6.page';

describe('VoluntaryContributionStep6Page', () => {
  let component: VoluntaryContributionStep6Page;
  let fixture: ComponentFixture<VoluntaryContributionStep6Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(VoluntaryContributionStep6Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
