import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MakeContributionService } from '../../make-contribution.service';
import { DataService } from 'src/app/common/services/data/data.service';

@Component({
  selector: 'app-voluntary-contribution-step6',
  templateUrl: './voluntary-contribution-step6.page.html',
  styleUrls: ['./voluntary-contribution-step6.page.scss'],
})
export class VoluntaryContributionStep6Page implements OnInit {
  errorTrue = false;
  isTermsAccepted = false;
  constructor(
    public router: Router,
    public makeContributionService: MakeContributionService,
    public data: DataService
  ) { }

  ngOnInit() {
    this.loadCheckbox();
  }
  gotoNext() {
    if (this.isTermsAccepted) {
      this.makeContributionService.voluntaryContribution.is_accept_condition =
        'Y';
      this.router.navigateByUrl(
        '/home/make-contribution/voluntary-contribution/voluntary-contribution-step5'
      );
    } else {
      this.makeContributionService.voluntaryContribution.is_accept_condition =
        'N';
      this.data.constructErrorMessage('Please accept the declaration.')
    }
  }
  onClickTerms(val: any) {
    if (val.detail.checked) {
      this.isTermsAccepted = true;
    } else {
      this.isTermsAccepted = false;
    }
  }
  loadCheckbox() {
    if (
      this.makeContributionService.voluntaryContribution.is_accept_condition ==
      'Y'
    ) {
      this.isTermsAccepted = true;
    }
  }
  goToHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
}
