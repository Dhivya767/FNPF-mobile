import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { VoluntaryContributionStep5PageRoutingModule } from './voluntary-contribution-step5-routing.module';

import { VoluntaryContributionStep5Page } from './voluntary-contribution-step5.page';
import { MessagesModule } from '../../../../app-core/template/messages/messages.module';
import { RatingComponent } from 'src/app/app-core/template/rating/rating.component';

@NgModule({
  declarations: [VoluntaryContributionStep5Page],
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    VoluntaryContributionStep5PageRoutingModule,
    MessagesModule,
  ],
})
export class VoluntaryContributionStep5PageModule { }
