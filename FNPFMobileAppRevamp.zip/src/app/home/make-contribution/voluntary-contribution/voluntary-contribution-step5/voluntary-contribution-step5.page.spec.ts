import { ComponentFixture, TestBed } from '@angular/core/testing';
import { VoluntaryContributionStep5Page } from './voluntary-contribution-step5.page';

describe('VoluntaryContributionStep5Page', () => {
  let component: VoluntaryContributionStep5Page;
  let fixture: ComponentFixture<VoluntaryContributionStep5Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(VoluntaryContributionStep5Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
