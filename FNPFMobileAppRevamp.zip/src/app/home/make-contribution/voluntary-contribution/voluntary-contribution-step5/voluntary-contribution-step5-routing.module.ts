import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { VoluntaryContributionStep5Page } from './voluntary-contribution-step5.page';

const routes: Routes = [
  {
    path: '',
    component: VoluntaryContributionStep5Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class VoluntaryContributionStep5PageRoutingModule {}
