import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { format } from 'date-fns';
import { BrowserService } from 'src/app/app-core/mobile-service/browser/browser.service';
import { busUIPaymentTransaction } from 'src/app/common/api-services/admin-api/admin-api.classes';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { MakeContributionService } from '../../make-contribution.service';

@Component({
  selector: 'app-voluntary-contribution-step5',
  templateUrl: './voluntary-contribution-step5.page.html',
  styleUrls: ['./voluntary-contribution-step5.page.scss'],
})
export class VoluntaryContributionStep5Page implements OnInit {
  showSpinner = false;
  showErrorDiv = false;
  url = '';
  timeInterVal: any;
  transactionDate = '';
  paidToFirstName = '';
  memberAccoundId = 0;
  transactionData = new busUIPaymentTransaction();
  constructor(
    public router: Router,
    public applicationService: ApplicationApiService,
    public data: DataService,
    public makeContributionService: MakeContributionService,
    public browser: BrowserService
  ) { }

  ngOnInit() {
    this.getPaymentAppURL();
  }

  getPaymentAppURL() {
    this.showSpinner = true;
    this.applicationService.getPaymentAppURL().subscribe((success: any) => {
      if (success?.ilstErrorMessages?.length > 0) {
        this.checkForError(success);
      } else {
        this.url = success;
        this.constructUrl();
      }
    });
  }

  async constructUrl() {
    this.showSpinner = true;
    let params = {
      title: 'Online Voluntary Contribution Payment',
      fnpfno:
        this.makeContributionService.voluntaryContribution
          .confirm_voluntary_contribution_member_no,
      paymentDate: '',
      paymentAmount:
        this.makeContributionService.voluntaryContribution.contribution_amount,
      paymentCurrency: 'FJD',
      paidBy: this.makeContributionService.voluntaryContribution.fnpf_id,
      type: 'VOLCO',
      primaryId:
        this.makeContributionService.voluntaryContribution
          .voluntary_contribution_payment_id,
    };
    let response = encodeURIComponent(btoa(JSON.stringify(params)));
    let finalUrl = this.url + response;
    this.checkTransactionStatus();
    // let now = moment().format("YYYY-MM-DD HH:mm:ss");
    this.transactionDate = format(new Date(), 'yyyy-MM-dd HH:mm:ss');
    let browserResponse = await this.browser.open(finalUrl);
  }

  checkTransactionStatus() {
    this.timeInterVal = setInterval(() => {
      this.getTransactionStatus();
    }, 10000);
  }

  getTransactionStatus() {
    let option = {
      hideFullSpinner: true
    }
    let obj = {
      paidby: this.makeContributionService.voluntaryContribution.fnpf_id,
      paidto:
        this.makeContributionService.voluntaryContribution
          .confirm_voluntary_contribution_member_no,
      aTransactionDate: this.transactionDate,
      aAmount:
        this.makeContributionService.voluntaryContribution.contribution_amount,
      contributionid:
        this.makeContributionService.voluntaryContribution
          .voluntary_contribution_payment_id,
      PaymentForValue: 'VOLCO',
    };
    this.applicationService
      .getInProgresspaymentTransaction(obj, option)
      .subscribe((success: any) => {
        if (success) {
          if (success?.ilstErrorMessages?.length > 0) {
            if (this.timeInterVal) {
              clearInterval(this.timeInterVal);
            }
            this.showSpinner = false;
            this.showErrorDiv = true;
            this.checkForError(success);
          } else {
            if (success.payment_transaction_id > 0) {
              if (this.timeInterVal) {
                clearInterval(this.timeInterVal);
              }
              setTimeout(() => {
                this.transactionData.istrUserId =
                  this.makeContributionService.memProfile.fnpf_no;
                if (success && success.ibusUIVoluntaryContributionPayment) {
                  this.makeContributionService.voluntaryContribution =
                    success.ibusUIVoluntaryContributionPayment;
                  this.transactionData = success;
                }
                this.sendNotificationToUser();
              }, 200);
            }
          }
        } else {
          this.data.errorMethod('');
        }
      });
  }

  sendNotificationToUser() {
    let option = {
      hideSpinner: true,
    };
    this.applicationService
      .sendPaymentTransactionNotificationForPayer(
        this.makeContributionService.voluntaryContribution,
        option
      )
      .subscribe((success: any) => {
        this.showSpinner = false;
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.router.navigateByUrl(
            '/home/make-contribution/voluntary-contribution/voluntary-contribution-step7'
          );
        }
      });
  }

  checkForError(response: any) {
    this.showSpinner = false;
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
  goToHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
}
