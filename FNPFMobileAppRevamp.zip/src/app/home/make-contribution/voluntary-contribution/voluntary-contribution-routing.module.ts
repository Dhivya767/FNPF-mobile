import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { VoluntaryContributionPage } from './voluntary-contribution.page';

const routes: Routes = [
  {
    path: '',
    component: VoluntaryContributionPage,
  },
  {
    path: 'voluntary-contribution-step1',
    loadChildren: () =>
      import(
        './voluntary-contribution-step1/voluntary-contribution-step1.module'
      ).then((m) => m.VoluntaryContributionStep1PageModule),
  },
  {
    path: 'voluntary-contribution-step2',
    loadChildren: () =>
      import(
        './voluntary-contribution-step2/voluntary-contribution-step2.module'
      ).then((m) => m.VoluntaryContributionStep2PageModule),
  },
  {
    path: 'voluntary-contribution-step3',
    loadChildren: () =>
      import(
        './voluntary-contribution-step3/voluntary-contribution-step3.module'
      ).then((m) => m.VoluntaryContributionStep3PageModule),
  },
  {
    path: 'voluntary-contribution-step4',
    loadChildren: () =>
      import(
        './voluntary-contribution-step4/voluntary-contribution-step4.module'
      ).then((m) => m.VoluntaryContributionStep4PageModule),
  },
  {
    path: 'voluntary-contribution-step5',
    loadChildren: () =>
      import(
        './voluntary-contribution-step5/voluntary-contribution-step5.module'
      ).then((m) => m.VoluntaryContributionStep5PageModule),
  },
  {
    path: 'voluntary-contribution-step6',
    loadChildren: () =>
      import(
        './voluntary-contribution-step6/voluntary-contribution-step6.module'
      ).then((m) => m.VoluntaryContributionStep6PageModule),
  },
  {
    path: 'voluntary-contribution-step7',
    loadChildren: () =>
      import(
        './voluntary-contribution-step7/voluntary-contribution-step7.module'
      ).then((m) => m.VoluntaryContributionStep7PageModule),
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class VoluntaryContributionPageRoutingModule {}
