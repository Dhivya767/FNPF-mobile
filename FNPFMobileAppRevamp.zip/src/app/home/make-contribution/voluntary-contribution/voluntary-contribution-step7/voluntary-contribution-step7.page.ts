import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NavController, AlertController } from '@ionic/angular';
import { FileSystemService } from 'src/app/app-core/mobile-service/file-system/file-system.service';
import { AppService } from 'src/app/app.service';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { MakeContributionService } from '../../make-contribution.service';

@Component({
  selector: 'app-voluntary-contribution-step7',
  templateUrl: './voluntary-contribution-step7.page.html',
  styleUrls: ['./voluntary-contribution-step7.page.scss'],
})
export class VoluntaryContributionStep7Page implements OnInit {
  isReceiptViewOpen = false;
  showAdultMemberRegistration = false;
  view_receipt_base64 = '';
  showSpinner = false;
  constructor(
    public router: Router,
    public makeContributionService: MakeContributionService,
    public applicationService: ApplicationApiService,
    public data: DataService,
    public navCtrl: NavController,
    public alertCtrl: AlertController,
    public fileService: FileSystemService,
    public appService: AppService
  ) { }

  ngOnInit() { }

  goRating(star: any) {
    this.makeContributionService.voluntaryContribution.rating = star;
    this.applicationService
      .saveVoluntaryContributionDetailUserExperiance(
        this.makeContributionService.voluntaryContribution
      )
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.makeContributionService.voluntaryContribution = success;
        }
      });
  }

  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }

  viewReceipt() {
    this.applicationService
      .viewreceiptVoluntaryContributionPayment(
        this.makeContributionService.voluntaryContribution
      )
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.makeContributionService.voluntaryContribution = success;
          this.view_receipt_base64 =
            'data:application/pdf;base64,' + success.view_receipt;
          this.isReceiptViewOpen = true;
        }
      });
  }
  downloadReceipt() {
    this.applicationService
      .downloadVoluntaryContributionReceipt(
        this.makeContributionService.voluntaryContribution
          .voluntary_contribution_payment_id
      )
      .subscribe(async (success: any) => {
        if (success) {
          let name =
            this.makeContributionService.memProfile.fnpf_no +
            '_Form_' +
            this.appService.getDateTimeStamp() +
            '.pdf';
          let writeFile = await this.fileService.fetchAndWriteFile(
            success,
            name
          );
        } else {
          this.data.constructErrorMessage(
            'Unable to download statement. Please try again later.'
          );
        }
      });
  }

  // emailAdditionalContributionReceipt() {
  //   this.applicationService
  //     .emailAdditionalContributionReceipt(
  //       this.makeContributionService.voluntaryContribution
  //     )
  //     .subscribe(async (success: any) => {
  //       if (success?.ilstErrorMessages?.length > 0) {
  //         this.checkForError(success);
  //       } else {
  //         const alert = await this.alertCtrl.create({
  //           message:
  //             'Your Registration Form has been emailed to your email address.',
  //           buttons: ['OK'],
  //         });
  //         await alert.present();
  //       }
  //     });
  // }
  goToHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
}
