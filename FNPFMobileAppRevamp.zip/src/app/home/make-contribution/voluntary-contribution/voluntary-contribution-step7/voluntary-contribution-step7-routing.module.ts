import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { VoluntaryContributionStep7Page } from './voluntary-contribution-step7.page';

const routes: Routes = [
  {
    path: '',
    component: VoluntaryContributionStep7Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class VoluntaryContributionStep7PageRoutingModule {}
