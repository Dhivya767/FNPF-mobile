import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { VoluntaryContributionStep7PageRoutingModule } from './voluntary-contribution-step7-routing.module';

import { VoluntaryContributionStep7Page } from './voluntary-contribution-step7.page';
import { MessagesModule } from '../../../../app-core/template/messages/messages.module';
import { PipesModule } from 'src/app/common/pipes/pipes.module';
import { RatingComponent } from 'src/app/app-core/template/rating/rating.component';

@NgModule({
  declarations: [VoluntaryContributionStep7Page],
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    VoluntaryContributionStep7PageRoutingModule,
    MessagesModule,
    PipesModule,
    RatingComponent,

  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class VoluntaryContributionStep7PageModule { }
