import { ComponentFixture, TestBed } from '@angular/core/testing';
import { VoluntaryContributionStep7Page } from './voluntary-contribution-step7.page';

describe('VoluntaryContributionStep7Page', () => {
  let component: VoluntaryContributionStep7Page;
  let fixture: ComponentFixture<VoluntaryContributionStep7Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(VoluntaryContributionStep7Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
