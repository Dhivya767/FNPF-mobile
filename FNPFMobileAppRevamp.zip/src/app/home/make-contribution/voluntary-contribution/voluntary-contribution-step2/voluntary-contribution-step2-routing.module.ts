import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { VoluntaryContributionStep2Page } from './voluntary-contribution-step2.page';

const routes: Routes = [
  {
    path: '',
    component: VoluntaryContributionStep2Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class VoluntaryContributionStep2PageRoutingModule {}
