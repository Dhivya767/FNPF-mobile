import { ComponentFixture, TestBed } from '@angular/core/testing';
import { VoluntaryContributionStep2Page } from './voluntary-contribution-step2.page';

describe('VoluntaryContributionStep2Page', () => {
  let component: VoluntaryContributionStep2Page;
  let fixture: ComponentFixture<VoluntaryContributionStep2Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(VoluntaryContributionStep2Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
