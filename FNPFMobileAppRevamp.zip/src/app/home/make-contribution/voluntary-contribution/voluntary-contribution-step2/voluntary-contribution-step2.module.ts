import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { VoluntaryContributionStep2PageRoutingModule } from './voluntary-contribution-step2-routing.module';

import { VoluntaryContributionStep2Page } from './voluntary-contribution-step2.page';
import { FormInputModule } from '../../../../app-core/form-input/form-input.module';
import { MessagesModule } from '../../../../app-core/template/messages/messages.module';

@NgModule({
  declarations: [VoluntaryContributionStep2Page],
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    VoluntaryContributionStep2PageRoutingModule,
    FormInputModule,
    MessagesModule,
  ],
})
export class VoluntaryContributionStep2PageModule {}
