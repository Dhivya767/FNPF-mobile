import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { MakeContributionService } from '../../make-contribution.service';

@Component({
  selector: 'app-voluntary-contribution-step2',
  templateUrl: './voluntary-contribution-step2.page.html',
  styleUrls: ['./voluntary-contribution-step2.page.scss'],
})
export class VoluntaryContributionStep2Page implements OnInit {
  errorTrue = false;
  depositAmount = 10;
  errorMessages = {
    depositAmount: 'please enter amount.',
    source_of_fund_value: 'Please select any source of fund to proceed.',
    other_source_of_fund: 'Please enter other source of fund to proceed.'
  };
  constructor(
    public router: Router,
    public applicationService: ApplicationApiService,
    public makeContributionService: MakeContributionService,
    public data: DataService
  ) {

  }

  ngOnInit() { }

  proceedToPayment(l: any) {
    if (l.valid) {
      this.validateEnteredAmount();
    }
    else {
      this.errorTrue = true;
    }
    // if (
    //   this.makeContributionService.voluntaryContribution
    //     .source_of_fund_value === 'OTH' &&
    //   this.makeContributionService.voluntaryContribution
    //     .other_source_of_fund === ''
    // ) {
    //   this.data.constructErrorMessage(
    //     'Please enter other source of fund to proceed.'
    //   );
    //   return;
    // }
  }
  validateEnteredAmount() {
    this.makeContributionService.voluntaryContribution.contribution_amount =
      this.depositAmount;
    this.applicationService
      .validateEnteredAmountForVoluntaryMemberContributionPayment(
        this.makeContributionService.voluntaryContribution
      )
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.makeContributionService.voluntaryContribution = success;
          this.router.navigateByUrl(
            '/home/make-contribution/voluntary-contribution/voluntary-contribution-step3'
          );
        }
      });
  }
  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
  goToHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
}
