import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from 'src/app/app.service';
import { AdminApiService } from 'src/app/common/api-services/admin-api/admin-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { MakeContributionService } from '../make-contribution.service';

@Component({
  selector: 'app-voluntary-contribution',
  templateUrl: './voluntary-contribution.page.html',
  styleUrls: ['./voluntary-contribution.page.scss'],
})
export class VoluntaryContributionPage implements OnInit {
  isVoluntaryAccount = false;
  constructor(
    public appService: AppService,
    public router: Router,
    public data: DataService,
    public apiService: AdminApiService,
    public makeContributionService: MakeContributionService,

  ) {
    // this.checkMemberAccountIsVoluntaryOrNot();

  }

  ngOnInit() {
  }
  payOther() {
    this.router.navigateByUrl('/home/make-contribution/voluntary-contribution/voluntary-contribution-step1');
  }
  paymentHistory() {
    this.router.navigateByUrl('/home/payment-history')
  }
  paySelf() {
    if (this.appService.memProfile.person_id > 0) {
      this.createNewVoluntaryContributionPayment();
    }
    else {
      this.data.constructErrorMessage("Unable to validate Member Account. Please try after sometime.");
    }
  }
  // checkMemberAccountIsVoluntaryOrNot() {
  //   if (this.appService.memProfile.ibusUIAccountDetail.account_type_value === "VLTY") {
  //     this.isVoluntaryAccount = true;
  //   }
  //   else if (this.appService.memProfile.ibusUIAccountDetail.account_type_value === "CMPL") {
  //     this.isVoluntaryAccount = false;
  //   }
  // }
  createNewVoluntaryContributionPayment() {
    const fnPf = {
      fnpfid: this.appService.memProfile.fnpf_no,
      paymentvalue: "SELF",
      otherPersonFnpf: ''
    };
    this.apiService.createNewVoluntaryContributionPayment(fnPf)
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.makeContributionService.voluntaryContribution = success;
          this.makeContributionService.DDL.ddlSourceOfFund =
            success.ilstbusUISourceOfFund;
          this.router.navigateByUrl('/home/make-contribution/voluntary-contribution/voluntary-contribution-step2');
        }
      });
  }
  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
}
