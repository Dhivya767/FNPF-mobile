import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { VoluntaryContributionStep4PageRoutingModule } from './voluntary-contribution-step4-routing.module';

import { VoluntaryContributionStep4Page } from './voluntary-contribution-step4.page';
import { MessagesModule } from '../../../../app-core/template/messages/messages.module';

@NgModule({
  declarations: [VoluntaryContributionStep4Page],
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    VoluntaryContributionStep4PageRoutingModule,
    MessagesModule,
  ],
})
export class VoluntaryContributionStep4PageModule {}
