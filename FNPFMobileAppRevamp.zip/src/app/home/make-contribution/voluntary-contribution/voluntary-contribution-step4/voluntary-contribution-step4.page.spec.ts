import { ComponentFixture, TestBed } from '@angular/core/testing';
import { VoluntaryContributionStep4Page } from './voluntary-contribution-step4.page';

describe('VoluntaryContributionStep4Page', () => {
  let component: VoluntaryContributionStep4Page;
  let fixture: ComponentFixture<VoluntaryContributionStep4Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(VoluntaryContributionStep4Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
