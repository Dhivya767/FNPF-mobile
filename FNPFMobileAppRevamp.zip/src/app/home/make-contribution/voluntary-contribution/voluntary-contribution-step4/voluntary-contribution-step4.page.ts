import { Component, OnInit } from '@angular/core';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { MakeContributionService } from '../../make-contribution.service';
import { Router } from '@angular/router';
import { AppService } from 'src/app/app.service';

@Component({
  selector: 'app-voluntary-contribution-step4',
  templateUrl: './voluntary-contribution-step4.page.html',
  styleUrls: ['./voluntary-contribution-step4.page.scss'],
})
export class VoluntaryContributionStep4Page implements OnInit {
  contributionHistory: any = [];
  constructor(
    public router: Router,
    public makeContributionService: MakeContributionService,
    public data: DataService,
    public applicationService: ApplicationApiService,
    public appService: AppService
  ) {
    this.makeContributionService.memProfile = this.appService.memProfile;
    if (
      this.makeContributionService.memProfile?.ibusUIAccountDetail
        ?.ilstUISubAccounts.length > 0
    ) {
      this.contributionHistory =
        this.makeContributionService.memProfile.ibusUIAccountDetail.ilstUISubAccounts;
    }
  }

  ngOnInit() { }
  goToHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
}
