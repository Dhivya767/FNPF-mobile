import { ComponentFixture, TestBed } from '@angular/core/testing';
import { VoluntaryContributionStep3Page } from './voluntary-contribution-step3.page';

describe('VoluntaryContributionStep3Page', () => {
  let component: VoluntaryContributionStep3Page;
  let fixture: ComponentFixture<VoluntaryContributionStep3Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(VoluntaryContributionStep3Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
