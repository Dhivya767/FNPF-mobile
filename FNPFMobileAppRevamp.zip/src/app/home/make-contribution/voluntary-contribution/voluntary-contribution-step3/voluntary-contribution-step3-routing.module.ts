import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { VoluntaryContributionStep3Page } from './voluntary-contribution-step3.page';

const routes: Routes = [
  {
    path: '',
    component: VoluntaryContributionStep3Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class VoluntaryContributionStep3PageRoutingModule {}
