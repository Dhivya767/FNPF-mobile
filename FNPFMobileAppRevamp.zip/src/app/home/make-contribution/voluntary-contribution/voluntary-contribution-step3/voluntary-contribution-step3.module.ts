import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { VoluntaryContributionStep3PageRoutingModule } from './voluntary-contribution-step3-routing.module';

import { VoluntaryContributionStep3Page } from './voluntary-contribution-step3.page';
import { FormInputModule } from '../../../../app-core/form-input/form-input.module';
import { MessagesModule } from '../../../../app-core/template/messages/messages.module';

@NgModule({
  declarations: [VoluntaryContributionStep3Page],
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    VoluntaryContributionStep3PageRoutingModule,
    FormInputModule,
    MessagesModule,
  ],
})
export class VoluntaryContributionStep3PageModule {}
