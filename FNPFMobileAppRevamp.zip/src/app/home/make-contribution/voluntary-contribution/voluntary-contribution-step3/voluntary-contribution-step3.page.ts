import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { MakeContributionService } from '../../make-contribution.service';

@Component({
  selector: 'app-voluntary-contribution-step3',
  templateUrl: './voluntary-contribution-step3.page.html',
  styleUrls: ['./voluntary-contribution-step3.page.scss'],
})
export class VoluntaryContributionStep3Page implements OnInit {
  constructor(
    public router: Router,
    public applicationService: ApplicationApiService,
    public makeContributionService: MakeContributionService,
    public data: DataService
  ) { }

  ngOnInit() { }
  goToHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
  showContributionHistory() {
    this.router.navigateByUrl(
      '/home/make-contribution/voluntary-contribution/voluntary-contribution-step4'
    );
  }
  validateVoluntaryContributionSplit() {
    if (
      this.makeContributionService.voluntaryContribution.general_ac_split_percentage.toString() ===
      '' ||
      this.makeContributionService.voluntaryContribution
        .general_ac_split_percentage < 0
    ) {
      this.makeContributionService.voluntaryContribution.general_ac_split_percentage = 0;
    }
    if (
      this.makeContributionService.voluntaryContribution.preserved_ac_split_percentage.toString() ===
      '' ||
      this.makeContributionService.voluntaryContribution
        .preserved_ac_split_percentage < 0
    ) {
      this.makeContributionService.voluntaryContribution.preserved_ac_split_percentage = 0;
    }
    this.applicationService
      .validateVoluntaryContributionSplit(
        this.makeContributionService.voluntaryContribution
      )
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.makeContributionService.voluntaryContribution = success;
          if (
            this.makeContributionService.voluntaryContribution
              .is_split_changed === 'Y'
          ) {
            this.redirectToNextPage();
          } else {
            this.router.navigateByUrl(
              '/home/make-contribution/voluntary-contribution/voluntary-contribution-step5'
            );
          }
        }
      });
  }
  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
  redirectToNextPage() {
    this.router.navigateByUrl(
      '/home/make-contribution/voluntary-contribution/voluntary-contribution-step6'
    );
  }
}
