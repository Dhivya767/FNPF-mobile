import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { VoluntaryContributionStep1Page } from './voluntary-contribution-step1.page';

const routes: Routes = [
  {
    path: '',
    component: VoluntaryContributionStep1Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class VoluntaryContributionStep1PageRoutingModule {}
