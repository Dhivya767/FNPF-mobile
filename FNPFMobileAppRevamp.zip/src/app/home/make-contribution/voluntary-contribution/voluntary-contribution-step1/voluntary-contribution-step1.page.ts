import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApplicationApiService } from 'src/app/common/api-services/application-api/application-api.service';
import { MakeContributionService } from '../../make-contribution.service';
import { DataService } from 'src/app/common/services/data/data.service';
import { busUIMemberProfile } from 'src/app/common/api-services/admin-api/admin-api.classes';
import { AppService } from 'src/app/app.service';

@Component({
  selector: 'app-voluntary-contribution-step1',
  templateUrl: './voluntary-contribution-step1.page.html',
  styleUrls: ['./voluntary-contribution-step1.page.scss'],
})
export class VoluntaryContributionStep1Page implements OnInit {
  errorTrue = false;
  enteredfnpf_no = '';
  tempBtn = false;
  isInValidFnpfNo = true;
  isVoluntaryMember = false;
  selectedFnpfNo = '';
  selectedFirstName = '';
  enteredFirstName = '';
  selectedMemberAccountId = 0;
  paidBy: string = '';
  paidTo: string = '';
  fnpfData: any = {};
  payeeList: any = [];
  errorMessage: any = [];
  memberProfileData = new busUIMemberProfile();
  constructor(
    public router: Router,
    public applicationService: ApplicationApiService,
    public makeContributionService: MakeContributionService,
    public data: DataService,
    public appService: AppService
  ) {
    this.makeContributionService.memProfile = this.appService.memProfile;
    this.errorMessage = [];
    this.payeeList = [];
    this.fnpfData = {};
    this.loadPreviousPayees();
  }

  ngOnInit() { }
  loadPreviousPayees() {
    this.fnpfData.fnpfNo = this.makeContributionService.memProfile.fnpf_no;
    this.applicationService
      .getAllExistingpaymentTransactionPayee(this.fnpfData)
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.payeeList = [];
          this.errorMessage = success.ilstErrorMessages;
          this.checkForError(success);
        } else {
          this.payeeList = success;
        }
      });
  }
  gotoPaymentDetail() {
    if (this.errorMessage.length === 0) {
      this.createNewVoluntaryContributionPayment(this.enteredfnpf_no);
    }
  }
  createNewVoluntaryContributionPayment(otherPersonFnpfNo: any) {
    let obj = {
      fnpfid: this.makeContributionService.memProfile.fnpf_no,
      paymentvalue: 'OTHER',
      otherPersonFnpf: otherPersonFnpfNo,
    };
    this.applicationService
      .createNewVoluntaryContributionPayment(obj)
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          this.checkForError(success);
        } else {
          this.makeContributionService.voluntaryContribution = success;
          this.makeContributionService.DDL.ddlSourceOfFund =
            success.ilstbusUISourceOfFund;
          this.redirectToPaymentScreen();
        }
      });
  }
  checkForError(response: any) {
    this.data.constructErrorMessage(response.ilstErrorMessages);
  }
  redirectToPaymentScreen() {
    this.router.navigateByUrl(
      '/home/make-contribution/voluntary-contribution/voluntary-contribution-step2'
    );
  }
  goToHome() {
    this.router.navigateByUrl('/home/my-balance');
  }
  onChangeFnpfNo(fnpf_no: any) {
    if (fnpf_no != '') {
      this.checkWhetherTheFnpfNoIsValidOrNot(fnpf_no);
    } else {
      this.isInValidFnpfNo = false;
    }
    this.tempBtn = true;
  }
  checkWhetherTheFnpfNoIsValidOrNot(fnpf_no: any) {
    this.isInValidFnpfNo = false;
    this.fnpfData.fnpfNo = fnpf_no;
    this.applicationService
      .getMemberProfileByFnpfNo(this.fnpfData)
      .subscribe((success: any) => {
        if (success?.ilstErrorMessages?.length > 0) {
          // this.checkForErrorMessage(success);
          this.data.constructErrorMessage(
            'The entered FNPF ID is not valid. Please check again.'
          );
        } else {
          let accountType = success.ibusUIAccountDetail.account_type_value;
          if (accountType === 'VLTY') {
            this.isVoluntaryMember = true;
            this.enteredFirstName = success.first_name;
            this.selectedMemberAccountId =
              success.ibusUIAccountDetail.member_account_id;
            this.paidTo = this.enteredfnpf_no;
          } else {
            this.isVoluntaryMember = false;
            this.data.constructErrorMessage(
              'The Voluntary Member Account with open and pending status are allowed.'
            );
          }
        }
      });
  }
  checkForErrorMessage(response: any) {
    let message = response.ilstErrorMessages[0];
    this.isInValidFnpfNo = false;
    if (message === 'ERR_FNPFNO') {
      this.data.constructErrorMessage(
        'The entered FNPF ID is not valid. Please check again.'
      );
    } else {
      // this.data.constructErrorMessage(response.ilstErrorMessages);
      this.data.constructErrorMessage(
        'The entered FNPF ID is not valid. Please check again.'
      );
    }
  }
  onChangePayee(payee: any) {
    this.createNewVoluntaryContributionPayment(payee.strFnpfNo);
  }
  enableBtn() {
    this.tempBtn = false;
  }
}
