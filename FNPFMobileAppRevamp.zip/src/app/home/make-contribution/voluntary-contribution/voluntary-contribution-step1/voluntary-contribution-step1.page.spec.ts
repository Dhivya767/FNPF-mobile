import { ComponentFixture, TestBed } from '@angular/core/testing';
import { VoluntaryContributionStep1Page } from './voluntary-contribution-step1.page';

describe('VoluntaryContributionStep1Page', () => {
  let component: VoluntaryContributionStep1Page;
  let fixture: ComponentFixture<VoluntaryContributionStep1Page>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(VoluntaryContributionStep1Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
