import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { HomePage } from './home.page';

import { HomePageRoutingModule } from './home-routing.module';
import { MessagesModule } from '../app-core/template/messages/messages.module';
import { SlidesComponent } from '../app-core/template/slides/slides.component';
import { FormInputModule } from '../app-core/form-input/form-input.module';
import { StepperUiComponent } from '../app-core/template/stepper-ui/stepper-ui.component';
import { PipesModule } from '../common/pipes/pipes.module';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    HomePageRoutingModule,
    MessagesModule,
    SlidesComponent,
    FormInputModule,
    StepperUiComponent,
    PipesModule
  ],
  declarations: [HomePage]
})
export class HomePageModule { }
