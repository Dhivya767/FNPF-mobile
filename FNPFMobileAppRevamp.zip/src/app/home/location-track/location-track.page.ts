import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-location-track',
  templateUrl: './location-track.page.html',
  styleUrls: ['./location-track.page.scss'],
})
export class LocationTrackPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
