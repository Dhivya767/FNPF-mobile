import { ComponentFixture, TestBed } from '@angular/core/testing';
import { LocationTrackPage } from './location-track.page';

describe('LocationTrackPage', () => {
  let component: LocationTrackPage;
  let fixture: ComponentFixture<LocationTrackPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(LocationTrackPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
