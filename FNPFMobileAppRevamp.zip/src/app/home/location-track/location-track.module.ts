import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { LocationTrackPageRoutingModule } from './location-track-routing.module';

import { LocationTrackPage } from './location-track.page';
import { FormInputModule } from 'src/app/app-core/form-input/form-input.module';
import { MessagesModule } from 'src/app/app-core/template/messages/messages.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    LocationTrackPageRoutingModule,
    MessagesModule,
    FormInputModule,
  ],
  declarations: [LocationTrackPage],
})
export class LocationTrackPageModule {}
