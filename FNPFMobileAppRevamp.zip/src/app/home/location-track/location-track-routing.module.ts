import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LocationTrackPage } from './location-track.page';

const routes: Routes = [
  {
    path: '',
    component: LocationTrackPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class LocationTrackPageRoutingModule {}
