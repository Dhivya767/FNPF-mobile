import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomePage } from './home.page';

const routes: Routes = [
  {
    path: '',
    component: HomePage,
    children: [
      {
        path: 'my-profile',
        loadChildren: () =>
          import('./profile/my-profile/my-profile.module').then(
            (m) => m.MyProfilePageModule
          ),
      },
      {
        path: 'my-profile-update',
        loadChildren: () =>
          import('./profile/my-profile-update/my-profile-update.module').then(
            (m) => m.MyProfileUpdatePageModule
          ),
      },
      {
        path: 'my-account',
        loadChildren: () =>
          import('./my-account/my-account.module').then(
            (m) => m.MyAccountPageModule
          ),
      },
      {
        path: 'payment-history',
        loadChildren: () =>
          import('./payment/payment-history/payment-history.module').then(
            (m) => m.PaymentHistoryPageModule
          ),
      },
      {
        path: 'transaction',
        loadChildren: () =>
          import('./my-transactions/transaction/transaction.module').then(
            (m) => m.TransactionPageModule
          ),
      },
      {
        path: 'transaction-details',
        loadChildren: () =>
          import(
            './my-transactions/transaction-details/transaction-details.module'
          ).then((m) => m.TransactionDetailsPageModule),
      },
      {
        path: 'employment-history',
        loadChildren: () =>
          import('./employment-history/employment-history.module').then(
            (m) => m.EmploymentHistoryPageModule
          ),
      },
      {
        path: 'nominations',
        loadChildren: () =>
          import('./nominations/nominations.module').then(
            (m) => m.NominationsPageModule
          ),
      },
      {
        path: 'my-messages',
        loadChildren: () =>
          import('./my-messages/my-messages.module').then(
            (m) => m.MyMessagesPageModule
          ),
      },
      {
        path: 'statements',
        loadChildren: () =>
          import('./statements/statements.module').then(
            (m) => m.StatementsPageModule
          ),
      },
      {
        path: 'withdrawal-status',
        loadChildren: () =>
          import('./withdrawal-status/withdrawal-status.module').then(
            (m) => m.WithdrawalStatusPageModule
          ),
      },
      {
        path: 'withdrawal-status-detail',
        loadChildren: () =>
          import('./with-drawal-detail/with-drawal-detail.module').then(
            (m) => m.WithDrawalDetailPageModule
          ),
      },
      {
        path: 'my-pension',
        loadChildren: () =>
          import('./pensions/my-pension/my-pension.module').then(
            (m) => m.MyPensionPageModule
          ),
      },
      {
        path: 'pension-options',
        loadChildren: () =>
          import('./pensions/pension-options/pension-options.module').then(
            (m) => m.PensionOptionsPageModule
          ),
      },
      {
        path: 'pension-options-details',
        loadChildren: () =>
          import(
            './pensions/pension-options-details/pension-options-details.module'
          ).then((m) => m.PensionOptionsDetailsPageModule),
      },
      {
        path: 'renewal-certificate',
        loadChildren: () =>
          import(
            './renewal/renewal-certificate/renewal-certificate.module'
          ).then((m) => m.RenewalCertificatePageModule),
      },
      {
        path: 'renewal-certificate-details',
        loadChildren: () =>
          import(
            './renewal/renewal-certificate-details/renewal-certificate-details.module'
          ).then((m) => m.RenewalCertificateDetailsPageModule),
      },
      {
        path: 'my-balance',
        loadChildren: () =>
          import('./my-balance/my-balance.module').then(
            (m) => m.MyBalancePageModule
          ),
      },
      {
        path: 'make-contribution',
        loadChildren: () =>
          import('./make-contribution/make-contribution.module').then(
            (m) => m.MakeContributionPageModule
          ),
      },
      {
        path: 'location-track',
        loadChildren: () =>
          import('./location-track/location-track.module').then(
            (m) => m.LocationTrackPageModule
          ),
      },
      {
        path: 'change-password',
        loadChildren: () =>
          import(
            '../start/login/employee/change-password/change-password.module'
          ).then((m) => m.ChangePasswordPageModule),
      },
      {
        path: 'change-pin',
        loadChildren: () =>
          import('../start/login/employee/change-pin/change-pin.module').then(
            (m) => m.ChangePinPageModule
          ),
      },
      {
        path: 'reset-home-password',
        loadChildren: () =>
          import('./reset-home-password/reset-home-password.module').then(
            (m) => m.ResetHomePasswordPageModule
          ),
      },
      {
        path: 'reset-home-pin',
        loadChildren: () =>
          import('./reset-home-pin/reset-home-pin.module').then(
            (m) => m.ResetHomePinPageModule
          ),
      },
      {
        path: 'with-drawal-detail',
        loadChildren: () =>
          import('./with-drawal-detail/with-drawal-detail.module').then(
            (m) => m.WithDrawalDetailPageModule
          ),
      },
      {
        path: 'nomination-detail',
        loadChildren: () =>
          import('./nomination-detail/nomination-detail.module').then(
            (m) => m.NominationDetailPageModule
          ),
      },
      {
        path: 'my-message-details',
        loadChildren: () =>
          import('./my-message-details/my-message-details.module').then(
            (m) => m.MyMessageDetailsPageModule
          ),
      },
      {
        path: 'profile-edit',
        loadChildren: () =>
          import('./profile/profile-edit/profile-edit.module').then(
            (m) => m.ProfileEditPageModule
          ),
      },
      {
        path: 'unemployment-member-info',
        loadChildren: () =>
          import(
            './unemployment-member-info/unemployment-member-info.module'
          ).then((m) => m.UnemploymentMemberInfoPageModule),
      },
      {
        path: 'emploment-history-detail',
        loadChildren: () =>
          import(
            './emploment-history-detail/emploment-history-detail.module'
          ).then((m) => m.EmplomentHistoryDetailPageModule),
      },
      {
        path: 'payment-history-detail',
        loadChildren: () =>
          import(
            './payment/payment-history-detail/payment-history-detail.module'
          ).then((m) => m.PaymentHistoryDetailPageModule),
      },
      {
        path: 'make-withdrawl',
        loadChildren: () =>
          import('./make-withdrawl/make-withdrawl.module').then(
            (m) => m.MakeWithdrawlPageModule
          ),
      },
      {
        path: '',
        redirectTo: 'my-balance',
        pathMatch: 'full',
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class HomePageRoutingModule { }
