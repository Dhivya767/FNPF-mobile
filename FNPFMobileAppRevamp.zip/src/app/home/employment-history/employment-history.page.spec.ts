import { ComponentFixture, TestBed } from '@angular/core/testing';
import { EmploymentHistoryPage } from './employment-history.page';

describe('EmploymentHistoryPage', () => {
  let component: EmploymentHistoryPage;
  let fixture: ComponentFixture<EmploymentHistoryPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(EmploymentHistoryPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
