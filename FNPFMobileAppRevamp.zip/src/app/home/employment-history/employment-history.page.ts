import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from 'src/app/app.service';

@Component({
  selector: 'app-employment-history',
  templateUrl: './employment-history.page.html',
  styleUrls: ['./employment-history.page.scss'],
})
export class EmploymentHistoryPage implements OnInit {
  constructor(
    public appService: AppService,
    public router: Router
  ) {

  }
  ngOnInit() {
  }
  gotoDetails(detail: any) {
    this.appService.empHistory = detail;
    this.router.navigateByUrl('/home/emploment-history-detail');
  }

}
