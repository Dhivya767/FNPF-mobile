import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { EmploymentHistoryPageRoutingModule } from './employment-history-routing.module';

import { EmploymentHistoryPage } from './employment-history.page';
import { MessagesModule } from 'src/app/app-core/template/messages/messages.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    EmploymentHistoryPageRoutingModule,
    MessagesModule,
  ],
  declarations: [EmploymentHistoryPage],
})
export class EmploymentHistoryPageModule {}
