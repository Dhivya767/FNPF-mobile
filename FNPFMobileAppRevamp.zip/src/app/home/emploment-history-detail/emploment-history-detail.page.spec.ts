import { ComponentFixture, TestBed } from '@angular/core/testing';
import { EmplomentHistoryDetailPage } from './emploment-history-detail.page';

describe('EmplomentHistoryDetailPage', () => {
  let component: EmplomentHistoryDetailPage;
  let fixture: ComponentFixture<EmplomentHistoryDetailPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(EmplomentHistoryDetailPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
