import { Component, OnInit } from '@angular/core';
import { AppService } from 'src/app/app.service';

@Component({
  selector: 'app-emploment-history-detail',
  templateUrl: './emploment-history-detail.page.html',
  styleUrls: ['./emploment-history-detail.page.scss'],
})
export class EmplomentHistoryDetailPage implements OnInit {

  constructor(
    public appService:AppService
  ) { 
  
  }

  ngOnInit() {
  }

}
