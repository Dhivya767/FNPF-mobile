import { TestBed } from '@angular/core/testing';

import { NormalUnemploymentService } from './normal-unemployment.service';

describe('NormalUnemploymentService', () => {
  let service: NormalUnemploymentService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(NormalUnemploymentService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
