import { TestBed } from '@angular/core/testing';

import { FuneralWithdrawalService } from './funeral-withdrawal.service';

describe('FuneralWithdrawalService', () => {
  let service: FuneralWithdrawalService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FuneralWithdrawalService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
