import { Injectable } from '@angular/core';
import { NavigationStart, Router } from '@angular/router';
import { ToastController } from '@ionic/angular';

@Injectable({
  providedIn: 'root',
})
export class DataService {
  token = '';

  errorMessage: any = [];

  constructor(public router: Router, public toastController: ToastController) {
    this.router.events.subscribe((val) => {
      if (val instanceof NavigationStart) {
        this.errorMessage = [];
      }
    });
  }

  serviceStarted() {
    this.errorMessage = [];
  }
  serviceCompleted() { }

  errorMethod(err: any) {
    this.errorMessage = ['Error has been occured. Please try after sometime.'];
  }
  clearErrorMessage() {
    this.errorMessage = [];
  }

  constructErrorMessage(response: any) {
    if (response) {
      this.errorMessage = [response];
    } else {
      this.errorMethod('');
    }
  }
  async successMessage(msg: any) {
    const alert = await this.toastController.create({
      message: msg,
      duration: 3000,
      color: 'success',
      buttons: ['Ok'],
      position: 'bottom',
    });

    await alert.present();
  }

  getErrorMessageByCode(code: any, message: any) {
    let index = message.map((e: any) => e.config_constant).indexOf(code);
    if (index > -1) {
      this.constructErrorMessage(message[index].config_const_description);
      return;
    } else {
      return '';
    }
  }
}
