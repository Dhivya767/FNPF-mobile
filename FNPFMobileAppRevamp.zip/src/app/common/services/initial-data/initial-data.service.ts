import { Injectable } from '@angular/core';
import { DataService } from '../data/data.service';
// import { ApiAdminService } from '../../config/api.admin-service';
// import { ApiMemberService } from '../../config/api.member-service';
// import { ApiEmployerService } from '../../config/api.employer-service';
// import { ApiFundService } from '../../config/api.fund-service';
@Injectable({
  providedIn: 'root',
})
export class InitialDataService {
  memberOptions = {
    type: 'memberPath',
  };
  employerOptions = {
    type: 'employerPath',
  };
  fundOptions = {
    type: 'fundPath',
  };
  memberInitialData: any = {
    DDLUserStatus: [],
    DDLMemberType: [],
  };
  employerInitialData: any = {
    DDLCompanySector: [],
    DDLEmployerType: [],
    DDLEmployerSubType: [],
    DDLBranchValue: [],
    DDLZoneValue: [],
    DDLMonthValue: [],
    DDLEmployerStatus: [],
    DDLEmployerDocumentValue: [],
    DDLContactDocumentValue: [],
  };
  planOptionInitialData: any = {
    DDLPlanOptionEmployerType: [],
    DDLPlanSubType: [],
    DDLPlanOptionStatus: [],
    DDLPlanName: [],
    DDLNotesStatus: [],
  };
  planInitialData: any = {
    DDLPlanType: [],
    DDLPlanSubType: [],
    DDLPlanStatus: [],
    DDLAssignedOfficer: [],
    DDLNotesStatus: [],
  };
  staffRequestInitialData: any = {
    DDLUserRequestStatus: [],
    DDLUserRequestType: [],
    DDLUserRequestGroupChangeType: [],
    DDLBranch: [],
    DDLGender: [],
    DDLDepartment: [],
    DDLLocation: [],
    DDLTeam: [],
    DDLDesignation: [],
    DDLUserStatus: [],
    DDLUserGroup: [],
    DDLNotesStatus: [],
    DDLAssignedOfficer: [],
  };

  userInitialData: any = {
    DDLUserStatus: [],
    DDLUserDesignation: [],
    DDLLocation: [],
    DDLAdmBranch: [],
    DDLDepartment: [],
    DDLTeam: [],
    DDLUserBranchCode: [],
    DDLUserGroup: [],
    DDLGroupStatus: [],
    DDLUserGroupStatus: [],
    DDLUserTeamStatus: [],
    DDLGender: [],
  };

  groupInitialData: any = {
    configRoleStatus: [],
    configGroupStatus: [],
    configModuleName: [],
  };

  roleInitialData: any = {
    configRoleStatus: [],
    configScreenName: [],
    configPermissions: [],
    configModule: [],
  };

  resourceInitialData: any = {
    ConfigResourceType: [],
    ConfigViewName: [],
  };

  messageInitialData: any = {
    DDLMessageType: [],
  };

  emailInitialData: any = {
    configMailStatus: [],
  };

  memberRegInitialData: any = {
    DDLMemberType: [],
    DDLReceivedMode: [],
    DDLRecievedBranch: [],
    DDLReceivedBy: [],
    DDLGender: [],
    DDLGuardianRelationship: [],
    DDLMaritalStatus: [],
    DDLNationality: [],
    DDLIdentificationDocumentType: [],
    DDLLanguageSpokenAtHome: [],
    DDLCommunicationLanguage: [],
    DDLResidingAt: [],
    DDLAddressType: [],
    DDLHomeAddressType: [],
    DDLCountry: [],
    DDLProvince: [],
    DDLIsland: [],
    DDLLocation: [],
    DDLMunicipality: [],
    DDLEducationLevel: [],
    DDLDesignation: [],
    DDLPayFrequency: [],
    DDLOccupationType: [],
    DDLOccupationCategory: [],
    DDLEmploymentType: [],
    DDLEmploymentSubtype: [],
    DDLEmployerBranch: [],
    DDLPlanOption: [],
    DDLPlan: [],
    DDLBankAccountType: [],
    DDLNOBCategory: [],
    DDLNOBType: [],
    DDLAssignedOfficer: [],
    DDLNotesStatus: []
  };

  memberRegSearchInitialData: any = {
    DDLApplicationType: [],
    DDLMemberType: [],
    DDLMemberApplicationOfficers: [],
    DDLRecievedByBranch: [],
    DDLApplicationStatus: []
  };
  constructor(
    public data: DataService,
    // public apiAdminService: ApiAdminService,
    // public apiMemberService: ApiMemberService,
    // public apiEmployerService: ApiEmployerService,
    // public apiFundService: ApiFundService
  ) { }

  // admin module

  // getUserRequestInitialData(): Promise<boolean> {
  //   return new Promise((resolve) => {
  //     this.apiAdminService
  //       .getUserRequestInitialData()
  //       .subscribe((success: any) => {
  //         success.data.forEach((element: any) => {
  //           this.staffRequestInitialData[element.key] = element.value;
  //         });
  //         resolve(true);
  //       });
  //   });
  // }

  // getUserInitialData(): Promise<boolean> {
  //   return new Promise((resolve) => {
  //     this.apiAdminService.getUserInitialData().subscribe((success: any) => {
  //       success.data.forEach((element: any) => {
  //         this.userInitialData[element.key] = element.value;
  //       });
  //       resolve(true);
  //     });
  //   });
  // }

  // getGroupDetailsInitialData(): Promise<boolean> {
  //   return new Promise((resolve) => {
  //     this.apiAdminService
  //       .getGroupDetailsInitialData()
  //       .subscribe((success: any) => {
  //         success.data.forEach((element: any) => {
  //           this.groupInitialData[element.key] = element.value;
  //         });
  //         resolve(true);
  //       });
  //   });
  // }

  // getRoleDetailsInitialData(): Promise<boolean> {
  //   return new Promise((resolve) => {
  //     this.apiAdminService
  //       .getRoleDetailsInitialData()
  //       .subscribe((success: any) => {
  //         success.data.forEach((element: any) => {
  //           this.roleInitialData[element.key] = element.value;
  //         });
  //         resolve(true);
  //       });
  //   });
  // }

  // geResourceDetailsInitialData(): Promise<boolean> {
  //   return new Promise((resolve) => {
  //     this.apiAdminService
  //       .geResourceDetailsInitialData()
  //       .subscribe((success: any) => {
  //         success.data.forEach((element: any) => {
  //           this.resourceInitialData[element.key] = element.value;
  //         });
  //         resolve(true);
  //       });
  //   });
  // }

  // getMessageInitialData(): Promise<boolean> {
  //   return new Promise((resolve) => {
  //     this.apiAdminService.getMessageInitialData().subscribe((success: any) => {
  //       success.data.forEach((element: any) => {
  //         this.messageInitialData[element.key] = element.value;
  //       });
  //       resolve(true);
  //     });
  //   });
  // }

  // getCommunicationTrackingInitialData(): Promise<boolean> {
  //   return new Promise((resolve) => {
  //     this.apiAdminService
  //       .getCommunicationTrackingInitialData()
  //       .subscribe((success: any) => {
  //         success.data.forEach((element: any) => {
  //           this.emailInitialData[element.key] = element.value;
  //         });
  //         resolve(true);
  //       });
  //   });
  // }

  // // application module

  // getMemberApplicationInitialData(): Promise<boolean> {
  //   return new Promise((resolve) => {
  //     this.apiMemberService
  //       .getMemberApplicationInitialData(this.memberOptions)
  //       .subscribe((success: any) => {
  //         success.data.forEach((element: any) => {
  //           this.memberRegInitialData[element.key] = element.value;
  //         });
  //         resolve(true);
  //       });
  //   });
  // }
  // getMemberApplicationSearchInitialData(): Promise<boolean> {
  //   return new Promise((resolve) => {
  //     this.apiMemberService
  //       .getMemberApplicationSearchInitialData(this.memberOptions)
  //       .subscribe((success: any) => {
  //         success.data.forEach((element: any) => {
  //           this.memberRegSearchInitialData[element.key] = element.value;
  //         });
  //         resolve(true);
  //       });
  //   });
  // }
  // getMemberdetailInitialData(): Promise<boolean> {
  //   return new Promise((resolve) => {
  //     this.apiMemberService
  //       .getMemberdetailInitialData(this.memberOptions)
  //       .subscribe((success: any) => {
  //         success.data.forEach((element: any) => {
  //           this.memberInitialData[element.key] = element.value;
  //         });
  //         resolve(true);
  //       });
  //   });
  // }
  // getEmployerSearchInitialData(): Promise<boolean> {
  //   return new Promise((resolve) => {
  //     this.apiEmployerService
  //       .getEmployerSearchInitialData(this.employerOptions)
  //       .subscribe((success: any) => {
  //         success.data.forEach((element: any) => {
  //           this.employerInitialData[element.key] = element.value;
  //         });
  //         resolve(true);
  //       });
  //   });
  // }
  // getPlanOptionInitialData(): Promise<boolean> {
  //   return new Promise((resolve) => {
  //     this.apiFundService
  //       .getPlanOptionInitialData(this.fundOptions)
  //       .subscribe((success: any) => {
  //         success.data.forEach((element: any) => {
  //           this.planOptionInitialData[element.key] = element.value;
  //         });
  //         resolve(true);
  //       });
  //   });
  // }
  // getPlanInitialData(): Promise<boolean> {
  //   return new Promise((resolve) => {
  //     this.apiFundService
  //       .getPlanInitialData(this.fundOptions)
  //       .subscribe((success: any) => {
  //         success.data.forEach((element: any) => {
  //           this.planInitialData[element.key] = element.value;
  //         });
  //         resolve(true);
  //       });
  //   });
  // }
  // getlistofalluser(): Promise<boolean> {
  //   return new Promise((resolve) => {
  //     this.apiFundService
  //       .getListofAllUser({}, this.fundOptions)
  //       .subscribe((success: any) => {
  //         this.planInitialData.DDLAssignedOfficer = success.value;
  //         // success.data.forEach((element: any) => {
  //         //   this.planInitialData.DDLAssignedOfficer[element.key] = element.value;
  //         // });
  //         resolve(true);
  //       });
  //   });
  // }
  // // getListofBankBasedonBranch(): Promise<boolean> {
  // //   return new Promise((resolve) => {
  // //     this.apiAdminService.get(this.options).subscribe((success: any) => {
  // //       this.branchBankInitialData.DDLBankBranch = success.lstentActCompanyBranchBankDetail;
  // //       resolve(true);
  // //     });
  // //   });
  // // }
}
