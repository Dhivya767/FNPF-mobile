import { Injectable } from '@angular/core';
import * as CryptoJS from 'crypto-js';
@Injectable({
  providedIn: 'root',
})
export class AesService {
  constructor() { }

  async encrypt(text: any, val: any) {
    return new Promise((resolve, reject) => {
      let Key = CryptoJS.enc.Utf8.parse(val[0]);
      let IV = CryptoJS.enc.Utf8.parse(val[1]);
      let encryptedText = CryptoJS.AES.encrypt(text, Key, {
        iv: IV,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      });
      resolve(encryptedText.toString());
    });
  }
}
