import { TestBed } from '@angular/core/testing';

import { MicroFinanceService } from './micro-finance.service';

describe('MicroFinanceService', () => {
  let service: MicroFinanceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MicroFinanceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
