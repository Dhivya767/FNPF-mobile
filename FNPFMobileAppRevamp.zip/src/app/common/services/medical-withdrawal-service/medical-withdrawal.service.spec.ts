import { TestBed } from '@angular/core/testing';

import { MedicalWithdrawalService } from './medical-withdrawal.service';

describe('MedicalWithdrawalService', () => {
  let service: MedicalWithdrawalService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MedicalWithdrawalService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
