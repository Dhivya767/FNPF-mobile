export class busUIAppWithdrawalApplication {
  withdrawal_application_id = 0;
  person_id = 0;
  tin = '';
  dob = '';
  first_name = '';
  middle_name = '';
  last_name = '';
  type_id = 0;
  type_value = '';
  sub_type_id = 0;
  sub_type_value = '';
  received_date = '';
  withdrawal_status_id = 0;
  withdrawal_status_value = '';
  withdrawal_action_status_id = 0;
  withdrawal_action_status_value = '';
  withdrawal_mob_status_id = 0;
  withdrawal_mob_status_value = '';
  location_id = 0;
  location_value = '';
  fee_type_id = 0;
  fee_type_value = '';
  fnpf_id = '';
  signature_verified_flag = '';
  photo_verified_flag = '';
  primary_applicant_flag = '';
  appeal_flag = '';
  discretioinary_process_flag = '';
  waive_off_flag = '';
  request_amt = 0;
  age = 0;
  ibltutionFee = false;
  ibltextbook = false;
  iblAccomodation = false;
  iblIncidentalExpenses = false;
  istrInvoiceAmount = '';
  istrInvoiceNo = '';
  idecEducationEligibility = 0;
  rating = 0;
  otp = '';
  otp_generated_time = '';
  nearest_town_id = 0;
  nearest_town_value = '';
  nearest_town = '';
  withdrawal_status_description = '';
  sub_type_description = '';
  type_description = '';
  promis_application_id = 0;
  email_id = '';
  contact_no = '';
  member_email_id = '';
  member_contact_no = '';
  is_email_sent_eg = '';
  is_email_sent_mb = '';
  istrIsDocumentUploaded = '';
  iintContentServerId = 0;
  istrLockdownwithdrawal = '';
  ibusUIAppStudentDetails = new busUIAppStudentDetails();
  ilstbusUIAppStudentDetails: any = [];
  ilstbusUIPreviouslyUsedStudentDetails: any = [];
  ilstbusUIAppWithdrawalApplicationDocuments: any = [];
  ilstUIAssistanceType: any = [];
  ilstUITerms: any = [];
  ilstUINearestTowns: any = [];
  ibusUIAppEducationWithdrawalConfig = new busUIAppEducationWithdrawalConfig();
  ibusUIAppWithdrawalApplicationMemberPhoto =
    new busUIAppWithdrawalApplicationDocuments();
  ibusUIAppWithdrawalApplicationMemberSignature =
    new busUIAppWithdrawalApplicationDocuments();
  ilstbusUIAppWithdrawalApplicationSummary: any = [];
  ibusUIAppViewWithdrawalApplication = new busUIAppViewWithdrawalApplication();
  ibusUIAppWithdrawalUnemploymentAdditionalInfo =
    new busUIAppWithdrawalUnemploymentAdditionalInfo();
  IsDocumentUploadSkip = '';
  covid_future_assistance_id = 0;
  covid_future_assistance_value = '';
  covid_future_assistance_description = '';
  istrIsPhase2C = '';
  preferred_communication_id = 0;
  preferred_communication_value = '';
  payment_mode_id = 0;
  payment_mode_value = '';
  brn = '';
  gender_id = 0;
  gender_value = '';
  work_no = '';
  home_no = '';
  t_c_flag = '';
  residential_address_id = 0;
  postal_address_id = 0;
  ibusUIMemberInfo = new busUIMemberInfo();
  ilstUIGenderValue: any = [];
  ilstUIPreferredCommunicationValue: any = [];
  ilstUIPaymentModeValue: any = [];
  ilstbusUIWithdrawalApplicationEmployementHistory: any = [];
  ibusUIWithdrawalApplicationEmployementHistory =
    new busUIWithdrawalApplicationEmployementHistory();
  ilstUIAddressType: any = [];
  ilstUICountry: any = [];
  ilstUIZone: any = [];
  same_as_postal = '';
  gender_description = '';
  preferred_communication_description = '';
  payment_mode_description = '';
  no_bank_account_flag = '';
  withdrawal_application_successmessage = '';
  ibusUIGovernmentAssistanceAdditionalInfo =
    new busUIGovernmentAssistanceAdditionalInfo();
  IsBrnMandatory = '';
  IsTinMandatory = '';
  IsVoterRegNoMandatory = '';
  IsVaccineRegNoMandatory = '';
  EnableGeoLocation = '';
  GetGeoLocationFlag = '';
  married_name = '';
  ibusUIMicrofinanceWithdrawalAdditionalInfo =
    new busUIMicrofinanceWithdrawalAdditionalInfo();
  ibusUIWithdrawalApplicationPaymentInfo =
    new busUIWithdrawalApplicationPaymentInfo();
  ibusUIAppPostalAddress = new busUIAppAddress();
  ibusUIAppResidentialAddress = new busUIAppAddress();
  ilstUIApplicationMode: any = [];
  ilstUIbusinessStructure: any = [];
  ilstUIEmployementStatus: any = [];
  ibusUIFuneralWithdrawalAdditionalInfo =
    new busUIFuneralWithdrawalAdditionalInfo();
  ibusUIAdviceOfDeath = new busUIAdviceOfDeath();
  ilstUILocation: any = [];
  ilstUIRelationship: any = [];
  ilstUIDetailedRelationship: any = [];
  ilstUIMaritalStaus: any = [];
  GetAodFlag = '';
  IsNormalUnemployment = '';
  total_medical_cost = 0;
  ibusUIAppMedicalWithdrawalConfig = new busUIAppMedicalWithdrawalConfig();
  ibusUIAppWithdrawalMedicalAdditionalInfo =
    new busUIAppWithdrawalMedicalAdditionalInfo();
  ibusUIAppPatientDetail = new busUIAppPatientDetail();
  ilstbusUIAppRelationshipXr: any = [];
  ilstbusUIAppPatientDetail: any = [];
  ilstUIWithdrawalSubType: any = [];
  ilstbusUIMedicalWithdrawalEvidenceDocuments: any = [];
  ilstbusUIAppViewMedicalWithdrawal: any = [];
  ilstFileTypes: any = [];
  ilngFileSize = 0;
  ilstUIAppOrganization: any = [];
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIAppStudentDetails {
  is_existing_student = '';
  student_detail_id = 0;
  withdrawal_application_id = 0;
  person_id = 0;
  fnpf_id = '';
  dob = '';
  first_name = '';
  middle_name = '';
  last_name = '';
  gender_id = 0;
  gender_value = '';
  nationality_id = 0;
  nationality_value = '';
  father_name = '';
  mother_name = '';
  ethnicity_id = 0;
  ethnicity_value = '';
  relation_ship_id = 0;
  relation_ship_value = '';
  relation_ship_description = '';
  study_type_id = 0;
  study_type_value = '';
  passport_number = '';
  passport_issue_date = '';
  passport_expiry_date = '';
  visa_issue_date = '';
  visa_expiry_date = '';
  visa_issue_number = '';
  incidental_cost_amount = 0;
  certificate_of_attainment_flag = '';
  student_FullName = '';
  LoggedInMemberFNPFId = '';
  ProgramName = '';
  InstituteBankId = 0;
  InstituteBankOrgId = 0;
  InstitutionId = 0;
  InstitutionName = '';
  StudentId = '';
  istrInvoiceNo = '';
  istrBRN = '';
  is_bank_statement_provided = '';
  student_name = '';
  student_tin = '';
  ibusUICurrentAppStudentCourseDetails = new busUIAppStudentCourseDetails();
  ibusUINewAppStudentCourseDetails = new busUIAppStudentCourseDetails();
  ilstbusUICurrentAppStudentCourseDetails: any = [];
  ibusUIAppAccommodationDetails = new busUIAppAccommodationDetails();
  ilstUIRelationship: any = [];
  ilstUIStudyType: any = [];
  ilstUIGender: any = [];
  ilstUINationality: any = [];
  ilstUIEthnicity: any = [];
  ilstUIEducationProviders: any = [];
  ilstUIAccommodationProviders: any = [];
  ilstUIAccommodationProviderTypes: any = [];
  ilstUIActiveBanks: any = [];
  ilstUIPreviouslyUsedBanks: any = [];
  ibusUIAppStudentPassportDoc = new busUIAppWithdrawalApplicationDocuments();
  ibusUIAppStudentVisaDoc = new busUIAppWithdrawalApplicationDocuments();
  ibusUIAppStudentBirthCertificateDoc =
    new busUIAppWithdrawalApplicationDocuments();
  ibusUIAppStudentSpouseDoc = new busUIAppWithdrawalApplicationDocuments();
  ibusUIAppBankStatementDoc = new busUIAppWithdrawalApplicationDocuments();
  ibusUIBankAccountDetails = new busUIBankAccountDetails();
  ibusUIAppWithdrawalApplicationTextBookQuotation =
    new busUIAppWithdrawalApplicationDocuments();
  ibusUIAppWithdrawalApplicationTutionFeeInvoice =
    new busUIAppWithdrawalApplicationDocuments();
  ilstUIBankAccountDepositType: any = [];
  add_overseas_flag = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIAppWithdrawalApplicationDocuments {
  withdrawal_application_document_id = 0;
  withdrawal_application_id = 0;
  student_detail_id = 0;
  document_type_id = 0;
  document_type_value = '';
  document_file = '';
  type = '';
  size = '';
  file_name = '';
  relative_path = '';
  document_type_description = '';
  base_64 = '';
  ImageFile = '';
  istrFNPFId = '';
  promis_document_id = 0;
  app_doc_status_id = 0;
  app_doc_status_value = '';
  status_id = 0;
  status_value = '';
  isMandatory = '';
  patient_detail_id = 0;
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIConfigValue {
  config_id = 0;
  config_constant = '';
  config_const_description = '';
  config_value_serial_id = 0;
  Data = '';
  Data1 = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIAppEducationWithdrawalConfig {
  idec_textbook_cost = 0;
  idec_accommodation_cost = 0;
  idec_incidental_cost = 0;
  idec_Eligibility_Amount = 0;
  idec_Current_Eligibility_Amount = 0;
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIAppWithdrawalApplicationSummary {
  student_detail_id = 0;
  student_name = '';
  totalAmount = 0;
  ilstUIAssistances: any = [];
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIAppViewWithdrawalApplication {
  ilstUIStudents: any = [];
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIAppWithdrawalUnemploymentAdditionalInfo {
  app_withdrawal_unemployment_additional_info_id = 0;
  withdrawal_application_id = 0;
  is_email_preferred_communication_mode = '';
  is_mobile_preferred_communication_mode = '';
  un_employment_notes = '';
  employer_contact_name = '';
  employer_contact_designation = '';
  employer_email = '';
  employer_contact = '';
  reason_id = 0;
  reason_value = '';
  category_id = 0;
  category_value = '';
  license_class_id = 0;
  license_class_value = '';
  permit_no = '';
  driver_license_no = '';
  amount_requested = 0;
  date_of_resignation_termination = '';
  business_license_no = '';
  payment_mode_id = 0;
  payment_mode_value = '';
  post_office_org_id = 0;
  post_office_org_ref_no = '';
  nearest_post_office_name = '';
  is_bank_statement_provided = '';
  payment_to_mobile_no = '';
  account_name = '';
  bank_name = '';
  account_no = '';
  bank_org_ref_no = '';
  bank_org_id = 0;
  is_payment_deposits_agree = '';
  payment_deposits_agree_datetime = '';
  employer_org_id = 0;
  employer_org_ref_no = '';
  employer_org_name = '';
  business_licence_date = '';
  tax_compliance_certificate_validity_date = '';
  iMaxWithdrawalAmount = 0;
  iMinimamAccountBalance = 0;
  iMinimamRequestAmount = 0;
  bank_account_id = 0;
  reason_description = '';
  category_description = '';
  license_class_description = '';
  payment_mode_description = '';
  is_valid_employment_history = '';
  employment_start_date = '';
  employment_end_date = '';
  ilstUIUnemploymentCategories: any = [];
  ilstUIUnemploymentReasons: any = [];
  ilstUILicenseClass: any = [];
  ilstUIPaymentModes: any = [];
  ilstUIPostOffices: any = [];
  ilstUIBanks: any = [];
  ilstUIPreviouslyUsedBank: any = [];
  ibusUIBankStatement = new busUIAppWithdrawalApplicationDocuments();
  ibusUITerminationLetter = new busUIAppWithdrawalApplicationDocuments();
  ibusUITaxCertificate = new busUIAppWithdrawalApplicationDocuments();
  ibusUIBusinessLicense = new busUIAppWithdrawalApplicationDocuments();
  ibusUIPhotoId = new busUIAppWithdrawalApplicationDocuments();
  ibusUILetterFromPermitHolder = new busUIAppWithdrawalApplicationDocuments();
  ibusUIPermitCopy = new busUIAppWithdrawalApplicationDocuments();
  ibusUIOtherDocuments = new busUIAppWithdrawalApplicationDocuments();
  ilstbusUIEmploymentHistory: any = [];
  employer_status_id = 0;
  employer_status_value = '';
  employer_status_description = '';
  isCsSubmitted = '';
  ilstMemberConsentInstructions: any = [];
  idecPartialWithdrawalEligibility = 0;
  idecOtherPartialWithdrawalEligibility = 0;
  isDocumentMandatory = '';
  istrDocType = '';
  bsb_routing_no = '';
  swift_code = '';
  bank_address = '';
  employment_row_id = 0;
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIMemberInfo {
  FNPF_No = '';
  TIN_No = '';
  DOB = '';
  First_Name = '';
  Full_Name = '';
  email_id = '';
  mobile_no = '';
  father_name = '';
  mother_name = '';
  Person_ID = 0;
  age = 0;
  member_account_balance = 0;
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIWithdrawalApplicationEmployementHistory {
  withdrawal_application_employement_history_id = 0;
  withdrawal_application_id = 0;
  employer_org_id = 0;
  employer_name = '';
  employement_from_year = 0;
  employement_to_year = 0;
  is_last_employement = '';
  last_employement_end_date = '';
  last_employer_address_id = 0;
  ibusUIAppAddress = new busUIAppAddress();
  member_account_employement_id = 0;
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIGovernmentAssistanceAdditionalInfo {
  government_assistance_additional_info_id = 0;
  withdrawal_application_id = 0;
  citizenship_no = '';
  voter_reg_no = '';
  fnpf_no = '';
  first_jab_flag = '';
  first_jab_place = '';
  first_jab_date = '';
  first_jab_consent = '';
  second_jab_flag = '';
  second_jab_place = '';
  second_jab_date = '';
  second_jab_consent = '';
  total_amount = 0;
  payout_amount = 0;
  statutory_declaration = '';
  location_detail = '';
  device_detail = '';
  first_jab_vaccination_reg_no = '';
  second_jab_vaccination_reg_no = '';
  GA_Balance_Amount = 0;
  Enable_Unemployement_option = '';
  ibusUIResidentialAddress = new busUIAppAddress();
  residential_address_id = 0;
  enable_second_jab_page = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIMicrofinanceWithdrawalAdditionalInfo {
  microfinance_withdrawal_additional_info_id = 0;
  withdrawal_application_id = 0;
  business_structure_id = 0;
  business_structure_value = '';
  business_registration_name = '';
  trade_name = '';
  business_registration_number = '';
  business_registration_date = '';
  business_tin = '';
  business_address_id = 0;
  owner_fnpf_id = '';
  owner_full_name = '';
  owner_business_owner_tin = '';
  owner_employement_status_id = 0;
  owner_employement_status_value = '';
  utilization_of_funds = '';
  indemnity_and_declaration = '';
  fnpf_id = '';
  application_mode_id = 0;
  application_mode_value = '';
  ibusUIAppBusinessAddress = new busUIAppAddress();
  indemnity_and_declaration_content = '';
  request_amount_content = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIWithdrawalApplicationPaymentInfo {
  withdrawal_application_payment_info_id = 0;
  withdrawal_application_id = 0;
  account_name = '';
  bank_name = '';
  account_no = '';
  bank_org_ref_no = '';
  bank_org_id = 0;
  payment_to_mobile_no = '';
  is_payment_deposits_agree = '';
  payment_deposits_agree_datetime = '';
  is_bank_statement_provided = '';
  employer_org_id = 0;
  employer_org_ref_no = '';
  employer_org_name = '';
  post_office_org_id = 0;
  post_office_org_ref_no = '';
  bank_account_id = 0;
  tax_compliance_certificate_validity_date = '';
  bsb_routing_no = '';
  swift_code = '';
  bank_address = '';
  fnpf_id = '';
  nearest_post_office_name = '';
  ilstUIBanks: any = [];
  ilstUIPreviouslyUsedBank: any = [];
  no_bank_account_flag = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIAppAddress {
  address_id = 0;
  address_type_id = 0;
  address_type_value = '';
  address_line_1 = '';
  address_line_2 = '';
  address_line_3 = '';
  address_line_4 = '';
  city = '';
  postal_code = '';
  country_id = 0;
  country_value = '';
  source_id = 0;
  source_value = '';
  zone_id = 0;
  zone_value = '';
  status_id = 0;
  status_value = '';
  org_id = 0;
  person_id = 0;
  approval_flag = '';
  country_description = '';
  zone_description = '';
  fnpf_id = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIFuneralWithdrawalAdditionalInfo {
  funeral_withdrawal_additional_info_id = 0;
  withdrawal_application_id = 0;
  primary_applicant_flag = '';
  deceased_person_id = 0;
  deceased_person_fnpf_id = '';
  advice_of_death_id = 0;
  medical_certificate_no = '';
  cause_of_death_id = 0;
  cause_of_death_value = '';
  death_certificate_no = '';
  place_of_death = '';
  place_of_burial = '';
  burial_date = '';
  relationship_id = 0;
  relationship_value = '';
  deceased_person_brn = '';
  deceased_person_tin = '';
  deceased_person_marital_status_id = 0;
  deceased_person_marital_status_value = '';
  indemnity_and_declaration_content = '';
  request_amount_content = '';
  fnpf_id = '';
  death_date = '';
  detailed_relationship_to_deceased_id = 0;
  detailed_relationship_to_deceased_value = '';
  deceased_person_first_name = '';
  deceased_person_middle_name = '';
  deceased_person_last_name = '';
  deceased_person_date_of_birth = '';
  deceased_person_father_name = '';
  deceased_person_dob = '';
  is_buried = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIAdviceOfDeath {
  advice_of_death_id = 0;
  deceased_person_id = 0;
  status_id = 0;
  status_value = '';
  reason_id = 0;
  reason_value = '';
  received_date = '';
  received_location_id = 0;
  received_location_value = '';
  error_status_id = 0;
  error_status_value = '';
  suppress_warnings_flag = '';
  death_date = '';
  death_reg_certificate_no = '';
  medical_certificate_no = '';
  death_cause_id = 0;
  death_cause_value = '';
  death_cause_other_txt = '';
  informant_fnpf_id = '';
  informant_person_id = 0;
  informant_name = '';
  informant_mailing_address = '';
  informant_telephone_no = '';
  informant_email_address = '';
  relationship_to_deceased_id = 0;
  relationship_to_deceased_value = '';
  processed_date = '';
  informant_other_contact_no = '';
  deceased_person_fnpf_id = '';
  deceased_person_brn_no = '';
  deceased_person_tin_no = '';
  is_deacesed_person_buried = '';
  is_deacesed_person_marital_status_id = 0;
  is_deacesed_person_marital_status_value = '';
  notes = '';
  mode_of_contact_id = 0;
  mode_of_contact_value = '';
  ilstbusUIAdviceOfDeathDocuments: any = [];
  ilstUILocation: any = [];
  ilstUIRelationship: any = [];
  ilstUIDetailedRelationship: any = [];
  ilstUIMaritalStaus: any = [];
  ibusUIAdviceOfDeathDocumentsMemberPhoto = new busUIAdviceOfDeathDocuments();
  ibusUIAdviceOfDeathDocumentsSignature = new busUIAdviceOfDeathDocuments();
  promis_advice_of_death_id = 0;
  is_check_employment_history = '';
  relationship_to_deceased_description = '';
  burial_date = '';
  burial_place = '';
  detailed_relationship_to_deceased_id = 0;
  is_user_existing_from_promis = '';
  detailed_relationship_to_deceased_value = '';
  deceased_person_dob = '';
  ilstUIDeathCause: any = [];
  deceased_person_name = '';
  deceased_person_father_name = '';
  Requirements_list1_for_AOD = '';
  Requirements_list2_for_AOD = '';
  ilstUIAODRequirementsPage1: any = [];
  ilstUIAODRequirementsPage2: any = [];
  ibusUIAdviceOfDeathLastEmployementHistory =
    new busUIAdviceOfDeathEmployementHistory();
  ilstbusUIAdviceOfDeathEmployementHistory: any = [];
  ibusUIAdviceOfDeathEmployementHistory =
    new busUIAdviceOfDeathEmployementHistory();
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIAppMedicalWithdrawalConfig {
  idec_withdrawal_eligibility_amount = 0;
  idec_current_eligibility_amount = 0;
  idec_incidental_cost = 0;
  idecPrimaryApplicationAmt = 0;
  idecSecondaryApplicationAmt = 0;
  idecTotalMedicalCostAmt = 0;
  idec_remaining_medical_cost_to_pay = 0;
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIAppWithdrawalMedicalAdditionalInfo {
  withdrawal_medical_additional_info_id = 0;
  withdrawal_application_id = 0;
  is_joint_withdrawal_application = '';
  primary_applicant_fnpf_id = '';
  joint_withdrawal_application_id = 0;
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIAppPatientDetail {
  patient_detail_id = 0;
  withdrawal_application_id = 0;
  fnpf_id = '';
  person_id = 0;
  first_name = '';
  middle_name = '';
  last_name = '';
  father_name = '';
  mother_name = '';
  date_of_birth = '';
  birth_registration_number = '';
  tin = '';
  gender_id = 0;
  gender_value = '';
  marital_status_id = 0;
  marital_status_value = '';
  is_applying_for_self = '';
  total_incidental_cost_amt = 0;
  patient_full_name = '';
  ibusUIAppRelationshipXr = new busUIAppRelationshipXr();
  ibusUIAppPatientTreatmentDetail = new busUIAppPatientTreatmentDetail();
  ilstbusUIAppPatientTreatmentDetail: any = [];
  ilstbusUIAppPatientDocuments: any = [];
  ilstFileTypes: any = [];
  ilngFileSize = 0;
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIAppRelationshipXr {
  relationship_xr_id = 0;
  withdrawal_application_id = 0;
  patient_detail_id = 0;
  promis_patient_detail_id = 0;
  relationship_id = 0;
  relationship_value = '';
  relationship_description = '';
  patient_full_name = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIAppViewMedicalWithdrawal {
  promis_application_id = 0;
  promis_received_date = '';
  promis_withdrawal_status = '';
  is_selected = false;
  istbusUIAppViewPatient: any = [];
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIAppOrganization {
  org_id = 0;
  org_ref_no = '';
  tin = '';
  business_registration_no = '';
  org_name = '';
  trade_name = '';
  status_id = 0;
  status_description = '';
  status_value = '';
  ilstUIClbAppBankAccounts: any = [];
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIAppStudentCourseDetails {
  student_course_detail_id = 0;
  student_detail_id = 0;
  student_id = '';
  institution_org_id = 0;
  institution__org_name = '';
  course_term_id = 0;
  course_term_value = '';
  program_of_study = '';
  course_code = '';
  course_name = '';
  course_fee = 0;
  tution_fee = 0;
  text_book_cost = 0;
  assistance_typeId = 0;
  assistance_type_value = '';
  incidental_expenses = 0;
  istrAssistanceType = '';
  invoice_no = '';
  text_book_invoice_no = '';
  incidental_expenses_invoice_no = '';
  tuition_fee_invoice_no = '';
  ilstUIProgramOfStudy: any = [];
  course_term_description = '';
  institute_bank_account_id = 0;
  institute_bank_org_id = 0;
  institute_bank_org_ref_no = '';
  institute_bank_name = '';
  institute_bank_account_no = '';
  institute_bank_account_name = '';
  bank_name = '';
  swift_code = '';
  bsb_routing_iban_no = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIAppAccommodationDetails {
  student_accommodation_id = 0;
  student_detail_id = 0;
  institution_id = 0;
  org_name = '';
  invoice_no = '';
  land_lord_person_id = 0;
  accommodation_cost_amt = 0;
  provider_type_id = 0;
  provider_type_value = '';
  provider_type_description = '';
  LoggedInMemberFNPFNo = '';
  ibusUIAppWithdrawalApplicationDocuments =
    new busUIAppWithdrawalApplicationDocuments();
  institute_bank_account_id = 0;
  institute_bank_org_id = 0;
  institute_bank_org_ref_no = '';
  institute_bank_account_no = '';
  institute_bank_account_name = '';
  bank_name = '';
  swift_code = '';
  bsb_routing_iban_no = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIAppBankAccount {
  c_and_f_notification_flag = '';
  end_date = '';
  start_date = '';
  org_id = 0;
  person_id = 0;
  status_value = '';
  status_description = '';
  status_id = 0;
  account_type_value = '';
  account_type_description = '';
  account_type_id = 0;
  account_name = '';
  account_number = '';
  bank_address_id = 0;
  bank_id = 0;
  bank_org_ref_no = '';
  bank_account_id = 0;
  error_status_id = 0;
  error_status_value = '';
  status_Description = '';
  account_type_Description = '';
  bank_name = '';
  account_details = '';
  swift_code = '';
  bsb_routing_iban_no = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIBankAccountDetails {
  bank_account_details_id = 0;
  withdrawal_application_id = 0;
  student_detail_id = 0;
  account_name = '';
  account_number = '';
  bank_org_ref_no = '';
  bank_name = '';
  loggedInMemberFNPFID = '';
  bank_org_id = 0;
  bank_account_id = 0;
  account_type_id = 0;
  account_type_value = '';
  account_type_description = '';
  status_description = '';
  status_id = 0;
  status_value = '';
  person_id = 0;
  c_and_f_notification_flag = '';
  end_date = '';
  start_date = '';
  org_id = 0;
  bank_address_id = 0;
  bank_id = 0;
  error_status_id = 0;
  error_status_value = '';
  deposit_mode_id = 0;
  deposit_mode_value = '';
  bank_address = '';
  bsb_or_routing_number = '';
  swift_code = '';
  is_payment_deposits_agree = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIAppWithdrawalApplicationAssistances {
  assistance_type = '';
  assistance_amount = 0;
  assistance_type_description = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIAppViewStudent {
  student_detail_id = 0;
  student_name = '';
  school_name = '';
  program_of_study = '';
  course_term = '';
  ilstUIAssistances: any = [];
  ilstUICourses: any = [];
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIEmploymentHistory {
  employer = '';
  start_date = '';
  end_date = '';
  occupation = '';
  org_Ref_no = '';
  org_id = 0;
  row_id = 0;
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIAdviceOfDeathDocuments {
  advice_of_death_document_id = 0;
  advice_of_death_id = 0;
  document_type_id = 0;
  document_type_value = '';
  document_file = '';
  type = '';
  size = '';
  file_name = '';
  relative_path = '';
  status_id = 0;
  status_value = '';
  promis_document_id = 0;
  app_doc_status_id = 0;
  app_doc_status_value = '';
  is_mandatory = '';
  document_type_description = '';
  base64 = '';
  ImageFile = '';
  FNPFId = '';
  ImageContent = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIAdviceOfDeathEmployementHistory {
  advice_of_death_employement_history_id = 0;
  advice_of_death_id = 0;
  employer_org_id = 0;
  employer_name = '';
  employement_from_year = 0;
  employement_to_year = 0;
  is_last_employement = '';
  last_employement_end_date = '';
  last_employer_address_id = 0;
  member_account_employement_id = 0;
  ibusUIAppAddress = new busUIAppAddress();
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIAppPatientTreatmentDetail {
  patient_treatment_detail_id = 0;
  patient_detail_id = 0;
  institution_org_id = 0;
  institution__org_name = '';
  treatment_type_txt = '';
  diagnosis_txt = '';
  estimate_flag = '';
  estimate_invoice_no = '';
  estimate_amt = 0;
  actual_invoice_no = '';
  actual_invoice_amt = 0;
  medical_cost = 0;
  institute_bank_account_id = 0;
  institute_bank_account_org_id = 0;
  institute_bank_account_no = '';
  institute_bank_account_name = '';
  institute_bank_account_bank_name = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIAppViewPatientDetails {
  promis_patient_detail_id = 0;
  patient_name = '';
  treatment_type = '';
  diagnosis = '';
  treatment_cost = 0;
  medical_institution_name = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIAppViewStudentCourses {
  course_code = '';
  course_name = '';
  course_code_name = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIAdditionalContributionPayment {
  additional_contribution_payment_id = 0;
  fnpf_id = '';
  payment_for_id = 0;
  payment_for_value = '';
  contribution_type_id = 0;
  contribution_type_value = '';
  other_person_fnpf_id = '';
  other_person_dob = '';
  contribution_amount = 0;
  general_ac_split_percentage = 0;
  general_ac_split_amount = 0;
  preserved_ac_split_percentage = 0;
  preserved_ac_split_amount = 0;
  payment_status_id = 0;
  payment_status_value = '';
  deposit_till_id = 0;
  promis_deposit_id = 0;
  member_account_transaction_id = 0;
  confirm_additional_contribution_member_no = '';
  confirm_additional_contribution_member_fullname = '';
  confirm_additional_contribution_member_name_dob = '';
  memberfnpfnoandfirstname = '';
  memberfirstname = '';
  ilstbuUIAdditionalContributionPaymentStatusHistory: any = [];
  ilstbusUIAdditionalContributionPaymentCommunicationHistory: any = [];
  ilstbusUIAlreadyExistingPayees: any = [];
  ilstbusUIpaymentamounts: any = [];
  rating = 0;
  is_accept_condition = '';
  split_changed_content = '';
  online_payment_content = '';
  promis_remittance_id = 0;
  paymentdate = '';
  view_receipt = '';
  source_of_fund_id = 0;
  source_of_fund_value = '';
  other_source_of_fund = '';
  ilstbusUISourceOfFund: any = [];
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class buUIAdditionalContributionPaymentStatusHistory {
  additional_contribution_payment_status_history_id = 0;
  additional_contribution_payment_id = 0;
  payment_status_id = 0;
  payment_status_value = '';
  changed_date = '';
  changed_by = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIAdditionalContributionPaymentCommunicationHistory {
  additional_contribution_payment_communication_history_id = 0;
  additional_contribution_payment_id = 0;
  communication_tracking_id = 0;
  status_id = 0;
  status_value = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIPaymentTransactionPayees {
  strFnpfNo = '';
  strFnpfNoName = '';
  strName = '';
  member_account_id = 0;
  MinContAmount = 0;
  MaxContAmount = 0;
  lstUIErrorMsg: any = [];
  person_id = 0;
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIPaymentTransaction {
  payment_transaction_id = 0;
  payment_type_id = 0;
  payment_type_value = '';
  lngrequest_id = 0;
  strreturn_data = '';
  strrequestData = '';
  lngclientId = 0;
  strSecretkey = '';
  transactionUrl = '';
  transaction_amount = 0;
  TransactionOverUrl = '';
  destinationurl = '';
  requestID = 0;
  token = '';
  aTransactionDate = '';
  strfnpf_no = '';
  strName = '';
  strTransactionCode = '';
  strPaidBy = '';
  strPaidTo = '';
  aPaidToMemberName = '';
  aPaidToMemeberContactNo = '';
  aPaidByMemberName = '';
  aPaidByMemeberContactNo = '';
  blisNotificationSend = false;
  istrUserId = '';
  iinttransactionstatusid = 0;
  istrtransactionstatusvalue = '';
  isChecked = '';
  istrPaidByFnpfandName = '';
  istrPaidToFnpfandName = '';
  transaction_status_description = '';
  ilstUIMPaisaStatus: any = [];
  ilstUIPaymentTransactionPayee: any = [];
  ilstUIbusUIPaymentTransactionStatus: any = [];
  ilstRemittanceStatus: any = [];
  strtransactionstate = '';
  ibldisablebtn = false;
  totalCountOfPending = 0;
  strPayerMobileNumber = '';
  additional_contribution_payment_id = 0;
  response_code = '';
  card_type = '';
  payment_for_type_value = '';
  payment_for_type_id = 0;
  transaction_no = '';
  ibusUIAdditionalContributionPayment =
    new busUIAdditionalContributionPayment();
  payer_mobile_no = '';
  payment_id = '';
  transaction_id = '';
  transaction_time = '';
  transaction_initiation_time = '';
  card_number = '';
  remitter_name = '';
  transaction_status_id = 0;
  transaction_status_value = '';
  ibusUIVoluntaryContributionPayment = new busUIVoluntaryContributionPayment();
  bsp_visa_debit_card_transaction_charge = 0;
  bsp_visa_credit_card_transaction_charge = 0;
  other_card_transaction_charge = 0;
  bsp_visa_debit_card_payable_amount = 0;
  bsp_visa_credit_card_payable_amount = 0;
  other_cards_payable_amount = 0;
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIPaymentTransactionPayee {
  key = '';
  value = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIPaymentTransactionStatus {
  status_code = '';
  status_description = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIVoluntaryContributionPayment {
  voluntary_contribution_payment_id = 0;
  fnpf_id = '';
  payment_for_id = 0;
  payment_for_value = '';
  contribution_type_id = 0;
  contribution_type_value = '';
  other_person_fnpf_id = '';
  other_person_dob = '';
  contribution_amount = 0;
  general_ac_split_percentage = 0;
  general_ac_split_amount = 0;
  preserved_ac_split_percentage = 0;
  preserved_ac_split_amount = 0;
  payment_status_id = 0;
  payment_status_value = '';
  deposit_till_id = 0;
  promis_deposit_id = 0;
  member_account_transaction_id = 0;
  memberfnpfnoandfirstname = '';
  memberfirstname = '';
  ilstbusUIpaymentamounts: any = [];
  rating = 0;
  is_accept_condition = '';
  split_changed_content = '';
  online_payment_content = '';
  promis_remittance_id = 0;
  paymentdate = '';
  view_receipt = '';
  confirm_voluntary_contribution_member_no = '';
  MemberAccountId = 0;
  Person_ID = 0;
  confirm_voluntary_contribution_member_fullname = '';
  confirm_voluntary_contribution_member_name_dob = '';
  is_split_changed = '';
  source_of_fund_id = 0;
  source_of_fund_value = '';
  other_source_of_fund = '';
  ilstbusUISourceOfFund: any = [];
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUINdMemberAffectedInfo {
  nd_member_affected_info_id = 0;
  fnpf_no = '';
  person_id = 0;
  geo_location = '';
  nd_code_id = 0;
  nd_code_value = '';
  affected_date = '';
  nd_application_id = 0;
  province_id = 0;
  province_value = '';
  member_first_name = '';
  member_middle_name = '';
  member_last_name = '';
  province_description = '';
  ibusUIGeoLocationDetail = new busUIGeoLocationDetail();
  ilstUIProvince: any = [];
  ilstUINaturalDisasterCode: any = [];
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIGeoLocationDetail {
  latitude = 0;
  longitude = 0;
  countryCode = '';
  countryName = '';
  postalCode = '';
  administrativeArea = '';
  subAdministrativeArea = '';
  locality = '';
  subLocality = '';
  thoroughfare = '';
  subThoroughfare = '';
  areasOfInterest: any = [];
}

export class busUIBSPRequestMessage {
  nar_msgType = '';
  nar_merTxnTime = '';
  nar_merBankCode = '';
  nar_orderNo = '';
  nar_merId = '';
  nar_txnCurrency = '';
  nar_txnAmount = '';
  nar_remitterEmail = '';
  nar_remitterMobile = '';
  nar_cardType = '';
  nar_checkSum = '';
  nar_paymentDesc = '';
  nar_version = '';
  nar_returnUrl = '';
  nar_Secure = '';
}

export class RedirectResult {
  Location = '';
  Request: any = {};
}

export class busUIBSPResponceMessage {
  nar_msgType = '';
  nar_narTxnId = '';
  nar_narTxnTime = '';
  nar_merTxnTime = '';
  nar_orderNo = '';
  nar_merId = '';
  nar_txnCurrency = '';
  nar_txnAmount = '';
  nar_checkSum = '';
  nar_remitterName = '';
  nar_remitterBankId = '';
  nar_debitAuthCode = '';
  nar_debitAuthNo = '';
  nar_cardType = '';
  nar_cardNo = '';
  nar_remarks = '';
  nar_returnUrl = '';
}

export class busUIVoluntaryMemberDetails {
  voluntary_member_detail_id = 0;
  tin = '';
  country_of_birth_id = 0;
  country_of_birth_value = '';
  country_of_birth_description = '';
  birth_reg_no = '';
  dob = '';
  first_name = '';
  middle_name = '';
  last_name = '';
  gender_id = 0;
  gender_value = '';
  gender_description = '';
  father_name = '';
  mother_name = '';
  guardian_name = '';
  ethnicity_id = 0;
  ethnicity_value = '';
  ethnicity_description = '';
  nationality_id = 0;
  nationality_value = '';
  email_id = '';
  contact_no = '';
  status_id = 0;
  status_value = '';
  livingin_id = 0;
  livingin_value = '';
  livingin_description = '';
  passport_no = '';
  passport_nationality_Id = 0;
  passport_nationality_Value = '';
  passport_dob = '';
  passport_gender_id = 0;
  passport_gender_value = '';
  placeofbirth_in_passport_id = 0;
  placeofbirth_in_passport_value = '';
  date_of_issue = '';
  date_of_expiry = '';
  passport_surname = '';
  passport_first_name = '';
  passport_middle_name = '';
  lngTimer = 0;
  maskedTin = '';
  FullName = '';
  marital_status_id = 0;
  marital_status_value = '';
  marital_status_description = '';
  occupation = '';
  date_of_marriage = '';
  member_image = '';
  member_signature = '';
  rating = 0;
  createdByFullname = '';
  createdByDate = '';
  nationality_description = '';
  totalCountOfPendingApproval = 0;
  istrFileApplicationFormContent = '';
  voluntarymemberType = '';
  voluntarymemberTypeId = 0;
  voluntarymemberTypedescription = '';
  ilstUICountries: any = [];
  ilstUIGender: any = [];
  ilstUINationality: any = [];
  ilstUIEthnicity: any = [];
  ilstUILivingIn: any = [];
  ilstUIPassportGender: any = [];
  ilstUIPlaceOfBirth: any = [];
  ilstUIMaritalStatus: any = [];
  ibusUIVoluntaryMemberHomeAddress = new busUIVoluntaryMemberAddress();
  ibusUIVoluntaryMemberPostalAddress = new busUIVoluntaryMemberAddress();
  ibusUIVoluntaryMemberDocuments = new busUIVoluntaryMemberDocuments();
  ilstbusUIVoluntaryMemberDocuments: any = [];
  ilstbusUIVoluntaryMemberAddress: any = [];
  ibusUIAdministrator = new busUIAdministrator();
  submittedDate = '';
  approvedDate = '';
  rejectedDate = '';
  ilstUIMemberType: any = [];
  ilstUIRelationshipType: any = [];
  ilstbusUIAdministrator: any = [];
  IsSameEmail = false;
  IsSameContact = false;
  ilstbusUIVoluntaryMemberAdministratorDocuments: any = [];
  AdministratorPassword = '';
  ilngkioskMemberDetail = 0;
  IsNeedOfPassword = false;
  token: any = [];
  IsMemberEligibleForRegistration = '';
  action_status_id = 0;
  action_status_value = '';
  action_status_description = '';
  CreatedByDefault = '';
  notes = '';
  ibusUIVoluntaryMemberRegistrationPayment =
    new busUIVoluntaryMemberRegistrationPayment();
  preferred_communication_id = 0;
  preferred_communication_value = '';
  preferred_communication_description = '';
  ilstUIPreferredCommunication: any = [];
  source_of_fund_id = 0;
  source_of_fund_value = '';
  other_source_of_fund = '';
  ilstbusUISourceOfFund: any = [];
  registration_amount = 0;
  view_receipt = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIVoluntaryMemberAddress {
  voluntary_member_address_id = 0;
  voluntary_member_detail_id = 0;
  line_1 = '';
  line_2 = '';
  line_3 = '';
  line_4 = '';
  same_as_home_address = '';
  country_id = 0;
  country_value = '';
  country_description = '';
  address_type_id = 0;
  adddress_type_value = '';
  address_type_description = '';
  bl_is_same_as_home = false;
  full_address = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIVoluntaryMemberDocuments {
  voluntary_member_document_id = 0;
  voluntary_member_detail_id = 0;
  document_type_id = 0;
  document_type_value = '';
  document_file = '';
  type = '';
  size = '';
  file_name = '';
  document_type_description = '';
  base_64 = '';
  ImageFile = '';
  relative_path = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIAdministrator {
  administrator_id = 0;
  kiosk_member_details_id = 0;
  voluntary_member_detail_id = 0;
  fnpf_id = '';
  email_id = '';
  contact = '';
  type_id = 0;
  type_value = '';
  type_description = '';
  first_name = '';
  middle_name = '';
  last_name = '';
  tin = '';
  birth_reg_no = '';
  passport_no = '';
  dob = '';
  gender_Id = 0;
  gender_value = '';
  relationship_Id = 0;
  relationship_value = '';
  administrator_name = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIVoluntaryMemberRegistrationPayment {
  voluntary_member_registration_payment_id = 0;
  fnpf_id = '';
  amount = 0;
  payment_status_id = 0;
  payment_status_value = '';
  deposit_till_id = 0;
  promis_deposit_id = 0;
  member_account_transaction_id = 0;
  rating = 0;
  remittance_id = 0;
  payment_date = '';
  ibusUIPaymentTransaction = new busUIPaymentTransaction();
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busPaymentTransaction {
  iuserInfo = new UserInfo();
  idoBase = new cdoPaymentTransaction();
  ilsMPaisaPayees: any = [];
  ilstbusMPaisaStatus: any = [];
  ilstbusRemittanceStatus: any = [];
  ibusAdditionalContributionPayment = new busAdditionalContributionPayment();
  ibusVoluntaryContributionPayment = new busVoluntaryContributionPayment();
  reference_id = 0;
  istrErrorCode: any = [];
  errorMsgList: any = [];
  infoMessge = new uMessage();
  userInfo = new UserInfo();
  AdditionalParameters: any = [];
}

export class UserInfo {
  UserName = '';
  userLoginID = '';
  referenceID = 0;
  additionalReferenceID1 = 0;
  additionalReferenceID2 = 0;
}

export class cdoPaymentTransaction {
  clientID = '';
  secretKey = '';
  destinationurl = '';
  TransactionOverUrl = '';
  requestID = 0;
  response = 0;
  transactionUrl = '';
  paidToMemeberName = '';
  paidByMemeberName = '';
  paidToMemeberContactNo = '';
  paidByMemeberContactNo = '';
  isNotificationSend = false;
  LoggedInUserId = '';
  isChecked = '';
  strPaidByNameAndFnpf = '';
  strPaidToNameAndFnpf = '';
  transaction_status_description = '';
  ibldisablebtn = false;
  totalCountOfPending = 0;
  additional_contribution_payment_id = 0;
  response_code = '';
  ResultURL = '';
  bsp_visa_debit_card_transaction_charge = 0;
  bsp_visa_credit_card_transaction_charge = 0;
  other_card_transaction_charge = 0;
  bsp_visa_debit_card_payable_amount = 0;
  bsp_visa_credit_card_payable_amount = 0;
  other_cards_payable_amount = 0;
  payment_transaction_id = 0;
  payment_type_id = 0;
  payment_type_value = '';
  request_id = 0;
  transaction_state = '';
  paid_to = '';
  paid_by = '';
  reference_id = 0;
  request_data = '';
  return_data = '';
  transaction_amount = 0;
  transaction_status_code = '';
  token = '';
  payer_mobile_no = '';
  payment_for_type_value = '';
  payment_for_type_id = 0;
  transaction_no = '';
  payment_id = '';
  transaction_id = '';
  transaction_time = '';
  transaction_initiation_time = '';
  card_type = '';
  card_number = '';
  remitter_name = '';
  transaction_status_id = 0;
  transaction_status_value = '';
  transaction_progress_status_value = '';
  transaction_progress_status_id = 0;
  transaction_fees = 0;
  created_by = '';
  created_date = '';
  modified_by = '';
  modified_date = '';
  update_seq = 0;
  deleted_flag = '';
  idoObjState = 0;
  iOldColumnValues: any = {};
}

export class busPaymentTransactionPayee {
  iuserInfo = new UserInfo();
  key = '';
  value = '';
  reference_id = 0;
  istrErrorCode: any = [];
  errorMsgList: any = [];
  infoMessge = new uMessage();
  userInfo = new UserInfo();
  AdditionalParameters: any = [];
}

export class busPaymentTransactionStatus {
  iuserInfo = new UserInfo();
  status_id = 0;
  status_code = '';
  status_description = '';
  reference_id = 0;
  istrErrorCode: any = [];
  errorMsgList: any = [];
  infoMessge = new uMessage();
  userInfo = new UserInfo();
  AdditionalParameters: any = [];
}

export class busConfigValue {
  iuserInfo = new UserInfo();
  idoBase = new cdoConfigValue();
  order_by = 0;
  Data = '';
  Data1 = '';
  errorMsgList: any = [];
  infoMessge = new uMessage();
  userInfo = new UserInfo();
  AdditionalParameters: any = [];
}

export class busAdditionalContributionPayment {
  iuserInfo = new UserInfo();
  idoBase = new cdoAdditionalContributionPayment();
  ilstbusAdditionalContributionPaymentStatusHistory: any = [];
  ilstbusAdditionalContributionPaymentCommunicationHistory: any = [];
  ilstAlreadyExistingPayees: any = [];
  ilstpaymentamounts: any = [];
  ilstSourceOfFund: any = [];
  reference_id = 0;
  istrErrorCode: any = [];
  errorMsgList: any = [];
  infoMessge = new uMessage();
  userInfo = new UserInfo();
  AdditionalParameters: any = [];
}

export class busVoluntaryContributionPayment {
  iuserInfo = new UserInfo();
  idoBase = new cdoVoluntaryContributionPayment();
  ilstSourceOfFund: any = [];
  reference_id = 0;
  istrErrorCode: any = [];
  errorMsgList: any = [];
  infoMessge = new uMessage();
  userInfo = new UserInfo();
  AdditionalParameters: any = [];
}

export class uMessage {
  errorID = 0;
  errorMsg = '';
  errorMsgType = 0;
}

export class cdoConfigValue {
  config_value_serial_id = 0;
  config_id = 0;
  config_constant = '';
  config_const_description = '';
  reference_id = 0;
  created_by = '';
  created_date = '';
  modified_by = '';
  modified_date = '';
  update_seq = 0;
  deleted_flag = '';
  idoObjState = 0;
  iOldColumnValues: any = {};
}

export class cdoAdditionalContributionPayment {
  confirm_additional_contribution_member_no = '';
  confirm_additional_contribution_member_fullname = '';
  confirm_additional_contribution_member_name_dob = '';
  memberfnpfnoandfirstname = '';
  memberfirstname = '';
  split_changed_content = '';
  online_payment_content = '';
  view_receipt = '';
  additional_contribution_payment_id = 0;
  fnpf_id = '';
  payment_for_id = 0;
  payment_for_value = '';
  contribution_type_id = 0;
  contribution_type_value = '';
  other_person_fnpf_id = '';
  other_person_dob = '';
  contribution_amount = 0;
  general_ac_split_percentage = 0;
  general_ac_split_amount = 0;
  preserved_ac_split_percentage = 0;
  preserved_ac_split_amount = 0;
  payment_status_id = 0;
  payment_status_value = '';
  deposit_till_id = 0;
  promis_deposit_id = 0;
  member_account_transaction_id = 0;
  rating = 0;
  is_accept_condition = '';
  promis_remittance_id = 0;
  paymentdate = '';
  source_of_fund_id = 0;
  source_of_fund_value = '';
  other_source_of_fund = '';
  created_by = '';
  created_date = '';
  modified_by = '';
  modified_date = '';
  update_seq = 0;
  deleted_flag = '';
  idoObjState = 0;
  iOldColumnValues: any = {};
}

export class busAdditionalContributionPaymentStatusHistory {
  iuserInfo = new UserInfo();
  idoBase = new cdoAdditionalContributionPaymentStatusHistory();
  reference_id = 0;
  istrErrorCode: any = [];
  errorMsgList: any = [];
  infoMessge = new uMessage();
  userInfo = new UserInfo();
  AdditionalParameters: any = [];
}

export class busAdditionalContributionPaymentCommunicationHistory {
  iuserInfo = new UserInfo();
  idoBase = new cdoAdditionalContributionPaymentCommunicationHistory();
  reference_id = 0;
  istrErrorCode: any = [];
  errorMsgList: any = [];
  infoMessge = new uMessage();
  userInfo = new UserInfo();
  AdditionalParameters: any = [];
}

export class cdoVoluntaryContributionPayment {
  confirm_voluntary_contribution_member_no = '';
  MemberAccountId = 0;
  Person_ID = 0;
  confirm_voluntary_contribution_member_fullname = '';
  confirm_voluntary_contribution_member_name_dob = '';
  memberfnpfnoandfirstname = '';
  memberfirstname = '';
  split_changed_content = '';
  online_payment_content = '';
  is_split_changed = '';
  view_receipt = '';
  voluntary_contribution_payment_id = 0;
  fnpf_id = '';
  payment_for_id = 0;
  payment_for_value = '';
  contribution_type_id = 0;
  contribution_type_value = '';
  other_person_fnpf_id = '';
  other_person_dob = '';
  contribution_amount = 0;
  general_ac_split_percentage = 0;
  general_ac_split_amount = 0;
  preserved_ac_split_percentage = 0;
  preserved_ac_split_amount = 0;
  payment_status_id = 0;
  payment_status_value = '';
  deposit_till_id = 0;
  promis_deposit_id = 0;
  member_account_transaction_id = 0;
  rating = 0;
  is_accept_condition = '';
  promis_remittance_id = 0;
  paymentdate = '';
  source_of_fund_id = 0;
  source_of_fund_value = '';
  other_source_of_fund = '';
  created_by = '';
  created_date = '';
  modified_by = '';
  modified_date = '';
  update_seq = 0;
  deleted_flag = '';
  idoObjState = 0;
  iOldColumnValues: any = {};
}

export class cdoAdditionalContributionPaymentStatusHistory {
  additional_contribution_payment_status_history_id = 0;
  additional_contribution_payment_id = 0;
  payment_status_id = 0;
  payment_status_value = '';
  changed_date = '';
  changed_by = '';
  created_by = '';
  created_date = '';
  modified_by = '';
  modified_date = '';
  update_seq = 0;
  deleted_flag = '';
  idoObjState = 0;
  iOldColumnValues: any = {};
}

export class cdoAdditionalContributionPaymentCommunicationHistory {
  additional_contribution_payment_communication_history_id = 0;
  additional_contribution_payment_id = 0;
  communication_tracking_id = 0;
  status_id = 0;
  status_value = '';
  created_by = '';
  created_date = '';
  modified_by = '';
  modified_date = '';
  update_seq = 0;
  deleted_flag = '';
  idoObjState = 0;
  iOldColumnValues: any = {};
}

export class cdoProcessLog {
  process_log_id = 0;
  process_name = '';
  log_type_id = 0;
  log_type_value = '';
  log_message = '';
  reference_id = 0;
  created_by = '';
  created_date = '';
  modified_by = '';
  modified_date = '';
  update_seq = 0;
  deleted_flag = '';
  idoObjState = 0;
  iOldColumnValues: any = {};
}

export class cdoConfigMetaData {
  config_meta_data_id = 0;
  config_value_serial_id = 0;
  meta_data_name = '';
  meta_data_value = '';
  meta_data_type = '';
  meta_data_description = '';
  reference_id = 0;
  created_by = '';
  created_date = '';
  modified_by = '';
  modified_date = '';
  update_seq = 0;
  deleted_flag = '';
  idoObjState = 0;
  iOldColumnValues: any = {};
}

export class busUIMobileMessageSearch {
  fnfp_id = '';
  message_type_value = '';
  delivery_status_value = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIMobileMessage {
  mobile_message_id = 0;
  fnpf_id = '';
  message_type_id = 0;
  message_type_value = '';
  send_or_recieve_date = '';
  category_id = 0;
  category_value = '';
  transaction_type_id = 0;
  transaction_type_value = '';
  reason_type_id = 0;
  reason_type_value = '';
  message_content = '';
  message_status_id = 0;
  message_status_value = '';
  delivery_status_id = 0;
  delivery_status_value = '';
  contact_ticket_id = 0;
  category_description = '';
  total_messages_count = 0;
  total_unread_messages_count = 0;
  body_max_character_size = 0;
  ilstUICategory: any = [];
  ilstUITransaction: any = [];
  ilstUIReason: any = [];
  ilstUITodaysMessages: any = [];
  ilstUIYesterdayMessages: any = [];
  ilstUIOlderMessages: any = [];
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUILowBalanceWithdrawalApplication {
  ibusUIResidentialAddress = new busUIAppAddress();
  ibusUIPostalAddress = new busUIAppAddress();
  ibusUIWithdrawalApplicationLastEmployementHistory =
    new busUIWithdrawalApplicationEmployementHistory();
  ilstEligibilityStatement: any = [];
  withdrawal_application_id = 0;
  person_id = 0;
  tin = '';
  dob = '';
  first_name = '';
  middle_name = '';
  last_name = '';
  type_id = 0;
  type_value = '';
  sub_type_id = 0;
  sub_type_value = '';
  received_date = '';
  withdrawal_status_id = 0;
  withdrawal_status_value = '';
  withdrawal_action_status_id = 0;
  withdrawal_action_status_value = '';
  withdrawal_mob_status_id = 0;
  withdrawal_mob_status_value = '';
  location_id = 0;
  location_value = '';
  fee_type_id = 0;
  fee_type_value = '';
  fnpf_id = '';
  signature_verified_flag = '';
  photo_verified_flag = '';
  primary_applicant_flag = '';
  appeal_flag = '';
  discretioinary_process_flag = '';
  waive_off_flag = '';
  request_amt = 0;
  age = 0;
  ibltutionFee = false;
  ibltextbook = false;
  iblAccomodation = false;
  iblIncidentalExpenses = false;
  istrInvoiceAmount = '';
  istrInvoiceNo = '';
  idecEducationEligibility = 0;
  rating = 0;
  otp = '';
  otp_generated_time = '';
  nearest_town_id = 0;
  nearest_town_value = '';
  nearest_town = '';
  withdrawal_status_description = '';
  sub_type_description = '';
  type_description = '';
  promis_application_id = 0;
  email_id = '';
  contact_no = '';
  member_email_id = '';
  member_contact_no = '';
  is_email_sent_eg = '';
  is_email_sent_mb = '';
  istrIsDocumentUploaded = '';
  iintContentServerId = 0;
  istrLockdownwithdrawal = '';
  ibusUIAppStudentDetails = new busUIAppStudentDetails();
  ilstbusUIAppStudentDetails: any = [];
  ilstbusUIPreviouslyUsedStudentDetails: any = [];
  ilstbusUIAppWithdrawalApplicationDocuments: any = [];
  ilstUIAssistanceType: any = [];
  ilstUITerms: any = [];
  ilstUINearestTowns: any = [];
  ibusUIAppEducationWithdrawalConfig = new busUIAppEducationWithdrawalConfig();
  ibusUIAppWithdrawalApplicationMemberPhoto =
    new busUIAppWithdrawalApplicationDocuments();
  ibusUIAppWithdrawalApplicationMemberSignature =
    new busUIAppWithdrawalApplicationDocuments();
  ilstbusUIAppWithdrawalApplicationSummary: any = [];
  ibusUIAppViewWithdrawalApplication = new busUIAppViewWithdrawalApplication();
  ibusUIAppWithdrawalUnemploymentAdditionalInfo =
    new busUIAppWithdrawalUnemploymentAdditionalInfo();
  IsDocumentUploadSkip = '';
  covid_future_assistance_id = 0;
  covid_future_assistance_value = '';
  covid_future_assistance_description = '';
  istrIsPhase2C = '';
  preferred_communication_id = 0;
  preferred_communication_value = '';
  payment_mode_id = 0;
  payment_mode_value = '';
  brn = '';
  gender_id = 0;
  gender_value = '';
  work_no = '';
  home_no = '';
  t_c_flag = '';
  residential_address_id = 0;
  postal_address_id = 0;
  ibusUIMemberInfo = new busUIMemberInfo();
  ilstUIGenderValue: any = [];
  ilstUIPreferredCommunicationValue: any = [];
  ilstUIPaymentModeValue: any = [];
  ilstbusUIWithdrawalApplicationEmployementHistory: any = [];
  ibusUIWithdrawalApplicationEmployementHistory =
    new busUIWithdrawalApplicationEmployementHistory();
  ilstUIAddressType: any = [];
  ilstUICountry: any = [];
  ilstUIZone: any = [];
  same_as_postal = '';
  gender_description = '';
  preferred_communication_description = '';
  payment_mode_description = '';
  no_bank_account_flag = '';
  withdrawal_application_successmessage = '';
  ibusUIGovernmentAssistanceAdditionalInfo =
    new busUIGovernmentAssistanceAdditionalInfo();
  IsBrnMandatory = '';
  IsTinMandatory = '';
  IsVoterRegNoMandatory = '';
  IsVaccineRegNoMandatory = '';
  EnableGeoLocation = '';
  GetGeoLocationFlag = '';
  married_name = '';
  ibusUIMicrofinanceWithdrawalAdditionalInfo =
    new busUIMicrofinanceWithdrawalAdditionalInfo();
  ibusUIWithdrawalApplicationPaymentInfo =
    new busUIWithdrawalApplicationPaymentInfo();
  ibusUIAppPostalAddress = new busUIAppAddress();
  ibusUIAppResidentialAddress = new busUIAppAddress();
  ilstUIApplicationMode: any = [];
  ilstUIbusinessStructure: any = [];
  ilstUIEmployementStatus: any = [];
  ibusUIFuneralWithdrawalAdditionalInfo =
    new busUIFuneralWithdrawalAdditionalInfo();
  ibusUIAdviceOfDeath = new busUIAdviceOfDeath();
  ilstUILocation: any = [];
  ilstUIRelationship: any = [];
  ilstUIDetailedRelationship: any = [];
  ilstUIMaritalStaus: any = [];
  GetAodFlag = '';
  IsNormalUnemployment = '';
  total_medical_cost = 0;
  ibusUIAppMedicalWithdrawalConfig = new busUIAppMedicalWithdrawalConfig();
  ibusUIAppWithdrawalMedicalAdditionalInfo =
    new busUIAppWithdrawalMedicalAdditionalInfo();
  ibusUIAppPatientDetail = new busUIAppPatientDetail();
  ilstbusUIAppRelationshipXr: any = [];
  ilstbusUIAppPatientDetail: any = [];
  ilstUIWithdrawalSubType: any = [];
  ilstbusUIMedicalWithdrawalEvidenceDocuments: any = [];
  ilstbusUIAppViewMedicalWithdrawal: any = [];
  ilstFileTypes: any = [];
  ilngFileSize = 0;
  ilstUIAppOrganization: any = [];
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIMemberProfile {
  full_name = '';
  first_name = '';
  middle_name = '';
  last_name = '';
  fnpf_no = '';
  dob = '';
  relationship_status = '';
  citizenship = '';
  location: any = [];
  tin = '';
  age = 0;
  nationality = '';
  home_tel = '';
  mobile_no = '';
  image = '';
  last_seen = '';
  last_interim_printout = '';
  last_detailed_printout = '';
  member_type = '';
  person_id = 0;
  email_id = '';
  alternate_email_id = '';
  current_address = '';
  annual_statement_print_count = 0;
  interim_statement_print_count = 0;
  print_not_allowed = false;
  machine_ip_address = '';
  ibusUIPensioner = new busUIPensioner();
  ibusUIAccountDetail = new busUIAccountDetail();
  ilistbusUIEmploymentHistory: any = [];
  ilistbusUITransaction: any = [];
  ibusUINomination = new busUINomination();
  ilistbusUIMessage: any = [];
  ilistbusUIApplication: any = [];
  ibusUIMemberAddress = new busUIMemberAddress();
  ibusUIMemberUpdateAddress = new busUIMemberUpdateAddress();
  father_name = '';
  mother_name = '';
  ibusUIMemberDetail = new busUIMemberDetail();
  ilistbusUIMinorAccounts: any = [];
  password = '';
  token: any = [];
  IsShowPassword = false;
  user_id = '';
  is_hotlisted = false;
  enableGeoLocation = '';
  minimamContributionAmount = 0;
  maximamContributionAmount = 0;
  lastFinancialYearInterest = 0;
  masked_emailId = '';
  masked_contactno = '';
  parse_mobile_no = '';
  ShowEducationWithdrawalbtn = '';
  ShowUnemploymentWithdrawalbtn = '';
  ShowCovidUnemploymentWithdrawalbtn = '';
  ShowNormalUnemploymentWithdrawalbtn = '';
  reset_pin = '';
  strEncryptedPin = '';
  member_detail_id = 0;
  pin = '';
  strEncryptedOldPin = '';
  ibusUIAppDeviceDetail = new busUIAppDeviceDetail();
  ShowLowBalanceAccountWithdrawalbtn = '';
  ShowContributionSpilitbtn = '';
  ShowGovernmentAssistanceWithdrawalbtn = '';
  ShowMicroFinanceWithdrawalbtn = '';
  ShowAdviceOfDeathbtn = '';
  ShowFuneralWithdrawalbtn = '';
  ShowNaturalDisasterAssistancebtn = '';
  ShowMenuHomebtn = '';
  ShowMenuMyProfilebtn = '';
  ShowMenuMyAccountbtn = '';
  ShowMenuMakePaymentbtn = '';
  ShowMenuMakeCotributionbtn = '';
  ShowMenuPaymentHistorybtn = '';
  ShowMenuMyTransactionbtn = '';
  ShowMenuEmploymentHistorybtn = '';
  ShowMenuNominationbtn = '';
  ShowMenuMakeWithdrawalbtn = '';
  ShowMenuWithdrawalStatusbtn = '';
  ShowMenuMyMessagebtn = '';
  ShowMenuStatementbtn = '';
  ShowMenuPensionsbtn = '';
  ShowMenuPensionOptionbtn = '';
  ShowMenurenewalCertificatebtn = '';
  ShowMenuChangeFNPFNobtn = '';
  ShowMenuChangePasswordbtn = '';
  ShowMenuChangeinbtn = '';
  ShowMenuMyContrbutionSplitbtn = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIPensioner {
  pension_id = '';
  payment_frequency = '';
  next_pay_date = '';
  payment_location = '';
  payment_mode = '';
  total_pension_amount = 0;
  ilistPensionOptions: any = [];
  ilistRenewalCertificates: any = [];
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIAccountDetail {
  account_type = '';
  my_general_balance = 0;
  my_preserved_balance = 0;
  my_total_balance = 0;
  housing_eligibility = 0;
  list_member_account_ids: any = [];
  account_type_value = '';
  member_account_id = 0;
  account_status_value = '';
  account_status_description = '';
  account_subtype_value = '';
  available_general_balance = 0;
  available_preserved_balance = 0;
  available_total_balance = 0;
  ibusUIActiveMemberAccountSubAccountDetail = new busUISubAccountDetail();
  ilstUISubAccounts: any = [];
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUITransaction {
  date = '';
  description = '';
  money_out = 0;
  money_in = 0;
  balance = 0;
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUINomination {
  ilistMemberNominees: any = [];
  ilistPensionNominees: any = [];
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIMessage {
  date = '';
  subject = '';
  message = '';
  office = '';
  ipAddress = '';
  personId = 0;
  fnpfNo = '';
  emailId = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIApplication {
  application_id = 0;
  withdrawal_type = '';
  withdrawal_status = '';
  requested_amount = 0;
  approved_amount = 0;
  paid_out_amount = 0;
  received_date = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIMemberAddress {
  Line1 = '';
  Line2 = '';
  Line3 = '';
  Line4 = '';
  City = '';
  Country = '';
  address_id = 0;
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIMemberUpdateAddress {
  address_type_id = 0;
  address_type_value = '';
  address_type_description = '';
  address_line_1 = '';
  address_line_2 = '';
  address_line_3 = '';
  address_line_4 = '';
  city = '';
  country_id = 0;
  country_value = '';
  country_description = '';
  status_id = 0;
  status_value = '';
  status_description = '';
  address_id = 0;
  person_id = 0;
  org_id = 0;
  zone_value = '';
  zone_description = '';
  zone_id = 0;
  source_value = '';
  source_description = '';
  source_id = 0;
  postal_code = '';
  approval_flag = '';
  source_province_type_id = 0;
  source_province_type_value = '';
  source_district_type_id = 0;
  source_district_type_value = '';
  source_locality_type_id = 0;
  source_locality_type_value = '';
  ilstUIAddressTypes: any = [];
  ilstUICountries: any = [];
  ilstUIProvince: any = [];
  ilstUIDistrict: any = [];
  ilstUILocality: any = [];
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIMemberDetail {
  member_detail_id = 0;
  user_id = '';
  person_id = 0;
  fnpf_number = '';
  tin_number = '';
  dob = '';
  first_name = '';
  full_name = '';
  status_value = '';
  email_id = '';
  alternate_email_id = '';
  contact_no = '';
  member_image = '';
  member_signature = '';
  IsActiveMinorAccounts = false;
  member_EmailId = '';
  member_Mobilenumber = '';
  notes = '';
  is_email_sent = '';
  password = '';
  status_description = '';
  pin = '';
  reset_pin = '';
  encrypted_pin = '';
  is_account_permanently_locked = '';
  no_of_failed_attempts_pin = 0;
  no_of_failed_attempts_password = 0;
  last_pin_failed_attempt_datetime = '';
  last_password_failed_attempt_datetime = '';
  ilstbusUIEmploymentHistory: any = [];
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIMinorAccounts {
  fnpf_no = '';
  personId = 0;
  fnpf_name = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIAppDeviceDetail {
  device_detail_id = 0;
  device_uuid = '';
  device_imei_no = '';
  push_notification_id = '';
  fnpf_no = '';
  person_id = 0;
  member_detail_id = 0;
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIPensionOption {
  option = '';
  pensionable_amount = 0;
  monthly_pension = 0;
  payments_made = 0;
  payments_left = 0;
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIRenewalCertificate {
  rc_no = 0;
  issued_date = '';
  certified_date = '';
  pay_date_from = '';
  pay_date_to = '';
  status = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUISubAccountDetail {
  member_account_subaccount_id = 0;
  member_account_id = 0;
  general_perc = 0;
  preserved_perc = 0;
  addl_general_perc = 0;
  addl_preserved_perc = 0;
  effective_date = '';
  new_addl_general_perc = 0;
  new_addl_preserved_perc = 0;
  fnpf_id = '';
  member_name = '';
  person_id = 0;
  account_type = '';
  new_general_perc = 0;
  new_preserved_perc = 0;
  default_general_perc = 0;
  default_preserved_perc = 0;
  default_addl_general_perc = 0;
  default_addl_preserved_perc = 0;
  total_perc = 0;
  created_date = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUINominees {
  date = '';
  name = '';
  relationship = '';
  share = 0;
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIMobileVersion {
  mobile_version_id = 0;
  internal_version = '';
  android_version = '';
  ios_version = '';
  update_option_id = 0;
  update_option_value = '';
  update_option_description = '';
  update_notes = '';
  release_update = '';
  staff_Id = '';
  ilstUpdateOptions: any = [];
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busMobileVersionSearch {
  istr_internal_version = '';
  istr_android_version = '';
  istr_ios_version = '';
  istr_update_option_value = '';
  TotalCount = 0;
  PageSize = 0;
  PageNumber = 0;
  OrderByColumnName = '';
  Ascending = false;
}

export class busUIStaffLogin {
  staff_id = '';
  staff_password = '';
  first_name = '';
  last_name = '';
  middle_name = '';
  begin_date = '';
  end_date = '';
  status = '';
  user_serial_id = 0;
  IsUserEligibleForApproval = false;
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIMemberLogin {
  userName = '';
  password = '';
  temppassword = '';
  email_id = '';
  alternate_email_id = '';
  masked_email_id = '';
  masked_alternate_email_id = '';
  contact_no = '';
  is_temp_password = '';
  fnpf_no = '';
  pension_no = '';
  person_id = 0;
  token: any = [];
  cquestion = '';
  canswer = '';
  cimage = '';
  tin_no = '';
  lngTimer = 0;
  masked_contact_no = '';
  lastFinancialYearInterest = 0;
  pin = 0;
  reset_pin = '';
  istrReceivedPinbyMobile = '';
  istrReceivedPinbyEmail = '';
  strEncryptedPin = '';
  ibusUIAppDeviceDetail = new busUIAppDeviceDetail();
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIContributionSplit {
  app_contribution_split_id = 0;
  existing_mandatory_general_perc = 0;
  new_mandatory_general_perc = 0;
  existing_mandatory_preserved_perc = 0;
  new_mandatory_preserved_perc = 0;
  existing_additional_general_perc = 0;
  new_additional_general_perc = 0;
  existing_additional_preserved_perc = 0;
  new_additional_preserved_perc = 0;
  t_and_c_flag = '';
  ibusUIContributionSplitDocumentMemberSignature =
    new busUIContributionSplitDocument();
  fnpf_id = '';
  member_email_id = '';
  member_first_name = '';
  member_middle_name = '';
  member_last_name = '';
  person_id = 0;
  account_type_value = '';
  effective_date = '';
  tin = '';
  member_contact_no = '';
  received_date = '';
  member_account_id = 0;
  status_id = 0;
  status_value = '';
  ilstCotributionSplitInformation: any = [];
  ilstCotributionSplitDeclaration: any = [];
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIContributionSplitDocument {
  contribution_split_document_id = 0;
  contribution_split_id = 0;
  document_type_id = 0;
  document_type_value = '';
  document_file = '';
  type = '';
  size = '';
  file_name = '';
  relative_path = '';
  document_type_description = '';
  base_64 = '';
  ImageFile = '';
  istrFNPFId = '';
  promis_document_id = 0;
  app_doc_status_id = 0;
  app_doc_status_value = '';
  status_id = 0;
  status_value = '';
  is_mandatory = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIBase {
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIMemberRegister {
  fnpf_no = '';
  email_id = '';
  masked_email_id = '';
  alternate_email_id = '';
  contact_no = '';
  masked_contact_no = '';
  image = '';
  signature = '';
  status_id = 0;
  status_value = '';
  status_value_description = '';
  person_id = 0;
  token: any = [];
  lngTimer = 0;
  tin_no = '';
  rating = 0;
  member_detail_id = 0;
  alternate_contact_no = '';
  lastFinancialYearInterest = 0;
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIPaypal {
  paypal_id = 0;
  intent = '';
  id = '';
  state = '';
  cart = '';
  created_time = '';
  fnpf_no = '';
  return_data = '';
  ibusUIPaypalPayer = new busUIPaypalPayer();
  ibusUIPaypalTransaction = new busUIPaypalTransaction();
  ibusUIPaypalSale = new busUIPaypalSale();
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIPaypalPayer {
  paypal_payer_id = 0;
  payment_method = '';
  status = '';
  email_id = '';
  first_name = '';
  middle_name = '';
  last_name = '';
  payer_id = '';
  country_code = '';
  paypal_id = 0;
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIPaypalTransaction {
  paypal_transaction_id = 0;
  paypal_id = 0;
  amount = 0;
  currency = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIPaypalSale {
  paypal_sale_id = 0;
  paypal_id = 0;
  id = '';
  state = '';
  payment_mode = '';
  protection_eligibility = '';
  parent_payment = '';
  created_time = '';
  updated_time = '';
  total_amount = 0;
  sub_total = 0;
  currency = '';
  amountCurrency = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIPaypalErrorLog {
  paypal_error_id = 0;
  fnpf_no = '';
  error_log = '';
  error_datetime = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busVoluntaryMemberSearch {
  status_value = '';
  tin = '';
  birth_reg_no = '';
  dob = '';
  TotalCount = 0;
  PageSize = 0;
  PageNumber = 0;
  OrderByColumnName = '';
  Ascending = false;
}

export class busSearchResult {
  TotalCount = 0;
  PageSize = 0;
  PageNumber = 0;
  SearchResult: any = [];
}

export class busVoluntaryMemberDocuments {
  iuserInfo = new UserInfo();
  idoBase = new cdoVoluntaryMemberDocuments();
  istrFileContent = '';
  istrMemberImageFileContent = '';
  reference_id = 0;
  istrErrorCode: any = [];
  errorMsgList: any = [];
  infoMessge = new uMessage();
  userInfo = new UserInfo();
  AdditionalParameters: any = [];
}

export class cdoVoluntaryMemberDocuments {
  document_type_description = '';
  base64 = '';
  ImageFile = '';
  voluntary_member_document_id = 0;
  voluntary_member_detail_id = 0;
  document_type_id = 0;
  document_type_value = '';
  document_file = '';
  type = '';
  size = '';
  file_name = '';
  relative_path = '';
  created_by = '';
  created_date = '';
  modified_by = '';
  modified_date = '';
  update_seq = 0;
  deleted_flag = '';
  idoObjState = 0;
  iOldColumnValues: any = {};
}

export class busUIMPaisa {
  lngmpaisa_transaction_id = 0;
  lngrequest_id = 0;
  strstate = '';
  strreturn_data = '';
  lngclientId = 0;
  strSecretkey = '';
  mpaisaUrl = '';
  transaction_amount = 0;
  mpaisaTransactionOverUrl = '';
  destinationurl = '';
  requestID = 0;
  response = 0;
  token = '';
  aTransactionDate = '';
  strfnpf_no = '';
  strName = '';
  strTransactionCode = '';
  strPaidBy = '';
  strPaidTo = '';
  aPaidToMemberName = '';
  aPaidToMemeberContactNo = '';
  aPaidByMemberName = '';
  aPaidByMemeberContactNo = '';
  blisNotificationSend = false;
  istrUserId = '';
  istrReason = '';
  ilngRemittanceId = 0;
  iintRemittanceStatusId = 0;
  istrRemittanceStatusValue = '';
  isChecked = '';
  istrPaidByFnpfandName = '';
  istrPaidToFnpfandName = '';
  RemittanceStatus = '';
  ilstUIMPaisaStatus: any = [];
  ilstUIMPaisaPayee: any = [];
  ilstUIbusUIMPaisaStatus: any = [];
  ilstRemittanceStatus: any = [];
  strMobileAppStatus = '';
  ibldisablebtn = false;
  totalCountOfPending = 0;
  strPayerMobileNumber = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIMPaisaPayee {
  key = '';
  value = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIMPaisaStatus {
  status_code = '';
  status_description = '';
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}

export class busUIMPaisaPayees {
  strFnpfNo = '';
  strFnpfNoName = '';
  strName = '';
  member_account_id = 0;
  MinContAmount = 0;
  MaxContAmount = 0;
  lstUIErrorMsg: any = [];
  person_id = 0;
  iInfoMessage = '';
  ilstErrorMessages: any = [];
  modified_by = '';
  modified_date = '';
}
