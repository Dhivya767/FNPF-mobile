import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AppSafePipe } from './app-safe/app-safe.pipe';

@NgModule({
  declarations: [AppSafePipe],
  imports: [CommonModule],
  providers: [],
  exports: [AppSafePipe],
})
export class PipesModule {}
