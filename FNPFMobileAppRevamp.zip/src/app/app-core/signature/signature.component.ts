import { AfterViewInit, Component, Input, OnInit, Renderer2, ViewChild } from '@angular/core';
import { ModalController, Platform } from '@ionic/angular';

@Component({
  selector: 'app-signature',
  templateUrl: './signature.component.html',
  styleUrls: ['./signature.component.scss'],
})
export class SignatureComponent implements OnInit, AfterViewInit {
  @Input() label = 'Draw your signature';
  @Input() submitBtnText = 'Submit';

  @ViewChild('myCanvas') canvas: any;
  canvasElement: any;
  lastX!: number;
  lastY!: number;
  currentX!: number;
  currentY!: number;

  xAdujst = 16 + 1;
  yAdjust = 56 + 16 + 1;

  currentColour = '#000000';
  brushSize = 2.5;
  ctx: any;
  showNext = false;

  constructor(public modalController: ModalController,
    public renderer: Renderer2,
    public platform: Platform) { }

  ngOnInit() { }

  ngAfterViewInit() {
    this.canvasElement = this.canvas.nativeElement;
    this.renderer.setAttribute(this.canvasElement, 'width', this.platform.width() - 36 + '');
    this.renderer.setAttribute(this.canvasElement, 'height', this.platform.height() - 156 + '');
    this.ctx = this.canvasElement.getContext('2d');
    this.ctx.fillStyle = 'white';
    this.ctx.fillRect(0, 0, this.canvasElement.width, this.canvasElement.height);
  }


  handleStart(ev: any) {
    this.lastX = ev.touches[0].pageX - this.xAdujst;
    this.lastY = ev.touches[0].pageY - this.yAdjust;

    this.ctx.beginPath();
    this.ctx.arc(this.lastX, this.lastY, 0.75, 0, 2 * Math.PI, true);
    this.ctx.stroke();

    // this.lastX = this.currentX;
    // this.lastY = this.currentY;
    // //console.log(this.lastX, this.lastY);
  }

  handleMove(ev: any) {

    // let ctx = this.canvasElement.getContext('2d');
    const currentX = ev.touches[0].pageX - this.xAdujst;
    const currentY = ev.touches[0].pageY - this.yAdjust;

    this.ctx.beginPath();
    this.ctx.lineJoin = 'round';
    this.ctx.moveTo(this.lastX, this.lastY);
    this.ctx.lineTo(currentX, currentY);
    this.ctx.closePath();
    this.ctx.strokeStyle = this.currentColour;
    this.ctx.lineWidth = this.brushSize;
    this.ctx.stroke();

    this.lastX = currentX;
    this.lastY = currentY;

    this.showNext = true;

  }

  clearDraw() {
    this.ctx.clearRect(0, 0, this.canvasElement.width, this.canvasElement.height);
    this.ctx.fillStyle = 'white';
    this.ctx.fillRect(0, 0, this.canvasElement.width, this.canvasElement.height);
    this.showNext = false;
  }


  dismiss() {
    this.modalController.dismiss();
  }

  goNext() {
    const dataUrl = this.canvasElement.toDataURL();
    // //console.log(dataUrl); 
    this.modalController.dismiss({
      dismissed: true,
      signature: dataUrl
    }

    );
  }

}
