import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SignatureComponent } from './signature.component';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { FormInputModule } from '../form-input/form-input.module';
@NgModule({
  declarations: [SignatureComponent],
  imports: [CommonModule, IonicModule,
  ],
  exports: [SignatureComponent]
})
export class SignatureModule { }
 