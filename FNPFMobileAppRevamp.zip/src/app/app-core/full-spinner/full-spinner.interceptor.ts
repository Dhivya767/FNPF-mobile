import {
  HttpEvent,
  HttpHandler,
  HttpHeaders,
  HttpInterceptor,
  HttpRequest,
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { finalize } from 'rxjs/operators';
import { IonLoading, LoadingController } from '@ionic/angular';

@Injectable()
export class FullSpinnerInterceptor implements HttpInterceptor {
  private requests: HttpRequest<any>[] = [];
  private loading!: HTMLIonLoadingElement;

  constructor(private loadingController: LoadingController) { }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    this.requests.push(request);
    if (this.requests.length === 1) {
      if (request.headers.has('Spinner')) {
        if (request.headers.get('Spinner') === 'true') {
          this.presentLoading();
        }
      }
      console.log(request.headers.get('Spinner'));
    }

    let auth: any = request.headers.has('Authorization') ? request.headers.get('Authorization') : '';
    const newRequest = request.clone({
      headers: new HttpHeaders({
        'Authorization': auth
      })
    })

    return next.handle(request).pipe(
      finalize(() => {
        const index = this.requests.indexOf(request);
        this.requests.splice(index, 1);
        if (this.requests.length === 0) {
          this.dismissLoading();
        }
      })
    );
  }

  private async presentLoading() {
    this.loading = await this.loadingController.create({
      message: 'Please Wait ...'
    });
    await this.loading.present();
  }

  private dismissLoading() {
    if (this.loading) {
      this.loading.dismiss();
      // this.loading = new HTMLIonLoadingElement;
    }
  }

}
