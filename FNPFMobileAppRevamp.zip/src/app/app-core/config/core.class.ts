export class DeviceInfo {
    name = "";
    model = "";
    platform = "";
    operatingSystem = "";
    osVersion = "";
    manufacturer = "";
    isVirtual = false;
    memUsed = 0;
    diskFree = 0;
    diskTotal = 0;
    realDiskFree = 0;
    realDiskTotal = 0;
    webViewVersion = 0;
}

export class BatteryInfo {
    batteryLevel = 0;
    isCharging = false;
}

export class DeviceID {
    uuid = "";
}

export class ConnectionStatus {
    connected = false;
    connectionType = "";
}

export class LocationPermissionStatus {
    coarseLocation = "";
    location = "";
}
export class LocationPosition {
    timestamp = 0;
    coords = {
        latitude: 0,
        longitude: 0,
        accuracy: 0,
        altitudeAccuracy: 0,
        altitude: 0,
        speed: 0,
        heading: 0
    }
}
export class LocationAddress {
    latitude = 0;
    longitude = 0;
    countryCode = "";
    countryName = "";
    postalCode = "";
    administrativeArea = "";
    subAdministrativeArea = "";
    locality = "";
    subLocality = "";
    thoroughfare = "";
    subThoroughfare = "";
    areasOfInterest = "";
}