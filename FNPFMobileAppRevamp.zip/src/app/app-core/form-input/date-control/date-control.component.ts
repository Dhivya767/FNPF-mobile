import { AfterViewInit, Component, Input, OnInit, Optional, Self, ViewChild } from '@angular/core';
import { NgControl } from '@angular/forms';
import { IonDatetime, IonInput } from '@ionic/angular';
import { FromInputControl } from '../form-input-control';
import { addYears, format, formatISO, isMatch, parse, parseISO, sub } from 'date-fns';

@Component({
  selector: 'app-date-control',
  templateUrl: './date-control.component.html',
  styleUrls: ['./date-control.component.scss'],
})
export class DateControlComponent extends FromInputControl implements OnInit, AfterViewInit {
  @Input() dob = false;
  @Input() adult = false;
  @Input() inputFormat = "dd/MM/yyyy";
  @ViewChild('formInput') formInput!: IonInput;
  inputElement: any;
  selectedDate = "";
  @ViewChild('datePicker') datePicker!: any;
  defaultMaxDate = formatISO(addYears(new Date(), 50));
  minDateNow = "";
  @Input()
  set minDate(minDate: string) {
    this.minDateNow = minDate || "";
  }
  get minDate() {
    return this.minDateNow;
  }
  maxDateNow = this.defaultMaxDate;
  @Input()
  set maxDate(maxDate: string) {
    this.maxDateNow = maxDate || this.defaultMaxDate;
  }
  get maxDate() {
    return this.maxDateNow;
  }


  constructor(@Self() @Optional() public control: NgControl) {
    super();
    this.control && (this.control.valueAccessor = this);
    this.xControl = this.control;
  }
  async ngAfterViewInit() {
    this.inputElement = await this.formInput.getInputElement();
    this.inputElement.addEventListener('keyup', (event: any) => {
      console.log(event);
    });
    this.viewValueChange().subscribe(async (xvalue) => {
      if (xvalue) {
        if (this.value) {
          this.setDateChanged()
        } else {
          this.selectedDate = '';
        }
      }
    });
  }

  async ngOnInit() {
    await this.setValidate(this.control);
    await this.init();
  }
  init() {
    // dob cannot be future
    if (this.dob) {

    }
    const result = sub(new Date(), { years: 18 });
    // Yesterday Date
    result.setDate(result.getDate() - 1);
    setTimeout(() => {
      // dob cannot be future
      if (this.dob) {
        this.maxDateNow = format(new Date(), 'yyyy-MM-dd');
      }
      if (this.adult) {
        this.maxDateNow = format(result, 'yyyy-MM-dd');
      }
    }, 200);
  }
  async onInput(event: any) {
    console.log(event);
    // console.log(await this.formInput.getInputElement());
  }

  setDateChanged() {
    if (this.value && this.value !== '') {
      if (isMatch(this.value, this.inputFormat)) {
        let parseDate = parse(this.value, this.inputFormat, new Date());
        this.selectedDate = format(parseDate, 'dd MMM yyyy');
        this.value = formatISO(parseDate);
      } else {
        this.selectedDate = format(new Date(this.value), 'dd MMM yyyy');
      }



    } else {
      this.selectedDate = '';
    }
  }

  doSelectedDate() {
    let selectedDate: any = this.datePicker.value;
    console.log(selectedDate);
    if (selectedDate !== "" && selectedDate) {
      this.selectedDate = format(new Date(selectedDate), 'dd MMM yyyy');
      this.value = selectedDate;
    } else {
      this.selectedDate = "";
      this.value = "";
    }
    // this.selectedDate = this.datePicker.value;
    // if (this.datePicker.value) {
    //   let date = new Date(this.datePicker.value);

    // }
    // console.log(this.datePicker.value);
  }

}
