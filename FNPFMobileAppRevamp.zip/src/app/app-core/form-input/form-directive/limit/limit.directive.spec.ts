import { LimitDirective } from './limit.directive';

describe('LimitDirective', () => {
  it('should create an instance', () => {
    const directive = new LimitDirective();
    expect(directive).toBeTruthy();
  });
});
