import { LowerCaseDirective } from './lower-case.directive';

describe('LowerCaseDirective', () => {
  it('should create an instance', () => {
    const directive = new LowerCaseDirective();
    expect(directive).toBeTruthy();
  });
});
