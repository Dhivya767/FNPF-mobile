import { SelectSearchPipe } from './select-search.pipe';

describe('SelectSearchPipe', () => {
  it('create an instance', () => {
    const pipe = new SelectSearchPipe();
    expect(pipe).toBeTruthy();
  });
});
