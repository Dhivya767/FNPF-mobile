import { AfterViewInit, ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Optional, Output, Self, ViewChild } from '@angular/core';
import { FromInputControl } from '../form-input-control';
import { NgControl } from '@angular/forms';
import { IonInput, IonModal } from '@ionic/angular';

@Component({
  selector: 'app-select-control',
  templateUrl: './select-control.component.html',
  styleUrls: ['./select-control.component.scss'],
})
export class SelectControlComponent extends FromInputControl implements OnInit, AfterViewInit {
  @ViewChild('formInput') formInput!: IonInput;
  inputElement: any;
  xName = '';
  xSubName1 = '';
  xSubName2 = '';
  @Input() checkBankAgainstAccountId = false;
  @ViewChild(IonModal) modal!: IonModal;
  @Input() public key: string = '';
  @Input() public keyname: string = '';
  @Input() public sort: boolean = true;
  @Input() public clearIcon: boolean = true;
  @Input() public startDate: string = '';
  @Input() public endDate: string = '';
  @Input() public accountName: string = '';
  @Output('inputChange') inputChange: EventEmitter<any> = new EventEmitter();
  itemsNow = [];
  isModalOpen = false;
  @Input()
  set items(items: any) {
    this.itemsNow = items || [];
    //console.log(items);
    if (items) {
      if (items.length > 3) {
        this.search = true;
        this.getSelected();
        // this.clearIcon = true;
      }
    }
  }
  get items() {
    return this.itemsNow;
  }

  searchItem = '';
  tempSelected = "";
  selectedItem: any;

  constructor(@Self() @Optional() public control: NgControl, private cdf: ChangeDetectorRef) {
    super();
    this.control && (this.control.valueAccessor = this);
    this.xControl = this.control;
  }
  async ngAfterViewInit() {

  }

  ngOnInit(): void {

    this.setValidate(this.control);
    // console.log(this.search);
    this.cdf.detectChanges();
    this.viewValueChange().subscribe(async (xvalue) => {
      if (xvalue) {
        if (this.value) {
          console.log('Value', this.value)
          this.getSelected();
        } else {
          this.selectedItem = undefined;
          this.tempSelected = "";
        }
      }
    });
  }

  getSelected() {

    this.tempSelected = this.value;
    // let value = this.value.toString();
    let index = this.itemsNow.map((e: any) => e[this.key]).indexOf(this.value);
    // let index = this.itemsNow.findIndex((item: any) => item[this.key] === this.tempSelected);
    console.log('index', index)
    if (index > -1) {
      // this.selectedItem = JSON.parse(JSON.stringify(this.itemsNow[index]));
      this.selectedItem = this.itemsNow[index];
      this.xName = this.selectedItem[this.keyname];
      if (this.startDate !== '') {
        this.xSubName1 = this.selectedItem[this.startDate]
      }
      if (this.endDate !== '') {
        this.xSubName2 = this.selectedItem[this.endDate]
      }
      if (this.accountName !== '') {
        this.xSubName2 = this.selectedItem[this.accountName]
      }
    }
    console.log('Selected Item', this.selectedItem)
  }



  triggerModal() {
    // if (!this.btnClickedNow) {
    //   this.isModalOpen = true;
    // }
  }

  doConfirm() {
    this.xName = this.selectedItem[this.keyname];
    this.value = this.selectedItem[this.key];
    if (this.startDate !== '') {
      this.xSubName1 = this.selectedItem[this.startDate]
    }
    if (this.endDate !== '') {
      this.xSubName2 = this.selectedItem[this.endDate]
    }
    this.inputChange.next(this.value);
    this.dismiss();
    console.log(this.xName)
  }
  valueSelected(item: any) {
    this.selectedItem = item;
    this.tempSelected = item[this.key];
    this.doConfirm();
  }
  dismiss() {
    this.modal.dismiss();
  }

}
