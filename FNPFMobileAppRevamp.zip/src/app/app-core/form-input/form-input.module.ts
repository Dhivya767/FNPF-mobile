import { NgModule } from "@angular/core";
import { InputControlComponent } from "./input-control/input-control.component";
import { PinControlComponent } from "./pin-control/pin-control.component";
import { PasswordControlComponent } from "./password-control/password-control.component";
import { DateControlComponent } from "./date-control/date-control.component";
import { EmailControlComponent } from "./email-control/email-control.component";
import { SelectControlComponent } from "./select-control/select-control.component";
import { SelectSearchPipe } from "./select-control/select-search.pipe";
import { NumberControlComponent } from "./number-control/number-control.component";
import { CommonModule } from "@angular/common";
import { IonicModule } from "@ionic/angular";
import { FormsModule } from "@angular/forms";
import { FormDirectiveModule } from "./form-directive/form-directive.module";


@NgModule({
  declarations: [
    InputControlComponent,
    PinControlComponent,
    PasswordControlComponent,
    DateControlComponent,
    EmailControlComponent,
    SelectControlComponent,
    SelectSearchPipe,
    NumberControlComponent,
  ],
  imports: [CommonModule, IonicModule, FormsModule, FormDirectiveModule],
  exports: [
    FormsModule,
    InputControlComponent,
    PinControlComponent,
    PasswordControlComponent,
    DateControlComponent,
    EmailControlComponent,
    SelectControlComponent,
    NumberControlComponent,
  ],
})
export class FormInputModule { }
