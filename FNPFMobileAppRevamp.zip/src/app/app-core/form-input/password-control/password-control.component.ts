import {
  AfterViewInit,
  Component,
  OnInit,
  Optional,
  Self,
  ViewChild,
} from '@angular/core';
import { NgControl } from '@angular/forms';
import { IonInput } from '@ionic/angular';
import { FromInputControl } from '../form-input-control';

@Component({
  selector: 'app-password-control',
  templateUrl: './password-control.component.html',
  styleUrls: ['./password-control.component.scss'],
})
export class PasswordControlComponent
  extends FromInputControl
  implements OnInit, AfterViewInit {
  @ViewChild('formInput') formInput!: IonInput;
  inputElement: any;
  textType = "password";
  constructor(@Self() @Optional() public control: NgControl) {
    super();
    this.control && (this.control.valueAccessor = this);
    this.xControl = this.control;
  }
  async ngAfterViewInit() {
    this.inputElement = await this.formInput.getInputElement();
    this.inputElement.addEventListener('keyup', (event: any) => {
      console.log(event);
    });
  }

  ngOnInit(): void {
    this.setValidate(this.control);
  }

  async onInput(event: any) {
    console.log(event);
    // console.log(await this.formInput.getInputElement());
  }

  toggleShow() {
    this.textType = this.textType === 'password' ? 'text' : 'password';
  }
}
