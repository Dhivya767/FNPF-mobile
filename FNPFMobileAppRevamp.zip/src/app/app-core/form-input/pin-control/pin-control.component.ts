import {
  AfterViewInit,
  Component,
  EventEmitter,
  Input,
  OnInit,
  Optional,
  Output,
  Self,
} from '@angular/core';
import { FromInputControl } from '../form-input-control';
import { NgControl } from '@angular/forms';

@Component({
  selector: 'app-pin-control',
  templateUrl: './pin-control.component.html',
  styleUrls: ['./pin-control.component.scss'],
})
export class PinControlComponent
  extends FromInputControl
  implements OnInit, AfterViewInit
{
  type = 'password';
  sets: any = [];
  boxes = 4;
  @Input() showForgotPin = false;
  @Output('onForgotPin') onForgotPin: EventEmitter<any> = new EventEmitter();

  constructor(@Self() @Optional() public control: NgControl) {
    super();
    this.control && (this.control.valueAccessor = this);
    this.xControl = this.control;
  }
  ngAfterViewInit(): void {
    this.init();
  }

  changeType() {
    this.type === 'text' ? (this.type = 'password') : (this.type = 'text');
  }

  ngOnInit() {}

  init() {
    setTimeout(() => {
      for (let i = 0; i < this.boxes; i++) {
        const obj = {
          value: '',
          id: this.name + i,
          nextid: this.name + (i + 1),
          previd: i === 0 ? '' : this.name + (i - 1),
        };
        this.sets.push(obj);
      }
    }, 200);
  }

  setValueFn() {
    let value = '';
    this.sets.forEach((element: any) => {
      if (element.value !== '') {
        value = value + element.value.toString();
      }
    });
    this.value = value;
    if (this.value.length === this.boxes) {
      // this.onFinished.emit();
    }
    // console.log(this.value.length, this.boxes);
  }

  pinClear() {
    this.sets = [];
    for (let i = 0; i < this.boxes; i++) {
      const obj = {
        value: '',
        id: this.name + i,
        nextid: this.name + (i + 1),
      };
      this.sets.push(obj);
    }
    this.value = '';
  }

  doForgotPin() {
    this.onForgotPin.emit();
  }
}
