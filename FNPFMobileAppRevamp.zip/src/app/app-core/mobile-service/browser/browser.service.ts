import { Injectable } from '@angular/core';
import { Browser } from '@capacitor/browser';

@Injectable({
  providedIn: 'root'
})
export class BrowserService {

  constructor() { }


  open(url: any) {

    return new Promise(async (resolve) => {
      let validUrl: any = await this.isValidUrl(url);
      if (!validUrl) {
        let msg = {
          status: false,
          message: 'Invalid Url'
        }
        resolve(msg);
      } else {
        // console.log(validUrl)
        await Browser.addListener('browserFinished', async () => {
          await Browser.removeAllListeners();
          let msg = {
            status: true,
            message: 'Browser Closed'
          }
          resolve(msg);
        })
        await Browser.open({ url: validUrl });
      }
    })
  }

  isValidUrl(url: any) {
    return new Promise((resolve) => {
      resolve(url);
      // console.log(url);
      // let correctedURL = url.trim();
      // if (!/^https?:\/\//i.test(correctedURL)) {
      //   correctedURL = 'http://' + correctedURL.replace(/^www\./i, '');
      // }
      // // const isValidURL = /^https?:\/\/(?:www\.)?[a-z0-9-]+\.[a-z]{2,}(?:\/[^<>]*)?$/i.test(correctedURL);
      // const isValidURL = /^(?:(?:https?|ftp):\/\/)?(?:www\.)?[a-z0-9-]+(?:\.[a-z]{2,})+(?:\/\S*)?$/i.test(correctedURL);

      // if (isValidURL) {
      //   resolve(correctedURL);
      // } else {
      //   resolve(undefined);
      // }
    })

  }

}
