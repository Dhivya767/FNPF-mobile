import { Injectable } from '@angular/core';
import { NativeGeocoder, reverseOptions } from '@capgo/nativegeocoder';

@Injectable({
  providedIn: 'root'
})
export class NativeGeocodeService {

  constructor() { }

  async getAddress(option: reverseOptions) {
    try {
      const address = await NativeGeocoder.reverseGeocode(option);
      return address;
    } catch (error) {
      console.error(error);
      return null;
    }
  }
}
