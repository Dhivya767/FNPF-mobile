import { Injectable } from '@angular/core';
import { Camera, CameraDirection, CameraResultType, CameraSource } from '@capacitor/camera';
import { AlertController } from '@ionic/angular';
import { NativeSettingsService } from '../native-settings/native-settings.service';
import { DeviceService } from '../device/device.service';


@Injectable({
  providedIn: 'root'
})
export class CameraService {

  private _permissionAlertMessage = {
    ios: "Camera permission is required to take photos. Please enable camera permission in Settings.",
    android: "Camera permission is required to take photos. Please enable camera permission in App Settings."
  }

  cameraPermissionStatus = {
    camera: '',
    photos: ''
  };

  constructor(
    public alertController: AlertController,
    public nativeSettings: NativeSettingsService,
    public device: DeviceService
  ) {
    this.device.getDeviceInfo();
  }


  async checkPermission(type: string): Promise<boolean> {
    this.cameraPermissionStatus = await Camera.checkPermissions();

    if (type === 'camera') {
      if (this.cameraPermissionStatus.camera === 'denied') {
        this.informUser();
        return false;
      }
    } else if (type === 'photos') {
      if (this.cameraPermissionStatus.photos === 'denied') {
        this.informUser();
        return false;
      }
    }

    return type === 'camera' || type === 'photos';
  }

  async requestPermission(type: string): Promise<boolean> {
    if (type === 'camera') {
      let requestPermission = await Camera.requestPermissions({ permissions: ['camera'] });
      if (requestPermission.camera === 'denied') {
        this.informUser();
        return false;
      }
      return true;
    } else if (type === 'photos') {
      let requestPermission = await Camera.requestPermissions({ permissions: ['photos'] });
      if (requestPermission.photos === 'denied') {
        this.informUser();
        return false;
      }
      return true;
    }
    return type === 'camera' || type === 'photos';
  }


  async takeSelfie(): Promise<string> {
    let hasPermission = await this.checkPermission('camera');
    if (!hasPermission) {
      let requestPermission = await this.requestPermission('camera');
      if (!requestPermission) {
        return '';
      }
    }
    const image = await Camera.getPhoto({
      quality: 90,
      allowEditing: true,
      resultType: CameraResultType.DataUrl,
      source: CameraSource.Camera,
      direction: CameraDirection.Front,
      width: 450,
      height: 450
    });
    let imageBase64: any = image.dataUrl;
    return imageBase64;
  }


  async captureImage(): Promise<string> {
    let hasPermission = await this.checkPermission('camera');
    if (!hasPermission) {
      let requestPermission = await this.requestPermission('camera');
      if (!requestPermission) {
        return '';
      }
    }
    const image = await Camera.getPhoto({
      quality: 100,
      allowEditing: true,
      resultType: CameraResultType.DataUrl,
      source: CameraSource.Camera,
      direction: CameraDirection.Rear,
      width: 1000,
      height: 1000,
      correctOrientation: true
    });

    let imageBase64: any = image.dataUrl;
    return imageBase64;
  }



  informUser() {
    if (this.device.deviceInfo.platform === 'android') {
      this.informAndroidUser();
    } else if (this.device.deviceInfo.platform === 'ios') {
      this.informIOSUser();
    }
  }



  async informAndroidUser() {
    const alert = await this.alertController.create({
      header: 'Permission Request',
      message: "Oops! It looks like you denied camera permission earlier. To continue, you will need to enable camera permission for our app in your app settings. Click 'OK' to be redirected to your app settings, then select 'Permission' > 'Camera' > 'Allow only while using the app'. Thank you!",
      buttons: [{
        text: 'Ok',
        handler: () => {
          this.nativeSettings.open();
        }
      }],
    });
    await alert.present();
  }

  async informIOSUser() {
    const alert = await this.alertController.create({
      header: 'Permission Request',
      message: "Oops! It looks like you denied location permission earlier.",
      buttons: [{
        text: 'Ok',
        handler: () => {
          this.nativeSettings.open();
        }
      }],
    });
    await alert.present();
  }




}
