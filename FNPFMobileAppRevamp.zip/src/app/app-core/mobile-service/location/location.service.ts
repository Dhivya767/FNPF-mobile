import { Injectable } from '@angular/core';
import { Geolocation } from '@capacitor/geolocation';
import { LocationAddress, LocationPermissionStatus, LocationPosition } from '../../config/core.class';
import { DeviceService } from '../device/device.service';
import { NativeSettingsService } from '../native-settings/native-settings.service';
import { AlertController } from '@ionic/angular';
import { NativeGeocodeService } from '../native-geocode/native-geocode.service';
import { DataService } from 'src/app/common/services/data/data.service';

@Injectable({
  providedIn: 'root'
})
export class LocationService {
  locationPermissionStatus = new LocationPermissionStatus();
  position: any = new LocationPosition();
  address: any = new LocationAddress();
  // locationData: any = "";
  constructor(
    public device: DeviceService,
    public nativeSettings: NativeSettingsService,
    public alertController: AlertController,
    public nativeGeocode: NativeGeocodeService,
    public data: DataService
  ) { }

  async init() {
    try {
      this.locationPermissionStatus = await Geolocation.checkPermissions();
      if (this.locationPermissionStatus.location === 'denied') {
        if (this.device.deviceInfo.platform === 'android') {
          this.informAndroidUser();
        } else if (this.device.deviceInfo.platform === 'ios') {
          this.informIOSUser();
        }
      }
      if (this.device.deviceInfo.platform !== 'web') {
        await this.requestPermission();
      }
      let position: any = await Geolocation.getCurrentPosition();
      this.position = position;
      let option = {
        latitude: this.position.coords.latitude,
        longitude: this.position.coords.longitude,
        useLocale: true
      }
      console.log(this.position);
      let address: any = await this.nativeGeocode.getAddress(option);
      this.address = address;
      return true;
    } catch (error) {
      console.error(error);
      return false;
    }
  }

  async requestPermission() {
    debugger
    let requestPermission = await Geolocation.requestPermissions({ permissions: ['location'] });
    if (requestPermission.location === 'denied') {
      console.log(requestPermission.location, 'request permisson denied');

      this.data.constructErrorMessage('No permission to access the location information. Please enable and try again.');
      if (this.device.deviceInfo.platform === 'android') {
        this.informAndroidUser();
      } else if (this.device.deviceInfo.platform === 'ios') {
        this.informIOSUser();
      }
    }
  }

  async informAndroidUser() {
    const alert = await this.alertController.create({
      header: 'Permission Request',
      message: "Oops! It looks like you denied location permission earlier. To continue, you will need to enable location permission for our app in your app settings. Click 'OK' to be redirected to your app settings, then select 'Permission' > 'Location' > 'Allow only while using the app'. Thank you!",
      buttons: [{
        text: 'Ok',
        handler: () => {
          this.nativeSettings.open();
        }
      }],
    });
    await alert.present();

  }

  async informIOSUser() {
    const alert = await this.alertController.create({
      header: 'Permission Request',
      message: "Oops! It looks like you denied location permission earlier.",
      buttons: [{
        text: 'Ok',
        handler: () => {
          this.nativeSettings.open();
        }
      }],
    });
    await alert.present();
  }

}
