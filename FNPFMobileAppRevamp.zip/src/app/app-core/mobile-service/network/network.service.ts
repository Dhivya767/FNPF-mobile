import { Injectable, OnDestroy, OnInit } from '@angular/core';
import { Network } from '@capacitor/network';
import { ConnectionStatus } from '../../config/core.class';
import { ToastController } from '@ionic/angular';

@Injectable({
  providedIn: 'root'
})
export class NetworkService implements OnInit, OnDestroy {
  status: any = new ConnectionStatus();
  isStatusWatched = false;

  constructor(private toastController: ToastController) { }

  async ngOnDestroy() {
    let removeListener = await Network.removeAllListeners();
    // console.log(removeListener);
    this.isStatusWatched = false;
  }
  ngOnInit(): void {
    this.init();
  }

  async init() {
    this.getStatus();
    // Add Listener for Status Change
    this.isStatusWatched = true;
    Network.addListener('networkStatusChange', (status) => {
      // this.status = status;
      // console.log(status);
      if (!status.connected) {
        this.showStatusToast();
      } else {
        this.toastController.dismiss();
      }
      setTimeout(() => {
        this.getStatus();
      }, 200);
    });
  }

  async getStatus() {
    const status: any = await Network.getStatus();
    this.status = status;
  }

  async showStatusToast() {
    const toast = await this.toastController.create({
      message: "You're currently offline. Apologies.",
      color: "danger",
      position: "top"
    });
    await toast.present();
  }




}
