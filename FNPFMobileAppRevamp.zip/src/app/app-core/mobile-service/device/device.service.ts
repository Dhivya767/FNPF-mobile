import { Injectable } from '@angular/core';
import { Device } from '@capacitor/device';
import { BatteryInfo, DeviceID, DeviceInfo } from '../../config/core.class';
@Injectable({
  providedIn: 'root'
})
export class DeviceService {
  deviceInfo: any = new DeviceInfo();
  batteryInfo: any = new BatteryInfo();
  deviceID: any = new DeviceID();

  constructor(

  ) { }


  async getDeviceID() {
    let deviceID: any = await Device.getId();
    this.deviceID = deviceID;
    // console.log(this.deviceID);
  }

  async getDeviceInfo() {
    let deviceInfo: any = await Device.getInfo();
    this.deviceInfo = deviceInfo;
  }

  async getBatteryInfo() {
    let batteryInfo: any = await Device.getBatteryInfo();
    this.batteryInfo = batteryInfo;
  }

} 
