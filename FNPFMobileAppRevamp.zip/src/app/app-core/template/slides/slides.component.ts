import { CommonModule } from '@angular/common';
import { AfterViewInit, Component, OnInit } from '@angular/core';
import Swiper, { Pagination } from 'swiper';

@Component({
  selector: 'app-slides',
  templateUrl: './slides.component.html',
  styleUrls: ['./slides.component.scss'],
  standalone: true,
  imports: [CommonModule]
})
export class SlidesComponent implements AfterViewInit {

  constructor() { }

  ngAfterViewInit(): void {
    this.init();
  }


  init() {
    const swiper = new Swiper('.swiper', {
      // configure Swiper to use modules
      modules: [Pagination],
      pagination: {
        el: '.swiper-pagination',
      },
    });
  }

}
