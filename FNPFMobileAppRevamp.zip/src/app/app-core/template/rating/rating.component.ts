import { CommonModule } from '@angular/common';
import { Component, OnInit, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-rating',
  templateUrl: './rating.component.html',
  styleUrls: ['./rating.component.scss'],
  standalone: true,
  imports: [CommonModule]
})
export class RatingComponent implements OnInit {
  stars: any = [1, 2, 3, 4, 5];
  starRating = 0;

  @Output('onSelect') onSelect: EventEmitter<any> = new EventEmitter();

  constructor() { }

  ngOnInit() { }

  goRating(val: any) {
    this.starRating = val;
    this.onSelect.emit(parseInt(val));
  }

}
