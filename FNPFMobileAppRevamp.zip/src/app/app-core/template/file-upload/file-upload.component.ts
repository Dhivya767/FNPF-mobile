import { CommonModule } from '@angular/common';
import { AfterViewInit, Component, ElementRef, EventEmitter, Input, OnInit, Output, Renderer2, ViewChild } from '@angular/core';
import { IonicModule } from '@ionic/angular';

@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.scss'],
  standalone: true,
  imports: [CommonModule, IonicModule]
})
export class FileUploadComponent implements OnInit, AfterViewInit {

  document = {
    fileName: '',
    fileSizeinBytes: 0,
    fileType: '',
    imageFile: ''
  }

  @Input() allowedFileType: any = ['jpg', 'png', 'pdf'];
  @Input() allowedFileSize = 3;

  @Output() onError: EventEmitter<any> = new EventEmitter();
  @Output() onClearError: EventEmitter<any> = new EventEmitter();
  @Output() onSelected: EventEmitter<any> = new EventEmitter();


  @ViewChild('nativeFileUpload') nativeFileUpload!: ElementRef;



  constructor(private el: ElementRef) { }

  ngAfterViewInit() {
    this.el.nativeElement.classList.add('document-file', 'ion-activatable', 'ripple-parent', 'rounded-rectangle');
  }

  ngOnInit() { }

  loadImageFromDevice(event: any) {
    this.onClearError.emit();
    this.clearDocument();
    const file = event.target?.files[0];
    if (file) {
      let fileName = event.target.files[0].name;
      let fileType = fileName.substring(fileName.lastIndexOf(".") + 1).toLowerCase();
      let fileSizeInMB = ((event.target.files[0].size) / 1000) / 1024;
      let fileTypeIndex = this.allowedFileType.indexOf(fileType);
      if (fileTypeIndex === -1) {
        this.onError.emit('The selected file format is not supported. Please select the file in following formats: ' + this.allowedFileType.join(', ') + '.');
        this.nativeFileUpload.nativeElement.value = "";
        return;
      }
      if (fileSizeInMB > this.allowedFileSize) {
        this.onError.emit("The file size is too big. Please reduce the file size to " + this.allowedFileSize + " MB");
        this.nativeFileUpload.nativeElement.value = "";
        return;
      }

      const reader = new FileReader();
      reader.readAsDataURL(file);

      reader.onload = () => {
        let base64Image = reader.result?.toString();
        if (!base64Image) {
          this.onError.emit('Please select a different file.');
          this.nativeFileUpload.nativeElement.value = "";
          return;
        }
        this.document.fileName = fileName;
        this.document.fileType = fileType;
        this.document.fileSizeinBytes = event.target.files[0].size;
        this.document.imageFile = base64Image;
        this.onSelected.emit(this.document);
        this.nativeFileUpload.nativeElement.value = "";
      };
      reader.onerror = (error) => {
        this.onError.emit('Error has been occurred, while selecting the file.');
        this.nativeFileUpload.nativeElement.value = "";
        return;
      }
    } else {
      this.onError.emit('Error Selecting File. Please try again');
    }
  }

  triggerClick() {
    this.nativeFileUpload.nativeElement.click();
  }

  clearDocument() {
    this.document = {
      fileName: '',
      fileSizeinBytes: 0,
      fileType: '',
      imageFile: ''
    }
  }

}
