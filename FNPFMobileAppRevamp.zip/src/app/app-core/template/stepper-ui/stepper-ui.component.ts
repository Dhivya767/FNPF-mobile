import { CommonModule } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-stepper-ui',
  templateUrl: './stepper-ui.component.html',
  styleUrls: ['./stepper-ui.component.scss'],
  standalone: true,
  imports: [CommonModule]
})
export class StepperUiComponent implements OnInit {
  @Input() steps: any = [];
  @Input() activeStep = 0;
  constructor() { }

  ngOnInit() { }

}
