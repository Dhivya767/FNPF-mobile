import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ErrorCardComponent } from './error-card/error-card.component';
import { InfoCardComponent } from './info-card/info-card.component';
import { IonicModule } from '@ionic/angular';
import { DataErrorCardComponent } from './data-error-card/data-error-card.component';
import { FormErrorCardComponent } from './form-error-card/form-error-card.component';

@NgModule({
  declarations: [
    ErrorCardComponent,
    InfoCardComponent,
    DataErrorCardComponent,
    FormErrorCardComponent,
  ],
  imports: [CommonModule, IonicModule],
  exports: [
    ErrorCardComponent,
    InfoCardComponent,
    DataErrorCardComponent,
    FormErrorCardComponent,
  ],
})
export class MessagesModule {}
