import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/common/services/data/data.service';

@Component({
  selector: 'app-data-error-card',
  templateUrl: './data-error-card.component.html',
  styleUrls: ['./data-error-card.component.scss'],
})
export class DataErrorCardComponent implements OnInit {
  constructor(public data: DataService) {}

  ngOnInit() {}
}
