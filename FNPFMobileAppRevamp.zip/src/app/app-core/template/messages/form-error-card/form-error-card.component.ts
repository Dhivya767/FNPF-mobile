import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { DataService } from 'src/app/common/services/data/data.service';

@Component({
  selector: 'app-form-error-card',
  templateUrl: './form-error-card.component.html',
  styleUrls: ['./form-error-card.component.scss'],
})
export class FormErrorCardComponent implements OnInit, OnDestroy {
  @Input('errorMessage') errorMessage: any = {};
  objectErrorMessage = '';

  public __formObject: any = {};
  interval: any;
  @Input()
  set formObject(formObject: any) {
    this.__formObject = formObject || {};
    this.init();
  }
  get formObject() {
    return this.__formObject;
  }

  constructor(public data: DataService) { }

  ngOnInit() {
    this.interval = setInterval(() => {
      this.init();
    }, 100);
  }

  ngOnDestroy(): void {
    if (this.interval) {
      clearInterval(this.interval);
    }
  }

  init() {
    this.objectErrorMessage = '';
    let objects: any = Object.keys(this.__formObject);
    for (let index = 0; index < objects.length; index++) {
      if (!this.__formObject[objects[index]].valid) {
        this.objectErrorMessage = this.errorMessage[objects[index]];
        break;
      }
    }
  }
}
